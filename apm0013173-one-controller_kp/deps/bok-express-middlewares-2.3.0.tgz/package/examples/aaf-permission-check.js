const express = require("express");
const mw = require("@com.att.bok.express-middlewares/bok-express-middlewares");


const app = express();
const port = 3000;

app.use(mw.aaf({
    "checkPermissions": true,
    "requiredPermissions": [
        /*
         * I.e. you can create own makespace,
         * use instance as URI path and action as REST method reference
         */
        {
            "action": "ALL",
            "instance": "/.*",
            "type": "com.att.terminator.test.read"
        }
    ]
}));
app.get("/", (req, res) => {
    res.send("Hello World!");
});

app.listen(port, () => {
    /* eslint-disable-next-line no-console */
    console.log("Example app listening at http://localhost:3000");
});
