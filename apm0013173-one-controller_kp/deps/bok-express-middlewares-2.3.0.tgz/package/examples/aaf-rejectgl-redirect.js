const express = require("express");
const mw = require("@com.att.bok.express-middlewares/bok-express-middlewares");


const app = express();

app.use(mw.aaf({ "rejectGlobalLogon": "https://att.com" }));
app.get("/", (req, res) => {
    res.send("Hello World!");
});

/* eslint-disable-next-line no-magic-numbers */
app.listen(3000, () => {
    /* eslint-disable-next-line no-console */
    console.log("Example app listening at http://localhost:3000");
});
