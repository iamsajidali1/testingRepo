/**
 * Very simple example for the middleware usage.
 * Reset cache manually via (todo TTL for items?):
 * axios.get(url, {headers: {"Cache-Control": "no-cache", ...}});
 */
const express = require("express");
const mw = require("@com.att.bok.express-middlewares/bok-express-middlewares");


const app = express();

app.use((req, res, next) => {
    req.user = "pb548a";
    next();
});

app.use(mw.upm({ "appId": 23 }));
app.get("/", (req, res) => {
    res.json(req.upmIdLevels);
});

/* eslint-disable-next-line no-magic-numbers */
app.listen(3000, () => {
    /* eslint-disable-next-line no-console */
    console.log("Example app listening at http://localhost:3000");
});
