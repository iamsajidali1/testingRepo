/**
 * TODO tests:
 * * GL redirect when invalid/expired/empty attESHr+ cookies passed
 */

/* eslint-disable no-undefined */
/* eslint-disable max-lines, max-lines-per-function, max-statements */
const assert = require("assert");
const sinon = require("sinon");
const mocha = require("mocha");
const pino = "pino";
const { beforeEach, afterEach, after, describe, it } = mocha;

const mwModule = "/app";
const depModules = [
    mwModule, "lru-cache", "https", "axios", "pino"
];
const { "stringify": str } = JSON;

const INTERNAL_SERVER_ERROR = 500;

afterEach(() => {
    sinon.restore();
    for (const mod of depModules) {
        delete require.cache[require.resolve(mod)];
    }
});

const splitMsg = "Cannot read property 'split' of undefined";
const HTTP_FORBIDDEN = 403;
const HTTP_MOVED_PERMANENTLY = 301;
const HTTP_FOUND = 302;

const mockLog = () => {
    require(pino);
    const fake = sinon.fake();
    sinon.stub(
        require.cache[require.resolve(pino)], "exports"
    ).returns({ "info": fake });
    return fake;
};

describe("Readable attESHr cookie parsing", () => {
    beforeEach(mockLog);

    afterEach(() => sinon.restore());

    it("attuid is the 8th item", () => {
        const mw = require(mwModule);
        const parse = mw.parseEshr;
        const left = "-|-|-|||-||";
        const right = ",-,-,-|-|-|-|1";
        const attuid = "ATTUID";
        const cookie = `${left}${attuid}${right}`;
        assert(parse(cookie) === attuid);
    });

    it("do not parse escaped cookie", () => {
        const mw = require(mwModule);
        const left = "-%7c-%7c-%7c%7c%7c-%7c%7c";
        const right = "%2c-%2c-%2c-%7c-%7c-%7c-%7c1";
        const attuid = "ATTUID";
        const cookie = `${left}${attuid}${right}`;
        const spy = sinon.spy(mw);
        try {
            spy.parseEshr(cookie);
        } catch (err) {
            assert(err.message === splitMsg);
        }
        assert(spy.parseEshr.threw("TypeError"));
    });
});


describe("Resolve Cookie header to object", () => {
    beforeEach(mockLog);

    describe("missing Cookie header", () => {
        afterEach(sinon.restore);

        it("should throw TypeError", () => {
            const mw = require(mwModule);
            const spy = sinon.spy(mw);
            try {
                spy.resolveCookies(undefined);
            } catch (err) {
                assert(err.message === splitMsg);
            }
            assert(spy.resolveCookies.threw("TypeError"));
        });
    });

    describe("empty Cookie header", () => {
        afterEach(sinon.restore);

        it("should return empty object", () => {
            const mw = require(mwModule);
            const result = str(mw.resolveCookies(""));
            assert(result === "{}");
        });
    });

    describe("correct Cookie header", () => {
        afterEach(sinon.restore);

        it("should parse semicolon-separated key-value pairs", () => {
            const mw = require(mwModule);
            const data = mw.resolveCookies("key=va'lue2; x=va%lue; y=te-st");
            const result = str(data);
            assert(result === str({
                "key": "va'lue2", "x": "va%lue", "y": "te-st"
            }));
        });
    });
});


describe("call forbid() on unsuccessful credentials", () => {
    beforeEach(mockLog);

    describe("with homeUrl", () => {
        afterEach(sinon.restore);

        it("should redirect to custom home with 301", () => {
            const mw = require(mwModule);
            // Dummy mock for status func
            const redirect = sinon.stub();
            const res = { redirect };

            mw.forbid(res, "myhome");
            assert(redirect.calledOnceWith(HTTP_MOVED_PERMANENTLY, "myhome"));
        });
    });

    describe("without homeUrl", () => {
        afterEach(sinon.restore);

        it("should reject with 403 Forbidden", () => {
            const mw = require(mwModule);
            const send = sinon.spy();
            const status = sinon.stub().returns({ send });

            mw.forbid({ status });
            assert(status.calledOnceWith(HTTP_FORBIDDEN));
            /* eslint-disable-next-line no-inline-comments */
            assert(send.calledWith(/* Empty */));
        });
    });
});


describe("AAF API call", () => {
    describe("locate working AAF API endpoint", () => {
        afterEach(sinon.restore);

        describe("auth for locate endpoint", () => {
            it("Basic auth if user+pass+no attESHr available", async () => {
                const err = { "response": { "status": HTTP_FOUND } };
                const agent = "agent";
                const info = sinon.spy();
                const error = sinon.stub().onFirstCall().throws(agent);

                const ax = require("axios");
                const get = sinon.stub(ax, "get").rejects(err);

                const mw = require(mwModule);
                const {
                    AAF_LOCATE, AAF_LOCATE_ATTEMPTS, AAF_URL
                } = mw.constants;
                const getAgent = sinon.stub(
                    mw, "getInsecureAgent"
                ).returns(agent);
                sinon.stub(mw, "getLogger").returns({ error, info });

                const params = {
                    "encoded": "hello", "password": "pass", "username": "user"
                };

                let result = null;
                try {
                    await mw.getAafUrl(params);
                } catch (throwedErr) {
                    result = throwedErr;
                }

                assert(result !== null);
                assert(result.name === agent);
                assert(get.calledOnce);
                assert(getAgent.calledOnce);

                const { firstCall } = get;
                assert(firstCall.firstArg === `${AAF_URL}/${AAF_LOCATE}`);

                const { "lastArg": opts } = firstCall;
                assert(opts.httpsAgent === agent);

                const {
                    "Authorization": auth, "Cookie": glCookie
                } = opts.headers;
                assert(glCookie === undefined);
                assert(auth !== undefined);
                assert(auth.includes("Basic"));
                assert(auth.includes(params.encoded));

                /* eslint-disable-next-line no-magic-numbers */
                const [logAttempts] = info.args[2][0].split(": ").reverse();
                assert(logAttempts === AAF_LOCATE_ATTEMPTS.toString());
                assert(error.calledOnce);
                assert(str(error.firstCall.firstArg) === str(err));
            });

            it("Cookie auth as default if attESHr is available", async () => {
                const err = { "response": { "status": HTTP_FOUND } };
                const agent = "agent";
                const info = sinon.spy();
                const error = sinon.stub().onFirstCall().throws(agent);

                const ax = require("axios");
                const get = sinon.stub(ax, "get").rejects(err);

                const mw = require(mwModule);
                const {
                    AAF_LOCATE, AAF_LOCATE_ATTEMPTS, AAF_URL
                } = mw.constants;
                const getAgent = sinon.stub(
                    mw, "getInsecureAgent"
                ).returns(agent);
                sinon.stub(mw, "getLogger").returns({ error, info });

                const params = {};
                let result = null;

                try {
                    await mw.getAafUrl(params);
                } catch (throwedErr) {
                    result = throwedErr;
                }

                assert(result !== null);
                assert(get.calledOnce);
                assert(getAgent.calledOnce);

                const { firstCall } = get;
                assert(firstCall.firstArg === `${AAF_URL}/${AAF_LOCATE}`);

                const { "lastArg": opts } = firstCall;
                assert(opts.httpsAgent === agent);

                const {
                    "Authorization": auth, "Cookie": glCookie
                } = opts.headers;
                assert(auth === undefined);
                assert(glCookie !== undefined);
                for (const item of ["attESHr", "attESSec", "attESg2"]) {
                    assert(glCookie.includes(item));
                }

                /* eslint-disable-next-line no-magic-numbers */
                const [logAttempts] = info.args[2][0].split(": ").reverse();
                assert(logAttempts === AAF_LOCATE_ATTEMPTS.toString());
                assert(error.calledOnce);
                assert(str(error.firstCall.firstArg) === str(err));
            });

            it("no auth available", async () => {
                const req = {
                    "headers": {
                        /* eslint-disable-next-line no-extra-parens */
                        "authorization": (
                            "Basic YXR0dWlkQGNzcC5hdHQuY29tOnNvbWV0aGluZw=="
                        ),
                        "cookie": ""
                    }
                };
                const send = sinon.stub().returns("dummy-resp");
                const res = {
                    "status": sinon.stub().returns({ send })
                };
                const next = sinon.stub().returns("next");
                const error = sinon.spy();
                const info = sinon.spy();

                const mw = require(mwModule);
                sinon.stub(mw, "getLogger").returns({ error, info });
                sinon.stub(mw, "getAafUrl").resolves(null);

                assert(await mw.aaf({
                    "passOnMissingAuth": true
                })(req, res, next) === "next");
                assert(next.calledOnceWith());
                assert(!error.called);
                /* eslint-disable-next-line no-magic-numbers */
                assert(info.callCount === 7);
            });
        });

        describe("fail all attempts (N) for location API lookup", () => {
            afterEach(sinon.restore);

            it("bubble error on invalid auth for location API", async () => {
                const err = { "response": { "status": HTTP_FOUND } };
                const agent = "agent";
                const info = sinon.spy();
                const error = sinon.spy();

                const ax = require("axios");
                const get = sinon.stub(ax, "get").rejects(err);

                const mw = require(mwModule);
                const {
                    AAF_LOCATE, AAF_LOCATE_ATTEMPTS, AAF_URL
                } = mw.constants;
                const getAgent = sinon.stub(
                    mw, "getInsecureAgent"
                ).returns(agent);
                sinon.stub(mw, "getLogger").returns({ error, info });

                const params = {};

                let result = null;
                try {
                    await mw.getAafUrl(params);
                } catch (throwedErr) {
                    result = throwedErr;
                }

                assert(result !== null);
                assert(get.calledOnce);
                assert(getAgent.calledOnce);

                const { firstCall } = get;
                assert(firstCall.firstArg === `${AAF_URL}/${AAF_LOCATE}`);

                const { "lastArg": opts } = firstCall;
                assert(opts.httpsAgent === agent);

                const { "Cookie": glCookie } = opts.headers;
                assert(glCookie !== undefined);
                for (const item of ["attESHr", "attESSec", "attESg2"]) {
                    assert(glCookie.includes(item));
                }

                /* eslint-disable-next-line no-magic-numbers */
                const [logAttempts] = info.args[2][0].split(": ").reverse();
                assert(logAttempts === AAF_LOCATE_ATTEMPTS.toString());
                assert(error.calledTwice);
                assert(str(error.firstCall.firstArg) === str(err));
            });

            it("exhaust all the attempts with null workingUrl", async () => {
                const err = { "response": { "status": null } };
                const agent = "agent";
                const info = sinon.spy();
                const error = sinon.spy();

                const ax = require("axios");
                const get = sinon.stub(ax, "get").rejects(err);

                const mw = require(mwModule);
                const {
                    AAF_LOCATE, AAF_LOCATE_ATTEMPTS, AAF_URL
                } = mw.constants;
                const getAgent = sinon.stub(
                    mw, "getInsecureAgent"
                ).returns(agent);
                sinon.stub(mw, "getLogger").returns({ error, info });

                const params = {};

                assert(await mw.getAafUrl(params) === null);
                assert(get.callCount === AAF_LOCATE_ATTEMPTS);

                const { firstCall } = get;
                assert(firstCall.firstArg === `${AAF_URL}/${AAF_LOCATE}`);

                const { "lastArg": opts } = firstCall;
                assert(opts.httpsAgent === agent);
                assert(getAgent.calledOnce);

                const { "Cookie": glCookie } = opts.headers;
                assert(glCookie !== undefined);
                for (const att of ["attESHr", "attESSec", "attESg2"]) {
                    assert(glCookie.includes(att));
                }

                /* eslint-disable-next-line no-magic-numbers */
                const [logAttempts] = info.args[2][0].split(": ").reverse();
                assert(logAttempts === AAF_LOCATE_ATTEMPTS.toString());
                assert(error.callCount === AAF_LOCATE_ATTEMPTS);
                assert(str(error.firstCall.firstArg) === str(err));
            });
        });

        describe("get URLs but fail pings (M)", () => {
            afterEach(sinon.restore);
            it("with axios reject", async () => {
                const err = { "response": { "code": "skip" } };
                const item = {
                    "hostname": "host", "port": 123, "protocol": "proto"
                };
                const data = { "endpoint": [item] };
                const agent = "agent";
                const info = sinon.spy();
                const error = sinon.spy();

                const ax = require("axios");
                const get = sinon.stub(ax, "get").resolves({ data });
                const options = sinon.stub(ax, "options").rejects(err);

                const mw = require(mwModule);
                const {
                    AAF_LOCATE, AAF_LOCATE_ATTEMPTS, AAF_PING_ATTEMPTS, AAF_URL
                } = mw.constants;
                const getAgent = sinon.stub(
                    mw, "getInsecureAgent"
                ).returns(agent);
                sinon.stub(mw, "getLogger").returns({ error, info });

                const params = {};

                assert(await mw.getAafUrl(params) === null);
                assert(get.calledOnceWith(`${AAF_URL}/${AAF_LOCATE}`));
                const { "lastArg": opts } = get.firstCall;
                assert(opts.httpsAgent === agent);
                assert(getAgent.calledOnce);

                const { "Cookie": glCookie } = opts.headers;
                assert(glCookie !== undefined);
                for (const att of ["attESHr", "attESSec", "attESg2"]) {
                    assert(glCookie.includes(att));
                }

                /* eslint-disable-next-line no-magic-numbers */
                const [logAttempts] = info.args[2][0].split(": ").reverse();
                assert(logAttempts === AAF_LOCATE_ATTEMPTS.toString());

                /* eslint-disable-next-line no-magic-numbers */
                const [pingAttempts] = info.args[7][0].split(": ").reverse();
                assert(pingAttempts === AAF_PING_ATTEMPTS.toString());
                assert(options.callCount === AAF_PING_ATTEMPTS);

                assert(error.callCount === AAF_PING_ATTEMPTS);
                assert(str(error.firstCall.firstArg) === str(err));

                const { "firstArg": reach } = info.lastCall;
                assert(reach.toLowerCase().includes("ping"));
                assert(reach.toLowerCase().includes("reached"));
            });

            it("with ECONNREFUSED", async () => {
                const resp = { "code": "ECONNREFUSED" };
                const item = {
                    "hostname": "host", "port": 123, "protocol": "proto"
                };
                const data = { "endpoint": [item] };
                const agent = "agent";
                const info = sinon.spy();
                const error = sinon.spy();

                const ax = require("axios");
                const get = sinon.stub(ax, "get").resolves({ data });
                const options = sinon.stub(ax, "options").resolves(resp);

                const mw = require(mwModule);
                const {
                    AAF_LOCATE, AAF_LOCATE_ATTEMPTS, AAF_PING_ATTEMPTS, AAF_URL
                } = mw.constants;
                const getAgent = sinon.stub(
                    mw, "getInsecureAgent"
                ).returns(agent);
                sinon.stub(mw, "getLogger").returns({ error, info });

                const params = {};

                assert(await mw.getAafUrl(params) === null);
                assert(get.calledOnceWith(`${AAF_URL}/${AAF_LOCATE}`));
                const { "lastArg": opts } = get.firstCall;
                assert(opts.httpsAgent === agent);
                assert(getAgent.calledOnce);

                const { "Cookie": glCookie } = opts.headers;
                assert(glCookie !== undefined);
                for (const att of ["attESHr", "attESSec", "attESg2"]) {
                    assert(glCookie.includes(att));
                }

                assert(options.callCount === AAF_PING_ATTEMPTS);
                /* eslint-disable-next-line no-magic-numbers */
                const [logAttempts] = info.args[2][0].split(": ").reverse();
                assert(logAttempts === AAF_LOCATE_ATTEMPTS.toString());

                /* eslint-disable-next-line no-magic-numbers */
                const [pingAttempts] = info.args[7][0].split(": ").reverse();
                assert(pingAttempts === AAF_PING_ATTEMPTS.toString());

                assert(error.callCount === AAF_PING_ATTEMPTS);
                assert(str(error.firstCall.firstArg) === str(resp));

                /* eslint-disable-next-line no-magic-numbers */
                const [semilastInfo] = info.args[info.callCount - 1 - 1];
                assert(semilastInfo === "Connection refused");

                const { "firstArg": reach } = info.lastCall;
                assert(reach.toLowerCase().includes("ping"));
                assert(reach.toLowerCase().includes("reached"));
            });
        });

        describe("get URLs, 1 ping fail (M) + success", () => {
            afterEach(sinon.restore);
            it("with axios reject", async () => {
                const err = { "response": { "code": "skip" } };
                const resp = { "status": "something" };
                const item = {
                    "hostname": "host", "port": 123, "protocol": "proto"
                };
                const data = { "endpoint": [item] };
                const agent = "agent";
                const info = sinon.spy();
                const error = sinon.spy();

                const ax = require("axios");
                const get = sinon.stub(ax, "get").resolves({ data });

                let options = sinon.stub(ax, "options");
                options = options.onFirstCall().rejects(err);
                options = options.onSecondCall().resolves(resp);

                const mw = require(mwModule);
                const {
                    AAF_LOCATE, AAF_LOCATE_ATTEMPTS, AAF_PING_ATTEMPTS, AAF_URL
                } = mw.constants;
                const getAgent = sinon.stub(
                    mw, "getInsecureAgent"
                ).returns(agent);
                sinon.stub(mw, "getLogger").returns({ error, info });

                const params = {};

                /* eslint-disable-next-line no-extra-parens */
                const expectedUrl = (
                    `${item.protocol}://${item.hostname}:${item.port}`
                );
                assert(expectedUrl === await mw.getAafUrl(params));
                assert(get.calledOnceWith(`${AAF_URL}/${AAF_LOCATE}`));
                const { "lastArg": opts } = get.firstCall;
                assert(opts.httpsAgent === agent);
                assert(getAgent.calledOnce);

                const { "Cookie": glCookie } = opts.headers;
                assert(glCookie !== undefined);
                for (const att of ["attESHr", "attESSec", "attESg2"]) {
                    assert(glCookie.includes(att));
                }

                /* eslint-disable-next-line no-magic-numbers */
                const [logAttempts] = info.args[2][0].split(": ").reverse();
                assert(logAttempts === AAF_LOCATE_ATTEMPTS.toString());

                /* eslint-disable-next-line no-magic-numbers */
                const [pingAttempts] = info.args[7][0].split(": ").reverse();
                assert(pingAttempts === AAF_PING_ATTEMPTS.toString());
                /* eslint-disable-next-line no-magic-numbers */
                assert(options.callCount === AAF_PING_ATTEMPTS - 1);

                // One failed ping
                assert(error.calledOnceWith(err));
                // One success afterwards
                assert(info.lastCall.firstArg.includes(expectedUrl));
            });

            it("with ECONNREFUSED", async () => {
                const err = { "code": "ECONNREFUSED" };
                const resp = { "status": "something" };
                const item = {
                    "hostname": "host", "port": 123, "protocol": "proto"
                };
                const data = { "endpoint": [item] };
                const agent = "agent";
                const info = sinon.spy();
                const error = sinon.spy();

                const ax = require("axios");
                const get = sinon.stub(ax, "get").resolves({ data });

                let options = sinon.stub(ax, "options");
                options = options.onFirstCall().resolves(err);
                options = options.onSecondCall().resolves(resp);

                const mw = require(mwModule);
                const {
                    AAF_LOCATE, AAF_LOCATE_ATTEMPTS, AAF_PING_ATTEMPTS, AAF_URL
                } = mw.constants;
                sinon.stub(mw, "getInsecureAgent").returns(agent);
                sinon.stub(mw, "getLogger").returns({ error, info });

                const params = {};

                /* eslint-disable-next-line no-extra-parens */
                const expectedUrl = (
                    `${item.protocol}://${item.hostname}:${item.port}`
                );
                assert(expectedUrl === await mw.getAafUrl(params));
                assert(get.calledOnceWith(`${AAF_URL}/${AAF_LOCATE}`));
                const { "lastArg": opts } = get.firstCall;
                assert(opts.httpsAgent === agent);

                const { "Cookie": glCookie } = opts.headers;
                assert(glCookie !== undefined);
                for (const att of ["attESHr", "attESSec", "attESg2"]) {
                    assert(glCookie.includes(att));
                }

                /* eslint-disable-next-line no-magic-numbers */
                const [logAttempts] = info.args[2][0].split(": ").reverse();
                assert(logAttempts === AAF_LOCATE_ATTEMPTS.toString());

                /* eslint-disable-next-line no-magic-numbers */
                const [pingAttempts] = info.args[7][0].split(": ").reverse();
                assert(pingAttempts === AAF_PING_ATTEMPTS.toString());
                /* eslint-disable-next-line no-magic-numbers */
                assert(options.callCount === AAF_PING_ATTEMPTS - 1);

                assert(error.calledOnceWith(err));

                /* eslint-disable-next-line no-magic-numbers */
                const [semilastInfo] = info.args[info.callCount - 1 - 4];
                assert(semilastInfo === "Connection refused");

                // One failed ping
                assert(error.calledOnceWith(err));
                // One success afterwards
                assert(info.lastCall.firstArg.includes(expectedUrl));
            });
        });
    });

    describe("getAafUserPermissions()", () => {
        beforeEach(mockLog);
        afterEach(sinon.restore);

        it("should reject invalid username", async () => {
            const mw = require(mwModule);
            sinon.stub(mw, "getAafUrl").resolves("url");

            assert(str(await mw.getAafUserPermissions({
                "username": "a"
            })) === str({
                "message": "Invalid username",
                "perms": [],
                "status": mw.constants.AAF_INVALID_USERNAME
            }));
        });

        it("null as aafUrl", async () => {
            const mw = require(mwModule);
            const expected = {
                "message": undefined,
                "perms": [],
                "status": mw.constants.AAF_NULL_BASE
            };
            const username = "attuid@csp.att.com";
            const permUrl = `${mw.constants.AAF_URL}/authz/perms/user`;

            const get = sinon.stub(mw, "getAafUrl").returns(null);
            const args = {
                "cookies": "c",
                "encoded": "d",
                "password": "b",
                "url": `${permUrl}/${username}`,
                username
            };
            const out = await mw.getAafUserPermissions(args);
            assert(get.calledOnceWith({
                "cookies": args.cookies,
                "encoded": args.encoded,
                "password": args.password,
                username
            }));
            assert(str(expected), str(out));
        });

        it("non-200 status", async () => {
            const mw = require(mwModule);
            const expected = {
                "message": undefined, "perms": [], "status": 401
            };
            const username = "attuid@csp.att.com";
            const permUrl = `${mw.constants.AAF_URL}/authz/perms/user`;

            const get = sinon.stub(mw, "getAafUrl").returns(
                mw.constants.AAF_URL
            );
            const call = sinon.stub(mw, "callAaf").returns({ "status": 401 });
            const args = {
                "cookies": "c",
                "encoded": "d",
                "password": "b",
                "url": `${permUrl}/${username}`,
                username
            };
            const out = await mw.getAafUserPermissions(args);
            assert(get.calledOnceWith({
                "cookies": args.cookies,
                "encoded": args.encoded,
                "password": args.password,
                username
            }));
            assert(call.called);
            assert(call.calledWith(args));
            assert(str(expected), str(out));
        });

        describe("200", () => {
            it("wrong output", async () => {
                const mw = require(mwModule);
                const expected = {
                    "message": undefined,
                    "perms": [],
                    "status": mw.constants.AAF_UNEXPECTED_FORMAT
                };
                const username = "attuid@csp.att.com";
                const permUrl = `${mw.constants.AAF_URL}/authz/perms/user`;

                const get = sinon.stub(mw, "getAafUrl").returns(
                    mw.constants.AAF_URL
                );
                const call = sinon.stub(mw, "callAaf").returns(
                    { "status": 200 }
                );
                const args = {
                    "cookies": "c",
                    "encoded": "d",
                    "password": "b",
                    "url": `${permUrl}/${username}`,
                    username
                };
                const out = await mw.getAafUserPermissions(args);
                assert(get.calledOnceWith({
                    "cookies": args.cookies,
                    "encoded": args.encoded,
                    "password": args.password,
                    username
                }));
                assert(call.called);
                assert(call.calledWith(args));
                assert(str(expected), str(out));
            });

            it("good output", async () => {
                const mw = require(mwModule);
                const per = { "action": "a", "instance": "i", "type": "1" };
                const expected = {
                    "message": undefined,
                    "perms": [per],
                    "status": 200
                };
                const username = "attuid@csp.att.com";
                const permUrl = `${mw.constants.AAF_URL}/authz/perms/user`;

                const get = sinon.stub(mw, "getAafUrl").returns(
                    mw.constants.AAF_URL
                );
                const call = sinon.stub(mw, "callAaf").returns({
                    "data": { "perm": expected.perms },
                    "status": expected.status
                });
                const args = {
                    "cookies": "c",
                    "encoded": "d",
                    "password": "b",
                    "url": `${permUrl}/${username}`,
                    username
                };
                const out = await mw.getAafUserPermissions(args);
                assert(get.calledOnceWith({
                    "cookies": args.cookies,
                    "encoded": args.encoded,
                    "password": args.password,
                    username
                }));
                assert(call.called);
                assert(call.calledWith(args));
                assert(str(expected), str(out));
            });

            it("good output, bad type", async () => {
                const mw = require(mwModule);
                const expected = {
                    "message": undefined,
                    "perms": [],
                    "status": 200
                };
                const username = "attuid@csp.att.com";
                const permUrl = `${mw.constants.AAF_URL}/authz/perms/user`;

                const get = sinon.stub(mw, "getAafUrl").returns(
                    mw.constants.AAF_URL
                );
                const call = sinon.stub(mw, "callAaf").returns({
                    "data": { "perm": null },
                    "status": expected.status
                });
                const args = {
                    "cookies": "c",
                    "encoded": "d",
                    "password": "b",
                    "url": `${permUrl}/${username}`,
                    username
                };
                const out = await mw.getAafUserPermissions(args);
                assert(get.calledOnceWith({
                    "cookies": args.cookies,
                    "encoded": args.encoded,
                    "password": args.password,
                    username
                }));
                assert(call.called);
                assert(call.calledWith(args));
                assert(str(expected), str(out));
            });

            it("missing perms", async () => {
                const mw = require(mwModule);
                const expected = {
                    "message": undefined,
                    "perms": undefined,
                    "status": mw.constants.AAF_UNEXPECTED_FORMAT
                };
                const username = "attuid@csp.att.com";
                const permUrl = `${mw.constants.AAF_URL}/authz/perms/user`;

                const get = sinon.stub(mw, "getAafUrl").returns(
                    mw.constants.AAF_URL
                );
                const call = sinon.stub(mw, "callAaf").returns({
                    "data": { "perm": [] }, "status": 200
                });
                const args = {
                    "cookies": "c",
                    "encoded": "d",
                    "password": "b",
                    "url": `${permUrl}/${username}`,
                    username
                };
                const out = await mw.getAafUserPermissions(args);
                assert(get.calledOnceWith({
                    "cookies": args.cookies,
                    "encoded": args.encoded,
                    "password": args.password,
                    username
                }));
                assert(call.called);
                assert(call.calledWith(args));
                assert(str(expected), str(out));
            });
        });
    });

    describe("cookie auth", () => {
        beforeEach(mockLog);
        afterEach(sinon.restore);

        it("should be used when attESHr cookie is present", () => {
            const mw = require(mwModule);
            const ax = require("axios");
            const mock = sinon.mock(ax);
            const { callAaf } = mw;
            const url = "myurl";

            mock.expects("get").once().withArgs(url, {
                "headers": {
                    "Cookie": "attESHr=value; attESSec=value; attESg2=value"
                },
                "maxRedirects": 0
            });

            callAaf({
                "cookies": {
                    "attESHr": "value",
                    "attESSec": "value",
                    "attESg2": "value"
                },
                url
            });

            mock.verify();
        });
    });

    describe("basic auth", () => {
        beforeEach(mockLog);
        after(sinon.restore);

        it("no cookie present and user+pass+base64 available", () => {
            const mw = require(mwModule);
            const ax = require("axios");
            const mock = sinon.mock(ax);
            const { callAaf } = mw;
            const url = "myurl";

            mock.expects("get").once().withArgs(url, {
                "headers": {
                    "Authorization": "Basic value"
                }
            });

            callAaf({
                "encoded": "value",
                "password": "dummy",
                url,
                "username": "pb548a@csp.att.com"
            });

            mock.verify();
        });
    });

    describe("Options", () => {
        beforeEach(mockLog);

        it("checkPermissions should forbid on missing perms", async () => {
            const mw = require(mwModule);
            const dummy = "test";
            const forbid = sinon.stub(mw, "forbid").returns(dummy);
            const call = sinon.stub(mw, "getAafUserPermissions").resolves({
                "message": "", "perms": [], "status": 200
            });

            const user = "my-attuid";
            const namespace = "csp.att.com";
            const pass = "...";
            const encoded = "bXktYXR0dWlkQGNzcC5hdHQuY29tOi4uLg==";

            const req = {
                "headers": {
                    "authorization": `Basic ${encoded}`
                }
            };
            const res = "response";
            const next = sinon.stub();

            const perms = ["a", "b", "c"];
            const opts = {
                "checkPermissions": true,
                "homeUrl": "home",
                "requiredPermissions": perms
            };
            const result = await mw.aaf(opts)(req, res, next);

            assert(result === dummy);
            assert(call.calledWith({
                "cookies": {},
                encoded,
                "passOnMissingAuth": false,
                "password": pass,
                "username": `${user}@${namespace}`
            }));
            assert(forbid.calledOnceWith(res, opts.homeUrl));
            assert(!next.called);
        });

        it("checkPermissions should next on all perms", async () => {
            const mw = require(mwModule);
            const dummy = "test";
            const forbid = sinon.stub(mw, "forbid");
            const call = sinon.stub(mw, "getAafUserPermissions").resolves({
                "message": "", "perms": ["a", "b", "c"], "status": 200
            });

            const user = "my-attuid";
            const namespace = "csp.att.com";
            const pass = "...";
            const encoded = "bXktYXR0dWlkQGNzcC5hdHQuY29tOi4uLg==";

            const req = {
                "headers": {
                    "authorization": `Basic ${encoded}`
                }
            };
            const res = {};
            const next = sinon.stub().returns(dummy);

            const perms = ["a", "b"];
            const opts = {
                "checkPermissions": true,
                "requiredPermissions": perms
            };
            const result = await mw.aaf(opts)(req, res, next);

            assert(result === dummy);
            assert(call.calledWith({
                "cookies": {},
                encoded,
                "passOnMissingAuth": false,
                "password": pass,
                "username": `${user}@${namespace}`
            }));
            assert(!forbid.called);
            assert(next.calledOnceWith());
        });

        it("setRequestUser should set attuid to req.user", async () => {
            const mw = require(mwModule);
            const call = sinon.stub(mw, "getAafUserPermissions").resolves({
                "message": "", "perms": [], "status": 200
            });

            const dummy = "test";
            const user = "my-attuid";
            const namespace = "csp.att.com";
            const pass = "...";
            const encoded = "bXktYXR0dWlkQGNzcC5hdHQuY29tOi4uLg==";

            const req = {
                "headers": {
                    "authorization": `Basic ${encoded}`
                }
            };
            const res = {};
            const next = sinon.stub().returns(dummy);

            const opts = { "setRequestUser": true };
            const result = await mw.aaf(opts)(req, res, next);

            assert(result === dummy);
            assert(req.user === user);
            assert(req.namespace === namespace);
            assert(call.calledWith({
                "cookies": {},
                encoded,
                "passOnMissingAuth": false,
                "password": pass,
                "username": `${user}@${namespace}`
            }));
            assert(next.called);
        });

        it("setRemoteUser should set remoteUser header", async () => {
            const mw = require(mwModule);
            const call = sinon.stub(mw, "getAafUserPermissions").resolves({
                "message": "", "perms": [], "status": 200
            });

            const dummy = "test";
            const user = "my-attuid";
            const namespace = "csp.att.com";
            const pass = "...";
            const encoded = "bXktYXR0dWlkQGNzcC5hdHQuY29tOi4uLg==";

            const req = {
                "headers": {
                    "authorization": `Basic ${encoded}`
                }
            };
            const res = {};
            const next = sinon.stub().returns(dummy);

            const opts = { "setRemoteUser": true };
            const result = await mw.aaf(opts)(req, res, next);

            assert(result === dummy);
            assert(req.headers.remoteUser === `${user}@${namespace}`);
            assert(call.calledWith({
                "cookies": {},
                encoded,
                "passOnMissingAuth": false,
                "password": pass,
                "username": `${user}@${namespace}`
            }));
            assert(next.called);
        });

        it("!setRequestUser should leave req.user undefined", async () => {
            const mw = require(mwModule);
            const call = sinon.stub(mw, "getAafUserPermissions").resolves({
                "message": "", "perms": [], "status": 200
            });

            const dummy = "test";
            const user = "my-attuid";
            const namespace = "csp.att.com";
            const pass = "...";
            const encoded = "bXktYXR0dWlkQGNzcC5hdHQuY29tOi4uLg==";

            const req = {
                "headers": {
                    "authorization": `Basic ${encoded}`
                }
            };
            const res = {};
            const next = sinon.stub().returns(dummy);

            const opts = { "setRequestUser": false };
            const result = await mw.aaf(opts)(req, res, next);

            assert(result === dummy);
            assert(req.user === undefined);
            assert(req.namespace === undefined);
            assert(call.calledWith({
                "cookies": {},
                encoded,
                "passOnMissingAuth": false,
                "password": pass,
                "username": `${user}@${namespace}`
            }));
            assert(next.called);
        });
    });

    describe("aafSetRequestUser()", () => {
        beforeEach(mockLog);

        it("falsy setRequestUser just skips", () => {
            const req = {};
            const user = "user";
            const aafns = "namespace";
            const username = `${user}@${aafns}`;

            const mw = require(mwModule);
            assert(str(req) === "{}");
            assert(undefined === mw.aafSetRequestUser(req, username, {}));
            assert(str(req) === "{}");
        });

        describe("truthy setRequestUser", () => {
            it("got username with namespace", () => {
                const req = {};
                const user = "user";
                const aafns = "namespace";
                const username = `${user}@${aafns}`;
                const expected = { "namespace": aafns, user };

                const mw = require(mwModule);

                assert(str(req) === "{}");
                assert(undefined === mw.aafSetRequestUser(
                    req, username, { "setRequestUser": true }
                ));
                assert(str(req) === str(expected));
            });

            it("got username without @ (length 1)", () => {
                const req = {};
                const user = "user";

                const mw = require(mwModule);

                assert(str(req) === "{}");
                assert(undefined === mw.aafSetRequestUser(
                    req, user, { "setRequestUser": true }
                ));
                assert(str(req) === str({ "namespace": "", user }));
            });

            it("got username only", () => {
                const req = {};
                const user = "user";
                const expected = { "namespace": "", user };

                const mw = require(mwModule);

                assert(str(req) === "{}");
                assert(undefined === mw.aafSetRequestUser(
                    req, user, { "setRequestUser": true }
                ));
                assert(str(req) === str(expected));
            });

            it("empty username (split array)", () => {
                const req = {};
                const username = "";
                const expected = { "namespace": "", "user": "" };

                const mw = require(mwModule);

                assert(str(req) === "{}");
                assert(undefined === mw.aafSetRequestUser(
                    req, username, { "setRequestUser": true }
                ));
                assert(str(req) === str(expected));
            });
        });
    });

    describe("aaf()", () => {
        beforeEach(mockLog);
        afterEach(sinon.restore);

        it("handle reject from getAafUserPermissions()", async () => {
            const err = "dummy-error";
            const handled = "dummy";
            const req = {
                "headers": {
                    /* eslint-disable-next-line no-extra-parens */
                    "authorization": (
                        "Basic YXR0dWlkQGNzcC5hdHQuY29tOnNvbWV0aGluZw=="
                    ),
                    "cookie": ""
                }
            };
            const res = "response obj";
            const next = sinon.spy();

            const mw = require(mwModule);
            sinon.stub(mw, "getAafUserPermissions").rejects(err);
            const handle = sinon.stub(
                mw, "handleAafReject"
            ).returns(handled);

            assert(await mw.aaf()(req, res, next) === handled);
            assert(!next.called);

            assert(handle.calledOnce);
            const [first, second, last] = handle.firstCall.args;
            assert(first.name === err);
            assert(second === res);
            assert(last === mw.aafDefaultConfig);
        });

        it("forbid on non-200 from getAafUserPermissions()", async () => {
            const data = { "status": 0 };
            const handled = "dummy";

            const req = {
                "headers": {
                    /* eslint-disable-next-line no-extra-parens */
                    "authorization": (
                        "Basic YXR0dWlkQGNzcC5hdHQuY29tOnNvbWV0aGluZw=="
                    ),
                    "cookie": ""
                }
            };
            const res = "response obj";
            const next = sinon.spy();

            const mw = require(mwModule);
            const forbid = sinon.stub(mw, "forbid").returns(handled);
            sinon.stub(mw, "getAafUserPermissions").resolves(data);
            const handle = sinon.stub(mw, "handleAafReject");

            assert(await mw.aaf()(req, res, next) === handled);
            assert(!next.called);
            assert(!handle.called);
            assert(forbid.calledOnceWith(res, mw.aafDefaultConfig.homeUrl));
        });

        it("rejectGlobalLogon calls redir to custom url", async () => {
            const dummy = "dummy";
            const req = {
                "headers": {
                    /* eslint-disable-next-line no-extra-parens */
                    "authorization": (
                        "Basic YXR0dWlkQGNzcC5hdHQuY29tOnNvbWV0aGluZw=="
                    ),
                    "cookie": ""
                }
            };
            const res = "response";
            const next = sinon.spy();
            const mw = require(mwModule);
            const forbid = sinon.stub(mw, "forbid").returns(dummy);
            const setRequestUser = sinon.stub(mw, "aafSetRequestUser");
            const get = sinon.stub(mw, "getAafUserPermissions");
            const url = "hello";
            assert(await mw.aaf({
                "rejectGlobalLogon": url
            })(req, res, next) === dummy);
            assert(!get.called);
            assert(!next.called);
            assert(forbid.calledOnceWith(res, url));
            assert(!setRequestUser.called);
        });

        it("rejectGlobalLogon calls forbid on csp.att.com", async () => {
            const dummy = "dummy";
            const req = {
                "headers": {
                    /* eslint-disable-next-line no-extra-parens */
                    "authorization": (
                        "Basic YXR0dWlkQGNzcC5hdHQuY29tOnNvbWV0aGluZw=="
                    ),
                    "cookie": ""
                }
            };
            const res = "response";
            const next = sinon.spy();
            const mw = require(mwModule);
            const forbid = sinon.stub(mw, "forbid").returns(dummy);
            const setRequestUser = sinon.stub(mw, "aafSetRequestUser");
            const get = sinon.stub(mw, "getAafUserPermissions");
            assert(await mw.aaf({
                "rejectGlobalLogon": true
            })(req, res, next) === dummy);
            assert(!get.called);
            assert(!next.called);
            assert(forbid.calledOnceWith(res));
            assert(!setRequestUser.called);
        });

        it("rejectGlobalLogon calls forbid on GL cookie", async () => {
            const dummy = "dummy";
            const cookie = "hi";
            const req = { "headers": { cookie } };
            const res = "response";
            const next = sinon.spy();
            const mw = require(mwModule);
            const user = "hello";
            const resolve = sinon.stub(mw, "resolveCookies").returns({
                "attESHr": user
            });
            const parse = sinon.stub(mw, "parseEshr").returns(user);
            const forbid = sinon.stub(mw, "forbid").returns(dummy);
            const setRequestUser = sinon.stub(mw, "aafSetRequestUser");
            const get = sinon.stub(mw, "getAafUserPermissions");
            assert(await mw.aaf({
                "rejectGlobalLogon": true
            })(req, res, next) === dummy);
            assert(resolve.calledOnceWith(cookie));
            assert(parse.calledOnceWith(user));
            assert(!get.called);
            assert(!next.called);
            assert(forbid.calledOnceWith(res));
            assert(!setRequestUser.called);
        });

        it("forbid on missing auth", async () => {
            const dummy = "dummy";
            const cookie = "hi";
            const req = { "headers": { cookie } };
            const res = "response";
            const next = sinon.spy();
            const mw = require(mwModule);
            const user = "hello";
            const resolve = sinon.stub(mw, "resolveCookies").returns({});
            const parse = sinon.stub(mw, "parseEshr").returns(user);
            const forbid = sinon.stub(mw, "forbid").returns(dummy);
            const setRequestUser = sinon.stub(mw, "aafSetRequestUser");
            const get = sinon.stub(mw, "getAafUserPermissions");
            assert(await mw.aaf({
                "rejectGlobalLogon": true
            })(req, res, next) === dummy);
            assert(resolve.calledOnceWith(cookie));
            assert(!parse.called);
            assert(!get.called);
            assert(!next.called);
            assert(forbid.calledOnceWith(res));
            assert(!setRequestUser.called);
        });

        describe("using cached results", () => {
            it("setRemoteUser from cache", async () => {
                require("lru-cache");
                const dummy = "dummy";
                const data = { "status": 0 };
                const req = {
                    "headers": {
                        /* eslint-disable-next-line no-extra-parens */
                        "authorization": (
                            "Basic YXR0dWlkQGNzcC5hdHQuY29tOnNvbWV0aGluZw=="
                        ),
                        "cookie": ""
                    }
                };
                const next = sinon.stub().returns(dummy);
                const dummyCache = {
                    "get": sinon.stub().returns(data)
                };
                const user = "attuid@csp.att.com";
                sinon.stub(
                    require.cache[require.resolve("lru-cache")], "exports"
                ).returns(dummyCache);
                const mw = require(mwModule);
                const forbid = sinon.stub(mw, "forbid");
                const setRequestUser = sinon.stub(mw, "aafSetRequestUser");
                const get = sinon.stub(mw, "getAafUserPermissions");
                assert(await mw.aaf({
                    "setRemoteUser": true
                })(req, {}, next) === dummy);
                assert(!get.called);
                assert(!forbid.called);
                assert(req.headers.remoteUser === user);
                assert(setRequestUser.calledOnceWith(
                    req, user, mw.aafDefaultConfig
                ));
                assert(next.calledOnceWith());
            });

            it("checkPermissions from cache", async () => {
                require("lru-cache");
                const dummy = "dummy";
                const data = {
                    "perms": ["x"],
                    "status": 0
                };
                const req = {
                    "headers": {
                        /* eslint-disable-next-line no-extra-parens */
                        "authorization": (
                            "Basic YXR0dWlkQGNzcC5hdHQuY29tOnNvbWV0aGluZw=="
                        ),
                        "cookie": ""
                    }
                };
                const next = sinon.stub().returns(dummy);
                const dummyCache = {
                    "get": sinon.stub().returns(data)
                };
                sinon.stub(
                    require.cache[require.resolve("lru-cache")], "exports"
                ).returns(dummyCache);
                const mw = require(mwModule);
                const forbid = sinon.stub(mw, "forbid");
                const setRequestUser = sinon.stub(mw, "aafSetRequestUser");
                const get = sinon.stub(mw, "getAafUserPermissions");
                assert(await mw.aaf({
                    "checkPermissions": true,
                    "requiredPermissions": ["x"]
                })(req, {}, next) === dummy);
                assert(!get.called);
                assert(!forbid.called);
                assert(setRequestUser.calledOnceWith(
                    req, "attuid@csp.att.com", mw.aafDefaultConfig
                ));
                assert(next.calledOnceWith());
            });

            it("checkPermissions + forbid from cache", async () => {
                require("lru-cache");
                const dummy = "dummy";
                const data = {
                    "perms": [],
                    "status": 0
                };
                const req = {
                    "headers": {
                        /* eslint-disable-next-line no-extra-parens */
                        "authorization": (
                            "Basic YXR0dWlkQGNzcC5hdHQuY29tOnNvbWV0aGluZw=="
                        ),
                        "cookie": ""
                    }
                };
                const res = "response";
                const next = sinon.spy();
                const dummyCache = {
                    "get": sinon.stub().returns(data)
                };
                sinon.stub(
                    require.cache[require.resolve("lru-cache")], "exports"
                ).returns(dummyCache);
                const mw = require(mwModule);
                const forbid = sinon.stub(mw, "forbid").returns(dummy);
                const setRequestUser = sinon.stub(mw, "aafSetRequestUser");
                const get = sinon.stub(mw, "getAafUserPermissions");
                assert(await mw.aaf({
                    "checkPermissions": true,
                    "requiredPermissions": ["x"]
                })(req, res, next) === dummy);
                assert(!get.called);
                assert(!next.called);
                const { "aafDefaultConfig": def } = mw;
                assert(forbid.calledOnceWith(res, def.homeUrl));
                assert(!setRequestUser.called);
            });
        });
    });
});


describe("AAF Middleware configuration", () => {
    beforeEach(mockLog);

    describe("incorrect middleware usage", () => {
        it("should fail as func reference", () => {
            const mw = require(mwModule);

            /**
             * It uses func() to return a function with a proper config,
             * therefore should fail when using the config wrapper directly.
             */
            const wrapper = mw.aaf;

            // Treating wrapper as middleware
            const fail = wrapper("req", "res", "next");
            assert(typeof fail === "function");
        });
    });

    it("should set default config with no options", () => {
        const mw = require(mwModule);
        // Aaf is a func wrapper
        const wrapper = mw.aaf;

        // Func is passed into express.use()
        /* eslint-disable-next-line no-inline-comments */
        const func = wrapper(/* No options */);

        // Result is retrieved when mw is called in request pipeline
        /* eslint-disable-next-line no-inline-comments */
        const result = func(/* No req, res, next */);

        // The options have to match
        assert(str(result) === str(mw.aafDefaultConfig));
    });

    it("should have default config overwritten", () => {
        const mw = require(mwModule);
        /* eslint-disable sort-keys */
        const options = {
            "checkPermissions": "test",
            "debug": "test",
            "homeUrl": "test",
            "passOnMissingAuth": "test",
            "rejectGlobalLogon": "test",
            "requiredPermissions": "test",
            "setRemoteUser": "test",
            "setRequestUser": "test"
        };
        /* eslint-enable sort-keys */

        const wrapper = mw.aaf;
        const func = wrapper(options);

        /* eslint-disable-next-line no-inline-comments */
        const result = func(/* No req, res, next */);

        assert(str(result) === str(options));
    });
});


describe("UPM Middleware configuration", () => {
    beforeEach(mockLog);

    describe("incorrect middleware usage", () => {
        it("should fail as func reference", () => {
            const mw = require(mwModule);

            /**
             * It uses func() to return a function with a proper config,
             * therefore should fail when using the config wrapper directly.
             */
            const wrapper = mw.upm;

            // Treating wrapper as middleware
            const fail = wrapper("req", "res", "next");
            assert(typeof fail === "function");
        });
    });

    it("should set default config with no options", () => {
        const mw = require(mwModule);
        // Upm is a func wrapper
        const wrapper = mw.upm;

        // Func is passed into express.use()
        /* eslint-disable-next-line no-inline-comments */
        const func = wrapper(/* No options */);

        // Result is retrieved when mw is called in request pipeline
        /* eslint-disable-next-line no-inline-comments */
        const result = func(/* No req, res, next */);

        // The options have to match
        assert(str(result) === str(mw.upmDefaultConfig));
    });

    it("should have default config overwritten", () => {
        const mw = require(mwModule);
        /* eslint-disable sort-keys */
        const options = {
            "appId": "test",
            "cache": "test",
            "checkLevels": "test",
            "debug": "test",
            "homeUrl": "test",
            "passOnMissing": "test",
            "requiredLevels": "test",
            "setRequestLevels": "test"
        };
        /* eslint-enable sort-keys */

        const wrapper = mw.upm;
        const func = wrapper(options);

        /* eslint-disable-next-line no-inline-comments */
        const result = func(/* No req, res, next */);

        assert(str(result) === str(options));
    });
});


describe("X-Authorization middleware", () => {
    beforeEach(mockLog);

    afterEach(sinon.restore);

    it("should rewrite Authorization when X-Authorization is present", () => {
        const mw = require(mwModule);
        const xAuth = "xauth";
        const auth = "auth";
        const next = sinon.stub();

        const request = {
            "headers": {
                "authorization": auth,
                "x-authorization": xAuth
            }
        };

        assert(mw.xAuthorization()(request, null, next) === undefined);
        assert(request.headers.authorization === xAuth);
        assert(request.headers["x-authorization"] === xAuth);

        /* eslint-disable-next-line no-inline-comments */
        assert(next.calledWith(/* No args */));
    });

    it("should create Authorization when missing", () => {
        const mw = require(mwModule);
        const xAuth = "xauth";
        const next = sinon.stub();

        const request = { "headers": { "x-authorization": xAuth } };

        assert(mw.xAuthorization()(request, null, next) === undefined);
        assert(request.headers.authorization === xAuth);
        assert(request.headers["x-authorization"] === xAuth);

        /* eslint-disable-next-line no-inline-comments */
        assert(next.calledWith(/* No args */));
    });

    it("should not rewrite Authorization with missing X-Authorization", () => {
        const mw = require(mwModule);
        const auth = "auth";
        const next = sinon.stub();

        const request = { "headers": { "authorization": auth } };

        assert(mw.xAuthorization()(request, null, next) === undefined);
        assert(request.headers.authorization === auth);
        assert(request.headers["x-authorization"] === undefined);

        /* eslint-disable-next-line no-inline-comments */
        assert(next.calledWith(/* No args */));
    });
});


describe("Insecure HTTPS agent", () => {
    beforeEach(mockLog);

    afterEach(sinon.restore);

    it("should allow internal unverified certs", () => {
        const mw = require(mwModule);
        assert(!mw.getInsecureAgent().rejectUnauthorized);
    });
});


describe("UPM API call", () => {
    beforeEach(mockLog);

    it("callUpm() should call UPM with appId and attuid", async () => {
        const ax = require("axios");
        const resp = "yes";
        const params = { "appId": 123, "attuid": "some attuid" };
        const stub = sinon.stub(ax, "get").resolves(resp);
        const agent = "agent";

        const mw = require(mwModule);
        sinon.stub(mw, "getInsecureAgent").returns(agent);
        const url = mw.constants.UPM_URL;

        assert(await mw.callUpm(params) === resp);
        assert(stub.calledWith(
            `${url}/user/${params.attuid}/application/${params.appId}`,
            { "httpsAgent": agent }
        ));
    });

    describe("getUpmLevels()", () => {
        afterEach(sinon.restore);

        it("should reject on missing appId & attuid", async () => {
            const mw = require(mwModule);
            const result = await mw.getUpmLevels({});
            assert(str(result) === str({
                "levels": [],
                "message": "",
                "status": mw.constants.UPM_MISSING_APP_ID
            }));
        });

        it("should reject on missing appId", async () => {
            const mw = require(mwModule);
            const result = await mw.getUpmLevels({
                "attuid": "test"
            });
            assert(str(result) === str({
                "levels": [],
                "message": "",
                "status": mw.constants.UPM_MISSING_APP_ID
            }));
        });

        it("should reject on missing attuid", async () => {
            const mw = require(mwModule);
            const result = await mw.getUpmLevels({
                "appId": 123
            });
            assert(str(result) === str({
                "levels": [],
                "message": "",
                "status": mw.constants.UPM_MISSING_ATTUID
            }));
        });

        it("non-200 status", async () => {
            const mw = require(mwModule);
            const expected = {
                "levels": [], "message": undefined, "status": 401
            };

            const call = sinon.stub(mw, "callUpm").rejects({
                "response": { "status": expected.status }
            });
            const args = { "appId": 123, "attuid": "yes" };
            const out = await mw.getUpmLevels(args);
            assert(call.called);
            assert(call.calledWith(args));
            assert(str(expected) === str(out));
        });

        it("200, but wrong output", async () => {
            const mw = require(mwModule);
            const expected = {
                "levels": [],
                "message": "",
                "status": mw.constants.UPM_UNEXPECTED_FORMAT
            };

            const call = sinon.stub(mw, "callUpm").resolves({
                "data": "not good", "status": 200, "text": "not good"
            });
            const args = { "appId": 123, "attuid": "yes" };
            const out = await mw.getUpmLevels(args);
            assert(call.called);
            assert(call.calledWith(args));
            assert(str(expected) === str(out));
        });

        it("200 and good output", async () => {
            const mw = require(mwModule);
            const expected = {
                "levels": [
                    {
                        "level": "1",
                        "levelDescription": "No access will be granted.",
                        "levelName": "ADMIN",
                        "modify": "yes"
                    },
                    {
                        "level": "26",
                        "levelDescription": "Level for the Organization",
                        "levelName": "Organization",
                        "modify": "no"
                    }
                ],
                "message": "",
                "status": 200
            };

            const call = sinon.stub(mw, "callUpm").returns({
                "data": {
                    // Yes, double "data", one as Axios attr, one from UPM
                    "data": {
                        "applications": {
                            "123": {
                                /* eslint-disable-next-line no-magic-numbers */
                                "1": expected.levels[0],
                                /* eslint-disable-next-line no-magic-numbers */
                                "26": expected.levels[1]
                            }
                        },
                        "attuid": "yes"
                    }
                },
                "status": expected.status
            });
            const args = { "appId": 123, "attuid": "yes" };
            const out = await mw.getUpmLevels(args);
            assert(call.called);
            assert(call.calledWith(args));
            assert(str(expected) === str(out));
        });
    });

    describe("upm()", () => {
        afterEach(sinon.restore);

        it("handle reject from getUpmLevels()", async () => {
            const err = "dummy-error";
            const handled = "dummy";
            const req = {
                "headers": {}
            };
            const res = "response obj";
            const next = sinon.spy();

            const mw = require(mwModule);
            sinon.stub(mw, "getUpmLevels").rejects(err);
            const handle = sinon.stub(mw, "handleUpmReject").returns(handled);

            assert(await mw.upm()(req, res, next) === handled);
            assert(!next.called);

            assert(handle.calledOnce);
            const [first, second, last] = handle.firstCall.args;
            assert(first.name === err);
            assert(second === res);
            assert(last === mw.upmDefaultConfig);
        });

        it("forbid on 404 from getUpmLevels()", async () => {
            const dummy = "dummy";
            const res = "response";
            const next = sinon.spy();

            const mw = require(mwModule);
            const forbid = sinon.stub(mw, "forbid").returns(dummy);
            const data = {
                "levels": [],
                "message": "",
                "status": mw.constants.HTTP_NOT_FOUND
            };
            sinon.stub(mw, "getUpmLevels").resolves(data);

            assert(await mw.upm({
                "checkLevels": true,
                "requiredLevels": ["x"]
            })({ "headers": {} }, res, next) === dummy);
            assert(forbid.calledOnceWith(res, mw.upmDefaultConfig.homeUrl));
        });

        it("forbid non-200 from getUpmLevels()", async () => {
            const dummy = "dummy";
            const res = "response";
            const next = sinon.spy();

            const mw = require(mwModule);
            const forbid = sinon.stub(mw, "forbid").returns(dummy);
            const data = {
                "levels": [],
                "message": "",
                "status": mw.constants.HTTP_FOUND
            };
            sinon.stub(mw, "getUpmLevels").resolves(data);

            assert(await mw.upm({
                "checkLevels": true,
                "requiredLevels": ["x"]
            })({ "headers": {} }, res, next) === dummy);
            assert(forbid.calledOnceWith(res, mw.upmDefaultConfig.homeUrl));
        });

        it("pass on missing levels from getUpmLevels()", async () => {
            const dummy = "dummy";
            const res = "response";
            const next = sinon.stub().returns(dummy);

            const mw = require(mwModule);
            const forbid = sinon.stub(mw, "forbid");
            const data = {
                "levels": ["y"],
                "message": "",
                "status": mw.constants.HTTP_OK
            };
            sinon.stub(mw, "getUpmLevels").resolves(data);

            assert(await mw.upm({
                "checkLevels": true,
                "passOnMissing": true,
                "requiredLevels": ["x"]
            })({ "headers": {} }, res, next) === dummy);
            assert(!forbid.called);
            assert(next.calledOnceWith());
        });

        describe("using cached results", () => {
            it("setRequestLevels from cache", async () => {
                require("lru-cache");
                const level = { "level": 0, "levelName": "llama" };
                const data = {
                    "levels": [level],
                    "status": 200
                };
                const req = { "headers": {} };
                const dummy = "dummy";
                const dummyCache = {
                    "get": sinon.stub().returns(data)
                };
                sinon.stub(
                    require.cache[require.resolve("lru-cache")], "exports"
                ).returns(dummyCache);
                const mw = require(mwModule);
                const get = sinon.stub(mw, "getUpmLevels");
                const next = sinon.stub().returns(dummy);
                const forbid = sinon.stub(mw, "forbid");
                assert(await mw.upm({
                    "setRequestLevels": true
                })(req, {}, next) === dummy);
                assert(!get.called);
                assert(next.calledOnceWith());
                assert(!forbid.called);
                const idLevels = { "0": level };
                const nameLevels = { "llama": level };
                assert(str(req.upmIdLevels) === str(idLevels));
                assert(str(req.upmNameLevels) === str(nameLevels));
            });

            it("just pass from cache", async () => {
                require("lru-cache");
                const level = { "level": 0, "levelName": "llama" };
                const data = {
                    "levels": [level],
                    "status": 200
                };
                const req = { "headers": {} };
                const dummy = "dummy";
                const dummyCache = {
                    "get": sinon.stub().returns(data)
                };
                sinon.stub(
                    require.cache[require.resolve("lru-cache")], "exports"
                ).returns(dummyCache);
                const mw = require(mwModule);
                const get = sinon.stub(mw, "getUpmLevels");
                const next = sinon.stub().returns(dummy);
                const forbid = sinon.stub(mw, "forbid");
                assert(await mw.upm({
                    "setRequestLevels": false
                })(req, {}, next) === dummy);
                assert(!get.called);
                assert(next.calledOnceWith());
                assert(!forbid.called);
                assert(req.upmIdLevels === undefined);
                assert(req.upmNameLevels === undefined);
            });

            it("forbid on 404 from cache", async () => {
                require("lru-cache");
                const data = {
                    "levels": [],
                    "message": "",
                    "status": 404
                };
                const dummyCache = {
                    "get": sinon.stub().returns(data)
                };
                const cache = sinon.stub(
                    require.cache[require.resolve("lru-cache")], "exports"
                ).returns(dummyCache);

                const dummy = "dummy";
                const res = "response";
                const next = sinon.spy();
                const user = "my-user";

                const mw = require(mwModule);
                const forbid = sinon.stub(mw, "forbid").returns(dummy);
                sinon.stub(mw, "getUpmLevels").resolves(data);

                assert(await mw.upm()({
                    "headers": {}, user
                }, res, next) === dummy);
                assert(cache.calledOnceWith({ "max": 128 }));
                assert(dummyCache.get.calledOnceWith(user));
                assert(forbid.calledOnceWith(res, mw.upmDefaultConfig.homeUrl));
                assert(!next.called);
            });

            it("pass on 404 from cache", async () => {
                require("lru-cache");
                const data = {
                    "levels": [],
                    "message": "",
                    "status": 404
                };
                const dummyCache = {
                    "get": sinon.stub().returns(data)
                };
                const cache = sinon.stub(
                    require.cache[require.resolve("lru-cache")], "exports"
                ).returns(dummyCache);

                const dummy = "dummy";
                const res = "response";
                const next = sinon.stub().returns(dummy);
                const user = "my-user";

                const mw = require(mwModule);
                const forbid = sinon.stub(mw, "forbid");
                sinon.stub(mw, "getUpmLevels").resolves(data);

                assert(await mw.upm({
                    "passOnMissing": true
                })({ "headers": {}, user }, res, next) === dummy);
                assert(cache.calledOnceWith({ "max": 128 }));
                assert(dummyCache.get.calledOnceWith(user));
                assert(!forbid.called);
                assert(next.calledOnceWith());
            });

            it("non-200 from cache", async () => {
                require("lru-cache");
                const data = {
                    "levels": [],
                    "message": "",
                    "status": 201
                };
                const dummyCache = {
                    "get": sinon.stub().returns(data)
                };
                const cache = sinon.stub(
                    require.cache[require.resolve("lru-cache")], "exports"
                ).returns(dummyCache);

                const dummy = "dummy";
                const res = "response";
                const next = sinon.spy();
                const user = "my-user";

                const mw = require(mwModule);
                const forbid = sinon.stub(mw, "forbid").returns(dummy);
                sinon.stub(mw, "getUpmLevels").resolves(data);

                assert(await mw.upm()({
                    "headers": {}, user
                }, res, next) === dummy);
                assert(cache.calledOnceWith({ "max": 128 }));
                assert(dummyCache.get.calledOnceWith(user));
                assert(forbid.calledOnceWith(res, mw.upmDefaultConfig.homeUrl));
                assert(!next.called);
            });

            it("checkLevels from cache with match", async () => {
                require("lru-cache");
                const data = {
                    "levels": ["x"],
                    "message": "",
                    "status": 200
                };
                const dummyCache = {
                    "get": sinon.stub().returns(data)
                };
                const cache = sinon.stub(
                    require.cache[require.resolve("lru-cache")], "exports"
                ).returns(dummyCache);

                const dummy = "dummy";
                const res = "response";
                const next = sinon.stub().returns(dummy);
                const user = "my-user";

                const mw = require(mwModule);
                const forbid = sinon.stub(mw, "forbid");
                sinon.stub(mw, "getUpmLevels").resolves(data);

                assert(await mw.upm({
                    "checkLevels": true,
                    "requiredLevels": ["x"]
                })({ "headers": {}, user }, res, next) === dummy);
                assert(cache.calledOnceWith({ "max": 128 }));
                assert(dummyCache.get.calledOnceWith(user));
                assert(!forbid.called);
                assert(next.called);
            });

            it("checkLevels from cache without match", async () => {
                require("lru-cache");
                const data = {
                    "levels": [],
                    "message": "",
                    "status": 200
                };
                const dummyCache = {
                    "get": sinon.stub().returns(data)
                };
                const cache = sinon.stub(
                    require.cache[require.resolve("lru-cache")], "exports"
                ).returns(dummyCache);

                const dummy = "dummy";
                const res = "response";
                const next = sinon.spy();
                const user = "my-user";

                const mw = require(mwModule);
                const forbid = sinon.stub(mw, "forbid").returns(dummy);
                sinon.stub(mw, "getUpmLevels").resolves(data);

                assert(await mw.upm({
                    "checkLevels": true,
                    "requiredLevels": ["x"]
                })({ "headers": {}, user }, res, next) === dummy);
                assert(cache.calledOnceWith({ "max": 128 }));
                assert(dummyCache.get.calledOnceWith(user));
                assert(forbid.calledOnceWith(res, mw.upmDefaultConfig.homeUrl));
                assert(!next.called);
            });

            it("checkLevels from cache without match + pass", async () => {
                require("lru-cache");
                const data = {
                    "levels": [],
                    "message": "",
                    "status": 200
                };
                const dummyCache = {
                    "get": sinon.stub().returns(data)
                };
                const cache = sinon.stub(
                    require.cache[require.resolve("lru-cache")], "exports"
                ).returns(dummyCache);

                const dummy = "dummy";
                const res = "response";
                const next = sinon.stub().returns(dummy);
                const user = "my-user";

                const mw = require(mwModule);
                const forbid = sinon.stub(mw, "forbid");
                sinon.stub(mw, "getUpmLevels").resolves(data);

                assert(await mw.upm({
                    "checkLevels": true,
                    "passOnMissing": true,
                    "requiredLevels": ["x"]
                })({ "headers": {}, user }, res, next) === dummy);
                assert(cache.calledOnceWith({ "max": 128 }));
                assert(dummyCache.get.calledOnceWith(user));
                assert(!forbid.called);
                assert(next.calledOnceWith());
            });
        });
    });

    describe("Cookie auth", () => {
        afterEach(sinon.restore);

        it("should be used when attESHr cookie is present", () => {
            const mw = require(mwModule);
            const ax = require("axios");
            const mock = sinon.mock(ax);
            const { callAaf } = mw;
            const url = "myurl";

            mock.expects("get").once().withArgs(url, {
                "headers": {
                    "Cookie": "attESHr=value; attESSec=value; attESg2=value"
                },
                "maxRedirects": 0
            });

            callAaf({
                "cookies": {
                    "attESHr": "value",
                    "attESSec": "value",
                    "attESg2": "value"
                },
                url
            });

            mock.verify();
        });
    });

    describe("Basic auth", () => {
        after(sinon.restore);

        it("no cookie present and user+pass+base64 available", () => {
            const mw = require(mwModule);
            const ax = require("axios");
            const mock = sinon.mock(ax);
            const { callAaf } = mw;
            const url = "myurl";

            mock.expects("get").once().withArgs(url, {
                "headers": {
                    "Authorization": "Basic value"
                }
            });

            callAaf({
                "encoded": "value",
                "password": "dummy",
                url,
                "username": "pb548a@csp.att.com"
            });

            mock.verify();
        });
    });

    describe("Options", () => {
        it("setRequestLevels & passOnMissing return empty arrays", async () => {
            const mw = require(mwModule);
            const call = sinon.stub(mw, "getUpmLevels").resolves({
                "levels": [], "message": "", "status": 200
            });

            const dummy = "test";
            const user = "some-username";
            const app = 999999;

            const req = { "headers": {}, user };
            const res = {};
            const next = sinon.stub().returns(dummy);

            const opts = {
                "appId": app, "passOnMissing": true, "setRequestLevels": true
            };
            const result = await mw.upm(opts)(req, res, next);

            assert(result === dummy);
            assert(str(req.upmLevels) === str([]));
            assert(str(req.upmIdLevels) === str({}));
            assert(str(req.upmNameLevels) === str({}));
            assert(call.calledWith({ "appId": app, "attuid": user }));
            assert(next.called);
        });

        it("levels & pass on 404 return empty arrays", async () => {
            const mw = require(mwModule);
            const call = sinon.stub(mw, "getUpmLevels").resolves({
                "levels": [], "message": "some-message", "status": 404
            });

            const dummy = "test";
            const user = "some-username";
            const app = 999999;

            const req = { "headers": {}, user };
            const res = {};
            const next = sinon.stub().returns(dummy);

            const opts = {
                "appId": app, "passOnMissing": true, "setRequestLevels": true
            };
            const result = await mw.upm(opts)(req, res, next);

            assert(result === dummy);
            assert(str(req.upmLevels) === str([]));
            assert(str(req.upmIdLevels) === str({}));
            assert(str(req.upmNameLevels) === str({}));
            assert(call.calledWith({ "appId": app, "attuid": user }));
            assert(next.called);
        });

        it("!setRequestLevels & passOnMissing passes on empty", async () => {
            const mw = require(mwModule);
            const call = sinon.stub(mw, "getUpmLevels").resolves({
                "levels": [], "message": "", "status": 200
            });

            const dummy = "test";
            const user = "some-username";
            const app = 999999;

            const req = { "headers": {}, user };
            const res = {};
            const next = sinon.stub().returns(dummy);

            const opts = {
                "appId": app, "passOnMissing": true, "setRequestLevels": false
            };
            const result = await mw.upm(opts)(req, res, next);

            assert(result === dummy);
            assert(req.upmLevels === undefined);
            assert(req.upmIdLevels === undefined);
            assert(req.upmNameLevels === undefined);
            assert(call.calledWith({ "appId": app, "attuid": user }));
            assert(next.called);
        });

        it("!levels & pass with 404 passes on empty", async () => {
            const mw = require(mwModule);
            const call = sinon.stub(mw, "getUpmLevels").resolves({
                "levels": [], "message": "some-message", "status": 404
            });

            const dummy = "test";
            const user = "some-username";
            const app = 999999;

            const req = { "headers": {}, user };
            const res = {};
            const next = sinon.stub().returns(dummy);

            const opts = {
                "appId": app, "passOnMissing": true, "setRequestLevels": false
            };
            const result = await mw.upm(opts)(req, res, next);

            assert(result === dummy);
            assert(req.upmLevels === undefined);
            assert(req.upmIdLevels === undefined);
            assert(req.upmNameLevels === undefined);
            assert(call.calledWith({ "appId": app, "attuid": user }));
            assert(next.called);
        });

        it("checkLevels + matching, without cache", async () => {
            const dummy = "dummy";
            const next = sinon.stub().returns(dummy);

            const mw = require(mwModule);
            const data = {
                "levels": ["x"],
                "message": "",
                "status": mw.constants.HTTP_OK
            };
            const getUpmLevels = sinon.stub(mw, "getUpmLevels").resolves(data);

            const appId = 123;
            const user = "hello";
            assert(await mw.upm({
                appId,
                "checkLevels": true,
                "requiredLevels": ["x"]
            })({ "headers": {}, user }, {}, next) === dummy);
            assert(next.called);
            assert(getUpmLevels.calledOnceWith({ appId, "attuid": user }));
        });

        it("checkLevels + not matching, without cache", async () => {
            const dummy = "dummy";
            const res = "response";
            const next = sinon.spy();

            const mw = require(mwModule);
            const forbid = sinon.stub(mw, "forbid").returns(dummy);
            const data = {
                "levels": [],
                "message": "",
                "status": mw.constants.HTTP_OK
            };
            const getUpmLevels = sinon.stub(mw, "getUpmLevels").resolves(data);

            const appId = 123;
            const user = "hello";
            assert(await mw.upm({
                appId,
                "checkLevels": true,
                "requiredLevels": ["x"]
            })({ "headers": {}, user }, res, next) === dummy);
            assert(forbid.calledOnceWith(res, mw.upmDefaultConfig.homeUrl));
            assert(getUpmLevels.calledOnceWith({ appId, "attuid": user }));
        });
    });
});


describe("Utils", () => {
    beforeEach(mockLog);

    afterEach(sinon.restore);

    it("lazyOptions should call functions when passed in options", () => {
        const mw = require(mwModule);
        const option = sinon.stub();
        const opts = { "myOption": option };
        const request = { "headers": "some-headers" };

        mw.lazyOptions(opts, request);
        assert(option.calledWith(request));
    });

    describe("reducer", () => {
        it("Reducer should return empty object on missing key", () => {
            const mw = require(mwModule);
            assert(str(mw.reducerByKey([])) === "{}");
        });

        it("Reducer should return flat object from array", () => {
            const mw = require(mwModule);
            const key = "mykey";
            const expected = {
                "123": { [key]: 123, "value": "test1" },
                "456": { [key]: 456, "value": "test2" }
            };

            // Key value is always converted to string 123 -> "123"
            for (const item of Object.keys(expected)) {
                assert(typeof item === "string");
            }

            const data = [
                { [key]: 123, "value": "test1" },
                { [key]: 456, "value": "test2" }
            ];
            assert(str(mw.reducerByKey(data, key)) === str(expected));
        });
    });

    describe("cacheControlClear()", () => {
        it("should not reset cache if no match", () => {
            const mw = require(mwModule);
            const instance = { "reset": sinon.stub() };
            const control = "";
            mw.cacheControlClear(instance, control);
            assert(!instance.reset.called);
        });

        it("should reset cache if Cache-Control matches", () => {
            const mw = require(mwModule);
            const instance = { "reset": sinon.stub() };
            const control = "no-cache";
            mw.cacheControlClear(instance, control);
            assert(instance.reset.called);
        });
    });
});


describe("Reject handlers", () => {
    describe("AAF", () => {
        it("should report errs on own crash + forward", () => {
            const log = mockLog();
            const mw = require(mwModule);

            const err = null;
            const res = null;
            const opts = {};
            const handleResp = sinon.stub(mw, "handleErrorResponse");

            mw.handleAafReject(err, res, opts);

            assert(log.calledTwice);
            const msg = "Cannot read property 'request' of null";
            assert(log.firstCall.firstArg.message === msg);
            assert(log.secondCall.firstArg === err);

            assert(handleResp.calledWith(err, res, opts.debug));
        });

        it("should print raw request headers", () => {
            const log = mockLog();
            const mw = require(mwModule);

            const headers = "my headers";
            const err = {
                "request": { "_header": headers }, "response": null
            };
            const res = null;
            const opts = {};
            const handleResp = sinon.stub(mw, "handleErrorResponse");

            mw.handleAafReject(err, res, opts);
            // eslint-disable-next-line no-magic-numbers
            assert(log.callCount === 3);

            const { firstCall, secondCall, thirdCall } = log;
            assert(
                firstCall.firstArg === "No response present (is undefined)"
            );
            assert(secondCall.firstArg === err);

            const msg = `Request Headers: ${str(headers)}`;
            assert(thirdCall.firstArg === msg);

            assert(handleResp.calledWith(err, res, opts.debug));
        });

        it("should print response details", () => {
            const log = mockLog();
            const mw = require(mwModule);

            const headers = "my headers";
            const url = "http://localhost";
            const data = "some data";
            const stat = null;
            const err = {
                "request": null,
                "response": { data, headers, "status": stat, url }
            };

            const res = null;
            const opts = {};
            const handleResp = sinon.stub(mw, "handleErrorResponse");

            mw.handleAafReject(err, res, opts);
            // eslint-disable-next-line no-magic-numbers
            assert(log.callCount === 3);

            const { firstCall, secondCall, thirdCall } = log;
            assert(
                firstCall.firstArg === `AAF request to ${url} failed: ${stat}`
            );
            assert(
                secondCall.firstArg === `Response Headers: ${str(headers)}`
            );
            assert(thirdCall.firstArg === `Body: "${data}"`);

            assert(handleResp.calledWith(err, res, opts.debug));
        });

        it("should redirect on 302", () => {
            const log = mockLog();
            const mw = require(mwModule);

            const url = "http://localhost";
            const headers = { "location": url };
            const homeUrl = "http://local.att.com";
            const data = "some data";
            const stat = 302;
            const err = {
                "request": null,
                "response": {
                    "config": { url }, data, headers, "status": stat, url
                }
            };

            const res = null;
            const opts = { homeUrl };
            const handleResp = sinon.stub(mw, "handleErrorResponse");
            const forbid = sinon.stub(mw, "forbid");

            mw.handleAafReject(err, res, opts);
            // eslint-disable-next-line no-magic-numbers
            assert(log.callCount === 5);

            const { firstCall, secondCall, thirdCall } = log;
            assert(
                firstCall.firstArg === `AAF request to ${url} failed: ${stat}`
            );
            assert(
                secondCall.firstArg === `Response Headers: ${str(headers)}`
            );
            assert(thirdCall.firstArg === `Body: "${data}"`);

            assert(forbid.calledWith(res, homeUrl, stat));
            assert(!handleResp.called);
        });

        it("should redirect on 302 + autofix nested GL url", () => {
            const log = mockLog();
            const mw = require(mwModule);
            const { GL_HOST, GL_PATH } = mw.constants;

            const url = `${GL_HOST}/${GL_PATH}?retUrl=http://localhost`;
            const headers = { "location": url };
            const homeUrl = "http://local.att.com";
            const data = "some data";
            const stat = 302;
            const err = {
                "request": null,
                "response": {
                    "config": { url }, data, headers, "status": stat, url
                }
            };

            const res = null;
            const opts = { homeUrl };
            const handleResp = sinon.stub(mw, "handleErrorResponse");
            const forbid = sinon.stub(mw, "forbid");

            mw.handleAafReject(err, res, opts);
            // eslint-disable-next-line no-magic-numbers
            assert(log.callCount === 5);

            const { firstCall, secondCall, thirdCall } = log;
            assert(
                firstCall.firstArg === `AAF request to ${url} failed: ${stat}`
            );
            assert(
                secondCall.firstArg === `Response Headers: ${str(headers)}`
            );
            assert(thirdCall.firstArg === `Body: "${data}"`);

            assert(forbid.calledWith(res, homeUrl, stat));
            assert(!handleResp.called);
        });

        it("should redirect on 401", () => {
            const log = mockLog();
            const mw = require(mwModule);

            const url = "http://localhost";
            const headers = { "location": url };
            const homeUrl = "http://local.att.com";
            const data = "some data";
            const stat = 401;
            const err = {
                "request": null,
                "response": {
                    "config": { url }, data, headers, "status": stat, url
                }
            };

            const res = null;
            const opts = { homeUrl };
            const handleResp = sinon.stub(mw, "handleErrorResponse");
            const forbid = sinon.stub(mw, "forbid");

            mw.handleAafReject(err, res, opts);
            // eslint-disable-next-line no-magic-numbers
            assert(log.callCount === 4);

            const { firstCall, secondCall, thirdCall } = log;
            assert(
                firstCall.firstArg === `AAF request to ${url} failed: ${stat}`
            );
            assert(
                secondCall.firstArg === `Response Headers: ${str(headers)}`
            );
            assert(thirdCall.firstArg === `Body: "${data}"`);

            assert(forbid.calledWith(res, homeUrl));
            assert(!handleResp.called);
        });

        it("should redirect on 403", () => {
            const log = mockLog();
            const mw = require(mwModule);

            const url = "http://localhost";
            const headers = { "location": url };
            const homeUrl = "http://local.att.com";
            const data = "some data";
            const stat = 403;
            const err = {
                "request": null,
                "response": {
                    "config": { url }, data, headers, "status": stat, url
                }
            };

            const res = null;
            const opts = { homeUrl };
            const handleResp = sinon.stub(mw, "handleErrorResponse");
            const forbid = sinon.stub(mw, "forbid");

            mw.handleAafReject(err, res, opts);
            // eslint-disable-next-line no-magic-numbers
            assert(log.callCount === 4);

            const { firstCall, secondCall, thirdCall } = log;
            assert(
                firstCall.firstArg === `AAF request to ${url} failed: ${stat}`
            );
            assert(
                secondCall.firstArg === `Response Headers: ${str(headers)}`
            );
            assert(thirdCall.firstArg === `Body: "${data}"`);

            assert(forbid.calledWith(res, homeUrl));
            assert(!handleResp.called);
        });
    });

    describe("UPM", () => {
        it("should report errs on own crash + forward", () => {
            const log = mockLog();
            const mw = require(mwModule);

            const err = null;
            const res = null;
            const opts = {};
            const handleResp = sinon.stub(mw, "handleErrorResponse");

            mw.handleUpmReject(err, res, opts);

            assert(log.calledTwice);
            const msg = "Cannot read property 'request' of null";
            assert(log.firstCall.firstArg.message === msg);
            assert(log.secondCall.firstArg === err);

            assert(handleResp.calledWith(err, res, opts.debug));
        });

        it("should print raw request headers", () => {
            const log = mockLog();
            const mw = require(mwModule);

            const headers = "my headers";
            const err = {
                "request": { "_header": headers }, "response": null
            };
            const res = null;
            const opts = {};
            const handleResp = sinon.stub(mw, "handleErrorResponse");

            mw.handleUpmReject(err, res, opts);
            // eslint-disable-next-line no-magic-numbers
            assert(log.callCount === 3);

            const { firstCall, secondCall, thirdCall } = log;
            assert(
                firstCall.firstArg === "No response present (is undefined)"
            );
            assert(secondCall.firstArg === err);

            const msg = `Request Headers: ${str(headers)}`;
            assert(thirdCall.firstArg === msg);

            assert(handleResp.calledWith(err, res, opts.debug));
        });

        it("should print response details", () => {
            const log = mockLog();
            const mw = require(mwModule);

            const headers = "my headers";
            const url = "http://localhost";
            const data = "some data";
            const stat = null;
            const err = {
                "request": null,
                "response": { data, headers, "status": stat, url }
            };

            const res = null;
            const opts = {};
            const handleResp = sinon.stub(mw, "handleErrorResponse");

            mw.handleUpmReject(err, res, opts);
            // eslint-disable-next-line no-magic-numbers
            assert(log.callCount === 3);

            const { firstCall, secondCall, thirdCall } = log;
            assert(
                firstCall.firstArg === `UPM request to ${url} failed: ${stat}`
            );
            assert(
                secondCall.firstArg === `Response Headers: ${str(headers)}`
            );
            assert(thirdCall.firstArg === `Body: "${data}"`);

            assert(handleResp.calledWith(err, res, opts.debug));
        });
    });

    describe("generic", () => {
        it("generic error handler should return 500 in production", () => {
            const mw = require(mwModule);
            const err = null;
            const res = { "sendStatus": sinon.stub() };
            const debug = false;
            mw.handleErrorResponse(err, res, debug);
            assert(res.sendStatus.calledWith(INTERNAL_SERVER_ERROR));
        });

        it("generic error handler should print error on debug", () => {
            const mw = require(mwModule);
            const err = "my error";
            const send = sinon.stub();
            const status = sinon.stub().returns({ send });
            const setHeader = sinon.stub();
            const res = { setHeader, status };
            const debug = true;

            mw.handleErrorResponse(err, res, debug);
            assert(setHeader.calledWith("Content-Type", "application/json"));
            assert(status.calledWith(INTERNAL_SERVER_ERROR));
            assert(send.calledWith(err));
        });
    });
});
