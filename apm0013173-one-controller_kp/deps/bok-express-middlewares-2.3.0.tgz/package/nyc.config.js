/* eslint-disable sort-keys */
module.exports = {
    "all": true,
    "exclude": ["nyc.config.js", "examples", "test.js"],
    "check-coverage": true,
    "statements": 57.79,
    "branches": 45,
    "functions": 57.89,
    "lines": 58.61
};
