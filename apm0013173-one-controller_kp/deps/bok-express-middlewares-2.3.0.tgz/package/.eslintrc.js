/* eslint-disable no-magic-numbers */
module.exports = {
    "env": {
        "browser": false,
        "node": true,
        "mocha": false,
        "es2021": true
    },
    "extends": [
        "eslint:all"
    ],
    "parserOptions": {
        "ecmaFeatures": { "jsx": false },
        "ecmaVersion": 12,
        "sourceType": "module"
    },
    "plugins": [],
    "rules": {
        "array-bracket-newline": [
            "error", { "multiline": true, "minItems": 4 }
        ],
        "array-element-newline": ["error", "consistent"],
        "function-call-argument-newline": ["error", "consistent"],
        "function-paren-newline": ["error", "consistent"],
        "max-params": ["error", 5],
        "max-statements": ["error", 30],
        "multiline-ternary": ["error", "always-multiline"],
        "newline-per-chained-call": ["error", { "ignoreChainWithDepth": 4 }],
        "no-continue": "off",
        "no-return-await": "off",
        "no-ternary": "off",
        // The finally and continue is a standard behavior in almost every lang
        "no-unsafe-finally": "off",
        "object-curly-spacing": ["error", "always"],
        "object-property-newline": [
            "error", { "allowAllPropertiesOnSameLine": true }
        ],
        "one-var": ["error", "never"],
        "padded-blocks": ["error", "never"],
        "quotes": ["error", "double"],
        "semi": ["error", "always"],
        "space-before-function-paren": [
            "error", {
                "anonymous": "never",
                "named": "never",
                "asyncArrow": "always"
            }
        ],
    }
};
