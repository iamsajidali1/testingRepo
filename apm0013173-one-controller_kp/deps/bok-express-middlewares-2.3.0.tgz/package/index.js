/**
 * Common Express middlewares
 *
 * AAF:
 * - options:
 *     rejectGlobalLogon: Boolean(403)/"url"(301)
 *     setRequestUser: set req.headers.remoteUser to attuid@namespace
 *     setRemoteUser: set req.user to attuid@namespace
 *     homeUrl: "url"(301 when unsuccessful) or function
 *         (req) => `https://${req.something}/some-path`
 *     checkPermissions: Boolean
 *     requiredPermissions: AAF format [{type, instance, action}, ...]
 */
/* eslint-disable capitalized-comments,max-statements,max-lines-per-function */
/* eslint-disable no-undefined,lines-around-comment */
const ax = require("axios");
const atob = require("atob");
const lruCache = require("lru-cache");
const https = require("https");
const pino = require("pino");
const { "stringify": str } = JSON;

const AAF_URL = "https://aaf.it.att.com";
const AAF_LOCATE = "locate/com.att.aaf.service";
const AAF_INVALID_USERNAME = -1;
const AAF_UNEXPECTED_FORMAT = -2;
const AAF_NULL_BASE = -3;
const AAF_SKIP_NULL_BASE = -4;
const AAF_LOCATE_ATTEMPTS = 10;
const AAF_PING_ATTEMPTS = 3;

const UPM_MISSING_APP_ID = -1;
const UPM_MISSING_ATTUID = -2;
const UPM_UNEXPECTED_FORMAT = -3;

const UPM_URL = "https://upm-api.web.att.com:8443/api/upm/v1";
const UPM_STORAGE_LRU = 1;
const UPM_STORAGE_SQLITE = 2;
const UPM_STORAGE_MYSQL = 3;

const DISABLE_CACHE = ["no-cache", "no-store"];
const GL_HOST = "e-access.att.com";
const GL_NAMESPACE = "@csp.att.com";
const GL_PATH = "empsvcs/hrpinmgt/pagLogin";
/* eslint-disable-next-line new-cap */
const LRU = new lruCache({ "max": 128 });

const HTTP_OK = 200;
const HTTP_MOVED_PERMANENTLY = 301;
const HTTP_FOUND = 302;
const HTTP_UNAUTHORIZED = 401;
const HTTP_FORBIDDEN = 403;
const HTTP_NOT_FOUND = 404;
const HTTP_SERVER_ERROR = 500;

const MSG_WRONG = "Something is wrong with";
const ATT_ESHR_ATTUID_POS = 7;


/*
 * Needs to be checked once removed / split into multiple files if it's
 * still required or if the modules finally behave as modules without
 * silly hacks with the "exports". Or just use exports.<symbol> everywhere...
 */
var exports = module.exports = {
    "getAafUrl": async (params) => {
        const logger = exports.getLogger();
        logger.info("Locating AAF URL");

        const redirStatus = [HTTP_MOVED_PERMANENTLY, HTTP_FOUND];

        let attempts = AAF_LOCATE_ATTEMPTS;
        let pingAttempts = AAF_PING_ATTEMPTS;

        const cookies = params.cookies || {};
        const eshr = cookies.attESHr;
        const sec = cookies.attESSec;
        const gtwo = cookies.attESg2;

        const locateUrl = `${AAF_URL}/${AAF_LOCATE}`;
        let locateOpts = {};

        if (params.username && params.password && !eshr) {
            logger.info("Locating AAF with Basic auth");
            locateOpts = {
                "headers": {
                    "Authorization": `Basic ${params.encoded}`
                },
                "httpsAgent": exports.getInsecureAgent()
            };
        } else {
            logger.info("Locating AAF with Cookie auth");
            const cookie = `attESHr=${eshr}; attESSec=${sec}; attESg2=${gtwo}`;
            locateOpts = {
                "headers": { "Cookie": cookie },
                "httpsAgent": exports.getInsecureAgent(),
                "maxRedirects": 0
            };
        }

        let resp = {};
        let status = null;
        let workingUrl = null;

        // total of N * M attempts, may be slow if everything is down
        while (attempts) {
            logger.info(`Remaining attempts: ${attempts}`);

            /* eslint-disable-next-line no-magic-numbers */
            attempts -= 1;

            try {
                logger.info(`Locating AAF: ${locateUrl}`);
                /* eslint-disable-next-line no-await-in-loop */
                resp = await ax.get(locateUrl, locateOpts);
                logger.info("Got response from locating API");
            } catch (err) {
                logger.info("Got error from locating API");
                logger.error(err);

                // invalid attESSec, bubble to forbid func
                if (redirStatus.includes(err.response.status)) {
                    logger.error("Bubble to AAF error handler");
                    throw err;
                }

                // next attempt!
                continue;
            }

            logger.info("AAF URLs found, pinging");
            const foundUrls = resp.data.endpoint.map(
                (item) => `${item.protocol}://${item.hostname}:${item.port}`
            );
            for (const url of foundUrls) {
                logger.info(`Pinging AAF URL: ${url}`);
                pingAttempts = AAF_PING_ATTEMPTS;
                while (pingAttempts) {
                    logger.info(`Remaining ping attempts: ${pingAttempts}`);

                    /* eslint-disable-next-line no-magic-numbers */
                    pingAttempts -= 1;

                    try {
                        /* eslint-disable-next-line no-await-in-loop */
                        resp = await ax.options(url);
                        logger.info(
                            `Got response from pinging - status ${resp.status}`
                        );
                    } catch (err) {
                        logger.info("Got error from pinging, checking...");
                        resp = err;
                    }

                    // resolve int from Response/Error obj
                    status = resp.status || (resp.response || {}).status;

                    if (resp.code === "ECONNREFUSED") {
                        logger.info("Connection refused");
                        logger.error(resp);
                        // next url!
                        continue;
                    }

                    // don't care, the response is required only
                    if (status !== undefined) {
                        logger.info("Status is defined, server responded!");
                        workingUrl = url;
                        // answered back, so we call!
                        logger.info(`Using AAF url ${workingUrl}`);
                        return url;
                    }
                    logger.error(resp);
                }
                logger.info("Ping attempts reached, next url!");
            }
            break;
        }
        return workingUrl;
    },

    /* eslint-disable-next-line sort-keys */
    "getLogger": () => {
        // Check for prettifier dependency
        require("pino-pretty");
        return pino(exports.getLoggerOptions());
    },

    "getLoggerOptions": () => ({
        "name": "bok-express-middlewares",
        "prettyPrint": {
            "colorize": true,
            "levelFirst": false,
            "translateTime": "yyyy-mm-dd HH:MM:ss.l o"
        }
    }),

    /* eslint-disable-next-line no-magic-numbers */
    "parseEshr": (eshr) => eshr.split("|")[ATT_ESHR_ATTUID_POS].split(",")[0],

    /* eslint-disable-next-line sort-keys */
    "resolveCookies": (header) => {
        const listCookies = header.split(";").map((item) => {
            const [key, value] = item.split("=");
            if (!key) {
                /*
                 * it returns undefined at best!! :D
                 * dangling element...
                 */
                return undefined;
            }
            return { [key.trim()]: unescape(value) };
        }).filter((item) => typeof item !== "undefined");

        const cookies = {};
        for (const item of listCookies) {
            Object.assign(cookies, item);
        }
        return cookies;
    },

    /* eslint-disable-next-line sort-keys */
    "getInsecureAgent": () => new https.Agent({ "rejectUnauthorized": false }),

    /* eslint-disable-next-line sort-keys */
    "callAaf": async (params) => {
        const logger = exports.getLogger();
        const cookies = params.cookies || {};
        const eshr = cookies.attESHr;
        const sec = cookies.attESSec;
        const gtwo = cookies.attESg2;
        const { url } = params;

        let resp = {};

        if (params.username && params.password && !eshr) {
            logger.info("Calling AAF with Basic auth");
            resp = await ax.get(params.url, { "headers": {
                "Authorization": `Basic ${params.encoded}`
            } });
        } else {
            logger.info("Calling AAF with Cookie auth");
            const cookie = `attESHr=${eshr}; attESSec=${sec}; attESg2=${gtwo}`;
            resp = await ax.get(url, {
                "headers": { "Cookie": cookie },
                "maxRedirects": 0
            });
        }
        return resp;
    },

    /* eslint-disable-next-line sort-keys */
    "callUpm": async (params) => {
        const { appId, attuid } = params;
        const resp = await ax.get(
            `${UPM_URL}/user/${attuid}/application/${appId}`,
            { "httpsAgent": exports.getInsecureAgent() }
        );
        return resp;
    },

    /* eslint-disable-next-line sort-keys */
    "getUpmLevels": async (params) => {
        const logger = exports.getLogger();
        const { appId, attuid } = params;

        const result = { "levels": [], "message": "", "status": 0 };

        if (!appId) {
            result.status = UPM_MISSING_APP_ID;
            return result;
        }
        if (!attuid) {
            result.status = UPM_MISSING_ATTUID;
            return result;
        }

        let response = {};
        try {
            response = await exports.callUpm(params);
        } catch (error) {
            logger.info(error.message);
            // Axios returns non-2xx as Promise to get the response
            const resolvedError = await error;

            /*
             * I for sure would, if the LANGUAGE ITSELF worked properly
             * when implementing block/variable scopes with const/let/var :)
             */
            /* eslint-disable-next-line prefer-destructuring */
            response = resolvedError.response;
        }

        const { status, text } = response;
        result.status = status;
        result.message = text;
        if (status === HTTP_OK) {
            result.message = "";
            const levels = response.data;
            if (!(levels instanceof Object)) {
                logger.info(`${MSG_WRONG} UPM API: ${str(levels)}`);
                result.status = UPM_UNEXPECTED_FORMAT;
                return result;
            }

            // { "data": {"applications": { ... } } }
            const { "applications": apps } = response.data.data;
            result.levels = Object.values(apps[appId]);
        }
        logger.info(`Found ${result.levels.length} levels`);
        return result;
    },

    /* eslint-disable-next-line sort-keys */
    "getAafUserPermissions": async (params) => {
        const logger = exports.getLogger();
        const {
            cookies,
            encoded,
            passOnMissingAuth,
            password,
            username
        } = params;

        logger.info(`Getting user permissions for ${username}`);

        const result = { "message": "", "perms": [], "status": 0 };
        const aafUrl = await exports.getAafUrl({
            cookies, encoded, password, username
        });
        logger.info(`AAF endpoint: ${aafUrl}`);
        if (!aafUrl) {
            if (passOnMissingAuth) {
                result.status = AAF_SKIP_NULL_BASE;
            } else {
                result.status = AAF_NULL_BASE;
            }
            logger.info(`Encountered null AAF url base, ${str(result)}`);
            return result;
        }

        const permUrl = `${aafUrl}/authz/perms/user`;
        logger.info(`Base URL: ${permUrl}`);

        if (!username.includes("@")) {
            logger.info(`Invalid user was supplied: ${username}`);
            result.status = AAF_INVALID_USERNAME;
            result.message = "Invalid username";
            return result;
        }

        const url = `${permUrl}/${username}`;

        logger.info(`Trying URL: ${url}`);

        // ignores {}, {auth: ...} for some reason, using raw
        const resp = await exports.callAaf({
            cookies, encoded, password, url, username
        });
        const { status } = resp;

        logger.info(resp.headers);
        logger.info(`Response: ${JSON.stringify(resp.data)}`);

        result.status = status;
        result.message = resp.text;

        if (status === HTTP_OK) {
            // 200 has to contain a valid JSON
            result.message = "";
            const perms = resp.data;

            if (perms instanceof Object) {
                result.perms = perms.perm || [];
            } else {
                logger.info(`${MSG_WRONG} AAF API: ${JSON.stringify(perms)}`);
                result.status = AAF_UNEXPECTED_FORMAT;
            }
        }
        logger.info(`Found ${result.perms.length} permissions`);
        return result;
    },

    /* eslint-disable-next-line sort-keys */
    "forbid": (res, homeUrl, status) => {
        const logger = exports.getLogger();
        if (homeUrl) {
            logger.info(`Redirect to: ${homeUrl}`);
            const newStatus = status || HTTP_MOVED_PERMANENTLY;
            return res.redirect(newStatus, homeUrl);
        }
        return res.status(HTTP_FORBIDDEN).send();
    },

    /* eslint-disable-next-line sort-keys */
    "upmDefaultConfig": {
        "appId": null,
        "cache": UPM_STORAGE_LRU,
        "checkLevels": false,
        "debug": true,
        "homeUrl": null,
        "passOnMissing": false,
        "requiredLevels": [],
        "setRequestLevels": true
    },

    /* eslint-disable-next-line sort-keys */
    "aafDefaultConfig": {
        "checkPermissions": false,
        "debug": true,
        "homeUrl": null,
        "passOnMissingAuth": false,
        "rejectGlobalLogon": false,
        "requiredPermissions": [],
        "setRemoteUser": false,
        "setRequestUser": false
    },

    /* eslint-disable-next-line sort-keys */
    "handleAafReject": (err, res, options) => {
        const logger = exports.getLogger();
        const { homeUrl, debug } = options;
        const forbidStatus = [HTTP_UNAUTHORIZED, HTTP_FORBIDDEN];

        try {
            const errReq = err.request;
            const resp = err.response;
            if (resp) {
                const { status, url, data, headers } = resp;
                logger.info(`AAF request to ${url} failed: ${status}`);
                logger.info(`Response Headers: ${str(headers)}`);
                logger.info(`Body: "${data}"`);
                if (status === HTTP_FOUND) {
                    logger.info(`Redirect to GL and return to ${homeUrl}`);
                    // TODO: find out why this is happening
                    const { "location": loc } = resp.headers;
                    let newLocation = "";
                    if (!loc.includes(GL_HOST) || !loc.includes(GL_PATH)) {
                        newLocation = resp.headers.location.replace(
                            resp.config.url, homeUrl
                        );
                    } else {
                        newLocation = homeUrl;
                    }
                    logger.info(headers.location, resp.config.url, homeUrl);
                    exports.forbid(res, newLocation, status);
                    return;
                } else if (forbidStatus.includes(status)) {
                    logger.info(
                        "Can't access AAF API - Unauthorized/Forbidden"
                    );
                    exports.forbid(res, homeUrl);
                    return;
                }
            } else {
                logger.info("No response present (is undefined)");
                logger.info(err);
            }
            if (errReq) {
                /* eslint-disable-next-line no-underscore-dangle */
                logger.info(`Request Headers: ${str(errReq._header)}`);
            }
        } catch (exc) {
            logger.info(exc);
            logger.info(err);
        }

        exports.handleErrorResponse(err, res, debug);
    },

    /* eslint-disable-next-line sort-keys */
    "handleUpmReject": (err, res, options) => {
        const logger = exports.getLogger();
        const { debug } = options;
        try {
            const errReq = err.request;
            const resp = err.response;
            if (resp) {
                const { status, url, data, headers } = resp;
                logger.info(`UPM request to ${url} failed: ${status}`);
                logger.info(`Response Headers: ${str(headers)}`);
                logger.info(`Body: "${data}"`);
            } else {
                logger.info("No response present (is undefined)");
                logger.info(err);
            }
            if (errReq) {
                /* eslint-disable-next-line no-underscore-dangle */
                logger.info(`Request Headers: ${str(errReq._header)}`);
            }
        } catch (exc) {
            logger.info(exc);
            logger.info(err);
        }

        exports.handleErrorResponse(err, res, debug);
    },

    /* eslint-disable-next-line sort-keys */
    "handleErrorResponse": (err, res, debug) => {
        if (debug) {
            res.setHeader("Content-Type", "application/json");
            res.status(HTTP_SERVER_ERROR).send(err);
        } else {
            res.sendStatus(HTTP_SERVER_ERROR);
        }
    },

    /* eslint-disable-next-line sort-keys */
    "cacheControlClear": (instance, control) => {
        // If any of DC items is present, reset the cache instance.
        if (DISABLE_CACHE.some((item) => control.includes(item))) {
            instance.reset();
        }
    },

    /*
     * Returns a reducer that reduces an array of items
     * to a single Object by one common, unique key each item has.
     */
    /* eslint-disable-next-line sort-keys */
    "reducerByKey": (array, key) => array.reduce((result, item) => {
        result[item[key]] = item;
        return result;
    }, {}),

    /* eslint-disable-next-line sort-keys */
    "xAuthorization": () => {
        const logger = exports.getLogger();
        return (req, res, next) => {
            const authRaw = req.headers.authorization;
            const authXheader = req.headers["x-authorization"] || authRaw;

            logger.info("X-Authorization middleware");
            logger.info(`Authorization found: ${Boolean(authRaw)}`);
            logger.info(`X-Authorization found: ${Boolean(authXheader)}`);

            req.headers.authorization = authXheader;
            next();
        };
    },

    /* eslint-disable-next-line sort-keys */
    "lazyOptions": (options, request) => {
        // Should include only the incoming request i.e. be read-only!
        let opt = null;
        for (const key of Object.keys(options)) {
            opt = options[key];
            if (typeof opt === "function") {
                options[key] = opt(request);
            }
        }
        return options;
    },

    /* eslint-disable-next-line sort-keys */
    "aafSetRequestUser": (req, username, options) => {
        const logger = exports.getLogger();
        if (options.setRequestUser) {
            const data = username.split("@");
            let user = "";
            let namespace = "";

            /* eslint-disable-next-line no-magic-numbers */
            if (data.length > 1) {
                // Prioritize user+namespace
                [user, namespace] = data;
            /* eslint-disable-next-line no-magic-numbers */
            } else {
                // Fallback to pure user
                [user] = data;
            }

            logger.info(`AAF middleware: set user: ${user}`);
            logger.info(`AAF middleware: set namespace: ${namespace}`);
            req.namespace = namespace;
            req.user = user;
        }
    },

    /* eslint-disable-next-line sort-keys */
    "aaf": (options) => {
        const logger = exports.getLogger();
        const defaults = exports.aafDefaultConfig;

        // always override the defaults, undefined makes all default
        /* eslint-disable-next-line no-param-reassign */
        options = Object.assign(defaults, options);

        return (req, res, next) => {
            // lazy-evaluate options if available
            /* eslint-disable-next-line no-param-reassign */
            options = exports.lazyOptions(options, req);

            if (!req && !res && !next) {
                /*
                 * dummy return for testing
                 * has to be the last after all config is set up Object.assign
                 */
                return options;
            }

            logger.info("Initializing AAF middleware");
            logger.info(`AAF middleware settings: ${JSON.stringify(options)}`);

            const checkPerms = options.checkPermissions;
            let requiredPerms = options.requiredPermissions;

            // Because array.includes() does not really, include() *objects*
            requiredPerms = requiredPerms.map((item) => str(item));

            const { homeUrl, passOnMissingAuth, setRemoteUser } = options;
            const rejectGL = options.rejectGlobalLogon;

            let cookies = {};
            if (req.headers.cookie) {
                cookies = exports.resolveCookies(req.headers.cookie);
            }
            logger.info(cookies);

            let auth = req.headers.authorization;
            if ((!auth || !auth.includes("Basic")) && !cookies.attESHr) {
                logger.info("No or incorrect Authorization header data found");
                return exports.forbid(res, homeUrl);
            }

            const cacheControl = req.headers["cache-control"] || "";
            logger.info(`Cache control "${cacheControl}"`);

            // Check if should clear the cache
            exports.cacheControlClear(LRU, cacheControl);

            // prioritize cookies over Basic auth
            let username = "";
            let password = "";
            if (cookies.attESHr) {
                auth = cookies.attESHr;
                username = exports.parseEshr(cookies.attESHr);
                username = `${username}@csp.att.com`;
                password = undefined;
            } else {
                // strip auth type prefix and unpack
                /* eslint-disable require-unicode-regexp */
                /* eslint-disable-next-line no-useless-escape */
                auth = auth.replace(/Basic\ /, "").trim();
                [username, password] = atob(auth).split(":");
            }

            if (rejectGL && username.includes(GL_NAMESPACE)) {
                logger.info(`Rejecting Global Logon user ${username}`);
                if (typeof rejectGL === "string") {
                    return exports.forbid(res, rejectGL);
                }
                return exports.forbid(res);
            }

            const result = LRU.get(auth);
            if (result) {
                if (checkPerms) {
                    // convert all objects to stringified versions to safely
                    const safePerms = result.perms.map((item) => str(item));
                    for (const item of requiredPerms) {
                        if (safePerms.includes(item)) {
                            continue;
                        }

                        logger.info("AAF: missing perms!");
                        return exports.forbid(res, homeUrl);
                    }
                }

                if (setRemoteUser) {
                    req.headers.remoteUser = username;
                }

                exports.aafSetRequestUser(req, username, options);
                return next();
            }

            return exports.getAafUserPermissions({
                cookies,
                "encoded": auth,
                passOnMissingAuth,
                password,
                username
            }).then((aafResult) => {
                if (aafResult.status === AAF_SKIP_NULL_BASE) {
                    return next();
                }

                if (aafResult.status !== HTTP_OK) {
                    logger.info(`AAF: forbid: ${JSON.stringify(aafResult)}`);
                    return exports.forbid(res, homeUrl);
                }

                if (checkPerms) {
                    // convert all objects to stringified versions to safely
                    const safePerms = aafResult.perms.map((item) => str(item));
                    for (const item of requiredPerms) {
                        if (safePerms.includes(item)) {
                            continue;
                        }

                        logger.info("AAF: missing perms!");
                        return exports.forbid(res, homeUrl);
                    }
                }

                if (setRemoteUser) {
                    req.headers.remoteUser = username;
                }

                exports.aafSetRequestUser(req, username, options);

                LRU.set(auth, aafResult);
                return next();
            }).catch((err) => exports.handleAafReject(err, res, options));
        };
    },

    /* eslint-disable-next-line sort-keys */
    "upm": (options) => {
        const logger = exports.getLogger();
        /*
         * Requires "username" attribute in request that will be checked in UPM
         * If used with AAF Middleware, use setRequestUser=true
         */
        const defaults = exports.upmDefaultConfig;

        // always override the defaults, undefined makes all default
        /* eslint-disable-next-line no-param-reassign */
        options = Object.assign(defaults, options);

        return (req, res, next) => {
            // lazy-evaluate options if available
            /* eslint-disable-next-line no-param-reassign */
            options = exports.lazyOptions(options, req);

            if (!req && !res && !next) {
                /*
                 * dummy return for testing
                 * has to be the last after all config is set up Object.assign
                 */
                return options;
            }

            const { user } = req;
            logger.info(`Initializing UPM middleware for user: ${user}`);
            logger.info(`UPM middleware settings: ${str(options)}`);

            const {
                checkLevels,
                /* eslint-disable-next-line no-unused-vars */
                debug,
                homeUrl,
                passOnMissing,
                setRequestLevels
            } = options;
            let { requiredLevels } = options;

            // Because array.includes() does not really, include() *objects*
            requiredLevels = requiredLevels.map((item) => str(item));

            const cacheControl = req.headers["cache-control"] || "";
            logger.info(`Cache control "${cacheControl}"`);

            // Check if should clear the cache
            exports.cacheControlClear(LRU, cacheControl);

            const result = LRU.get(user);
            if (result) {
                const { "levels": rawLevels } = result;
                if (result.status === HTTP_NOT_FOUND) {
                    /*
                     * If we get 404 user is not in UPM, but we might return
                     * levels or pass anyway as it's not 3xx/400/5xx status.
                     */
                    logger.info(`UPM user not found 404: ${str(result)}`);
                    if (!passOnMissing) {
                        logger.info(`UPM: forbid: ${str(result)}`);
                        return exports.forbid(res, homeUrl);
                    }
                } else if (result.status !== HTTP_OK) {
                    logger.info(`UPM: forbid: ${str(result)}`);
                    return exports.forbid(res, homeUrl);
                }

                if (checkLevels) {
                    // convert all objects to stringified versions to safely
                    const safeLevels = rawLevels.map((item) => str(item));
                    for (const item of requiredLevels) {
                        if (safeLevels.includes(item)) {
                            continue;
                        }

                        logger.info("UPM: missing levels!");
                        if (!passOnMissing) {
                            return exports.forbid(res, homeUrl);
                        }
                    }
                }

                if (setRequestLevels) {
                    logger.info(`UPM middleware: set levels for: ${user}`);
                    req.upmLevels = rawLevels;

                    const reducer = exports.reducerByKey;
                    req.upmIdLevels = reducer(rawLevels, "level");
                    req.upmNameLevels = reducer(rawLevels, "levelName");
                }
                return next();
            }

            return exports.getUpmLevels({
                "appId": options.appId, "attuid": user
            }).then((upmResult) => {
                const { "levels": rawLevels } = upmResult;
                if (upmResult.status === HTTP_NOT_FOUND) {
                    /*
                     * If we get 404 user is not in UPM, but we might return
                     * levels or pass anyway as it's not 3xx/400/5xx status.
                     */
                    logger.info(`UPM user not found 404: ${str(upmResult)}`);
                    if (!passOnMissing) {
                        logger.info(`UPM: forbid: ${str(upmResult)}`);
                        return exports.forbid(res, homeUrl);
                    }
                } else if (upmResult.status !== HTTP_OK) {
                    logger.info(`UPM: forbid: ${str(upmResult)}`);
                    return exports.forbid(res, homeUrl);
                }

                if (checkLevels) {
                    // convert all objects to stringified versions
                    const safeLevels = rawLevels.map((item) => str(item));
                    for (const item of requiredLevels) {
                        if (safeLevels.includes(item)) {
                            continue;
                        }

                        // Reject on the first missing level
                        logger.info("UPM: missing levels!");
                        if (!passOnMissing) {
                            return exports.forbid(res, homeUrl);
                        }
                    }
                }

                if (setRequestLevels) {
                    logger.info(`UPM middleware: set levels for: ${user}`);
                    req.upmLevels = rawLevels;

                    const reducer = exports.reducerByKey;
                    req.upmIdLevels = reducer(rawLevels, "level");
                    req.upmNameLevels = reducer(rawLevels, "levelName");
                }

                LRU.set(user, upmResult);
                return next();
            }).catch((err) => exports.handleUpmReject(err, res, options));
        };
    }
};

exports.constants = {
    AAF_INVALID_USERNAME,
    AAF_LOCATE,
    AAF_LOCATE_ATTEMPTS,
    AAF_NULL_BASE,
    AAF_PING_ATTEMPTS,
    AAF_SKIP_NULL_BASE,
    AAF_UNEXPECTED_FORMAT,
    AAF_URL,
    ATT_ESHR_ATTUID_POS,
    DISABLE_CACHE,
    GL_HOST,
    GL_NAMESPACE,
    GL_PATH,
    HTTP_FORBIDDEN,
    HTTP_FOUND,
    HTTP_MOVED_PERMANENTLY,
    HTTP_NOT_FOUND,
    HTTP_OK,
    HTTP_SERVER_ERROR,
    HTTP_UNAUTHORIZED,
    UPM_MISSING_APP_ID,
    UPM_MISSING_ATTUID,
    UPM_STORAGE_LRU,
    UPM_STORAGE_MYSQL,
    UPM_STORAGE_SQLITE,
    UPM_UNEXPECTED_FORMAT,
    UPM_URL
};
