# Install as local package

0. ``./start.sh``
1. ``pushd ..``
2. ``npm install ./app``
3. ``popd``

# Documentation

    $ head -n 50 index.js
    $ ls ./examples

# Upload package to NPM Nexus

1. Get Node.js
2. Set registry with ``npm config set registry`` to NPM Nexus
   http://dockercentral.it.att.com:8093/nexus/repository/npm-hosted/

3. Add credentials to npm
   ``npm config set _auth <btoa("attuid:global-login-pass")>``

4. Initialize a new package within your namespace's scope

        npm init --scope=<namespace>

   and follow with the official tutorial:
   https://docs.npmjs.com/creating-and-publishing-unscoped-public-packages

6. Publish your package (``npm publish``)

# Installing package from NPM Nexus

0. Ensure proxy is properly set up

        npm config set proxy http://pxyapp.proxy.att.com:8080
        npm config set https-proxy http://pxyapp.proxy.att.com:8080
        npm config set no-proxy .att.com

1. Set registry with ``npm config set registry`` to NPM Nexus

        http://dockercentral.it.att.com:8093/nexus/repository/npm-group/

2. Add credentials for accessing the registry

        npm config set _auth <btoa("attuid:global-login-pass")>

3. ``npm install @com.att.bok.express-middlewares/bok-express-middlewares``

# Deleting package from NPM Nexus

1. curl -X DELETE http://<userid>:<password>@dockercentral.it.att.com:8093/nexus/repository/npm-hosted/@namespace/name/-/name-version.tgz

Source: https://wiki.web.att.com/x/Zwu7Hw
(https://wiki.web.att.com/display/swm/NPMs)
