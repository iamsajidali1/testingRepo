import axios from 'axios';


// const controllerService = {

// async getServiceToCustomerById(id: string) {
//   const response = await axios.get(
//     `${process.env.NEXT_PUBLIC_API}/customer/service`,
//     { params: { customerId: id } }
//   );
//   return response.data;
// }
// }

// export default controllerService;

import httpClient from "./httpClient";
// import axios from 'axios';
import { interceptedFetch } from '../../lib/interceptor'


// const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';


// export async function getFormTemplateById(id: number) {
//   // This hits /action-template/?id= on backend, returns fields/questions for dropdowns.
//   const res = await httpClient.get(`/action-template/?id=${id}`);
//   // This hits /action-template/:id on your backend, returns fields/questions for dropdowns.
// //   const res = await httpClient.get(`/action-template/${id}`);
//   return res.data;
// }

export async function getFormTemplateById(templateId: number) {
    const res = await httpClient.get(`/form-rules?template_id=${encodeURIComponent(templateId)}`);
    return res.data;
}

/**
 * Deletes a BC User for an Action Template.
 * @param bcUserId The ID of the BC User.
 * @param actionTemplateId The ID of the Action Template.
 * @returns Promise<any>
 */
const controllerService = {

    async getTemplateToBcUser(actionTemplateId: number): Promise<any> {
        try {
            const url = `${API_URL}/permission/template/customer/?templateId=${encodeURIComponent(actionTemplateId)}`;
            const res = await axios.get(url);
            return res.data;
        } catch (error: any) {
            throw new Error(`Failed to fetch: ${error.message}`);
        }
    },

    async getRolesForServiceAndCustomer(customerId: string, serviceId: string): Promise<any[]> {
        try {
            const params = new URLSearchParams({
                serviceId,
                customerId,
            });
            const res = await axios.get<any[]>(`${API_URL}/permission/service/role/`, {
                params,
            });
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to fetch roles for service and customer');
        }
    },

    async getBcUserForServiceAndCustomer(customerId: number, serviceId: number): Promise<any> {
        try {
            const res = await axios.get(`${API_URL}/customers/${customerId}/services/${serviceId}/bc-users`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to fetch BC users for service and customer');
        }
    },

    async getBcUserForServices(serviceId: number): Promise<any> {
        try {
            const res = await axios.get(`${API_URL}/services/${serviceId}/bc-users`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to fetch BC users for service');
        }
    },

    async getTemplateToRole(actionTemplateId: number): Promise<any> {
        try {
            const res = await axios.get(`${API_URL}/action-templates/${actionTemplateId}/roles`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to fetch roles assigned to template');
        }
    },

    async getRolesForServices(serviceId: number): Promise<any> {
        try {
            const res = await axios.get(`${API_URL}/services/${serviceId}/roles`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to fetch roles for service');
        }
    },

    async getTemplateToUser(actionTemplateId: number): Promise<any> {
        try {
            const res = await axios.get(`${API_URL}/action-templates/${actionTemplateId}/users`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to fetch users assigned to template');
        }
    },

    async getUsersForServiceAndCustomer(customerId: number, serviceId: number): Promise<any> {
        try {
            const res = await axios.get(`${API_URL}/customers/${customerId}/services/${serviceId}/users`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to fetch users for service and customer');
        }
    },

    async getUserForServices(serviceId: number): Promise<any> {
        try {
            const res = await axios.get(`${API_URL}/services/${serviceId}/users`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to fetch users for service');
        }
    },

    async assignTemplateToUser(userId: number, actionTemplateId: number): Promise<any> {
        try {
            const res = await axios.post(`${API_URL}/action-templates/${actionTemplateId}/users/${userId}`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to assign template to user');
        }
    },

    async getExistingUsersFromDB(): Promise<any[]> {
        try {
            const res = await axios.get(`${API_URL}/users/`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to fetch users');
        }
    },

    async getBcUsers(): Promise<any[]> {
        try {
            const res = await axios.get(`${API_URL}/bc/users/`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to fetch business center users');
        }
    },

    async getRoles(): Promise<any[]> {
        try {
            const res = await axios.get(`${API_URL}/roles/`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to fetch roles');
        }
    },

    async deleteBcUserForActionTemplate(bcUserId: number, actionTemplateId: number): Promise<any> {
        try {
            const res = await axios.delete(`${API_URL}/action-templates/${actionTemplateId}/bc-users/${bcUserId}`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to delete BC User for Action Template');
        }
    },

    async assignTemplateToRole(roleId: number, actionTemplateId: number): Promise<any> {
        try {
            const res = await axios.post(`${API_URL}/action-templates/${actionTemplateId}/roles/${roleId}`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to assign template to role');
        }
    },

    async deleteRoleForActionTemplate(roleId: number, actionTemplateId: number): Promise<any> {
        try {
            const res = await axios.delete(`${API_URL}/action-templates/${actionTemplateId}/roles/${roleId}`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to delete role for Action Template');
        }
    },

    async deleteUsersForActionTemplate(userId: number, actionTemplateId: number): Promise<any> {
        try {
            const res = await axios.delete(`${API_URL}/action-templates/${actionTemplateId}/users/${userId}`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to delete user for Action Template');
        }
    },

    async assignTemplateToBCUser(bcUserId: number, actionTemplateId: number): Promise<any> {
        try {
            const res = await axios.post(`${API_URL}/action-templates/${actionTemplateId}/bc-users/${bcUserId}`);
            return res.data;
        } catch (error: any) {
            throw new Error('Failed to assign template to BC User');
        }
    },
};

export default controllerService;
