
import axios from "axios";
import { generateBasicAuthHeader } from "../lib/authHelper";

const BASE = process.env.NEXT_PUBLIC_API ?? "http://localhost:8000/api";
const API_BASE = BASE.endsWith("/") ? BASE.slice(0, -1) : BASE;

const api = axios.create({
  baseURL: API_BASE,
  withCredentials: true,
  headers: {
    // "Content-Type": "application/json",
    "Authorization": generateBasicAuthHeader(),
  },
});
// Types
export interface TemplateResponse {
  id: number;
  name: string;
  version?: string | number;
  contractid?: string;
  service?: string;
  deviceModel?: string | number;
  vendorType?: string | number;
  templateType?: string | number;
  body?: string;
  dateCreated?: string;
}
export interface VariableResponse {
  [key: string]: string | number | boolean | null;
}
export interface NodeListResponse {
  // minimal typing — the Angular JSON is large; we'll type loosely
  [key: string]: any;
}
export interface SimpleIdName {
  id: number;
  contentType?: string;
  templateType?: string;
  vendorType?: string;
  [key: string]: any;
}
// API
const TemplateApi = {
  // Check template usage (dummy implementation, replace endpoint as needed)
  async checkTemplateUsage(id: string | number, name: string) {
    // Replace with your actual backend endpoint if available
    // Example: /cArche/template/usage/?id=...&name=...
    try {
      const params = { id: String(id), name };
      const res = await api.get("/cArche/template/usage/", { params });
      return res.data;
    } catch (err) {
      // If endpoint not available, return empty array
      return [];
    }
  },
  async contentTypes() {
    const res = await api.get<SimpleIdName[]>("/cArche/template/content-types/");
    return res.data;
  },
  async templateTypes() {
    const res = await api.get<SimpleIdName[]>("/cArche/template/types/");
    return res.data;
  },
  async vendorTypes() {
    const res = await api.get<SimpleIdName[]>("/cArche/template/vendor-types/");
    return res.data;
  },
  // Templates list (by contract/service) — Angular called this listTemplates endpoint (we also include this /cArche route)
  async listTemplates(contractId?: string | null, serviceId?: string) {
    // Use the cArche list endpoint (matches routes.js)
    const params: Record<string, string> = {};
    if (contractId) params.contractid = contractId;
    if (serviceId) params.service = serviceId;

    const res = await api.get<TemplateResponse[]>("/cArche/template-list/contract-id/service/", { params });
    return res.data;
  },
  // Get single template (same as Angular: /cArche/template/?name=...&contractid=...&service=...)
  async getTemplateByName(name?: string, contractId?: string, serviceId?: string) {
    const params: Record<string, string> = {};
    if (name) params.name = name;
    if (contractId) params.contractid = contractId;
    if (serviceId) params.service = serviceId;
    const res = await api.get<TemplateResponse[]>("/cArche/template/", { params });
    // backend returns array — mirror Angular behaviour: return first if array
    const data = res.data;
    return Array.isArray(data) ? (data[0] ?? null) : data;
  },
  // Create / Update / Delete
  async addTemplate(payload: Partial<TemplateResponse> & { body: string }) {
    const res = await api.post("/cArche/template/", payload);
    return res.data;
  },
  async updateTemplate(payload: Partial<TemplateResponse> & { id: number }) {
    const res = await api.put("/cArche/template/", payload);
    return res.data;
  },
  async deleteTemplate(params: { id?: number; contractid?: string; service?: string; name?: string }) {
    const res = await api.delete("/cArche/template/", { params });
    return res.data;
  },
  // Variables (3 flavors)
  async getVariablesByContract(name: string, contractId: string, templateType: string) {
    const params = { name, contractid: contractId, templateType };
    const res = await api.get<VariableResponse>("/cArche/variables/name/contract-id/", { params });
    return res.data;
  },
  async getVariablesByService(name: string, service: string, templateType: string) {
    const params = { name, service, templateType };
    const res = await api.get<VariableResponse>("/cArche/variables/name/service/", { params });
    return res.data;
  },
  async getVariablesByTemplateId(id: string, templateType: string) {
    const params = { id, templateType };
    const res = await api.get<VariableResponse>("/cArche/variables/template-id/", { params });
    return res.data;
  },

  // Convert to Jinja (matches controller)
  async convertToJinja(data: string) {
    const res = await api.post("/cArche/template/convert-to-jinja/", { data });
    // console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>convertToJinja response:", res.data);
    const result = res.data;
    // Return plain string like angular
    if (typeof result === "string") return result;
    if (result?.data && typeof result.data === "string") return result.data;
    if (result?.converted && typeof result.converted === "string") return result.converted;
    return JSON.stringify(result, null, 2);
  },
};

export default TemplateApi;