import httpClient from "./httpClient";
 
export interface WhenCondition {
  source_key: string;
  condition: string;
  value: string;
  operation?: "OR" | "AND";
}
 
export interface ThenCondition {
  target_key: string;
  action: string;
  target_value: string;
}
 
export interface FormRule {
  ID: number;
  SEQUENCE: number;
  WHEN_CONDITIONS: WhenCondition[];
  THEN_CONDITIONS: ThenCondition[];
  TEMPLATE_ID: number;
}

// please check these two function which one do you need

// GET with belongsTo and correct param name
export async function fetchFormRules(
  actionId: number,
  belongsTo: string
): Promise<FormRule[]> {
  const res = await httpClient.get(
    `/form-rules?template_id=${actionId}&belongsTo=${belongsTo}`
  );
  return res.data;
}

// POST with correct param name
 
// export async function fetchFormRules(actionId: number): Promise<FormRule[]> {
//   const res = await httpClient.get(`/form-rules?template_id=${actionId}`);
//   return res.data;
// }
 
export async function createFormRule(
  actionId: number,
  sequence: number,
  when_conditions: WhenCondition[],
  then_conditions: ThenCondition[]
) {
  return httpClient.post(`/form-rules`, {
    template_id: actionId,
    sequence,
    when_conditions,
    then_conditions,
  });
}
 
export async function editFormRule(
  id: number,
  when_conditions: WhenCondition[],
  then_conditions: ThenCondition[]
) {
  return httpClient.patch(`/form-rules/${id}`, {
    when_conditions,
    then_conditions,
  });
}
 
export async function deleteFormRule(id: number) {
  return httpClient.delete(`/form-rules/${id}`);
}
 
export async function incrementFormRuleSequence(id: number, increment: boolean) {
  return httpClient.put(`/form-rules/increment-sequence/${id}`, { increment });
}
 