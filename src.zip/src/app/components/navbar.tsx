"use client";

import React, { useEffect, useState, useRef } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { getCustomers } from "./controllerService";
import styles from "./navbar.module.css";

interface Customer {
  id: string;
  name: string;
}

const Navbar: React.FC = () => {
  const pathname = usePathname();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selected, setSelected] = useState<string>("");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [search, setSearch] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    getCustomers()
      .then(setCustomers)
      .catch((err) => console.error("Failed to fetch customers:", err));
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filteredCustomers = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <nav className={styles.navbar} style={{
      background: "#000",
      color: "#fff",
      display: "flex",
      alignItems: "center",
      padding: "0 20px",
      height: "65px"
    }}>
      {/* Logo */}
      <div className={styles.logo} style={{ display: "flex", alignItems: "center", marginRight: "24px" }}>
        <img src="/logo3.original.png" alt="one" style={{ height: "32px", marginRight: "8px" }} />
        <span style={{ fontWeight: "bold", fontSize: "1.2em" }}></span>
      </div>
      {/* Custom Dropdown */}
      <div ref={dropdownRef} style={{ position: "relative", marginRight: "32px" }}>
        <button
          onClick={() => setDropdownOpen((v) => !v)}
          style={{
            background: "#fff",
            color: "#000",
            border: "none",
            borderRadius: "4px",
            padding: "6px 12px",
            minWidth: "180px",
            textAlign: "left",
            fontSize: "1em",
            cursor: "pointer"
          }}
        >
          {selected
            ? customers.find((c) => c.id === selected)?.name
            : "Select Customer"}
        </button>
        {dropdownOpen && (
          <div
            style={{
              position: "absolute",
              top: "110%",
              left: 0,
              background: "#fff",
              color: "#000",
              border: "1px solid #ccc",
              borderRadius: "4px",
              width: "260px",
              zIndex: 10,
              boxShadow: "0 2px 8px rgba(0,0,0,0.15)"
            }}
          >
            <div style={{ display: "flex", alignItems: "center", padding: "8px" }}>
              <input
                type="text"
                placeholder="Search"
                value={search}
                onChange={e => setSearch(e.target.value)}
                style={{
                  flex: 1,
                  padding: "4px 8px",
                  border: "1px solid #ccc",
                  borderRadius: "4px"
                }}
              />
              <span style={{ marginLeft: "4px", color: "#888" }}>🔍</span>
            </div>
            <div style={{
              maxHeight: "180px",
              overflowY: "auto",
              borderTop: "1px solid #eee"
            }}>
              {filteredCustomers.length === 0 && (
                <div style={{ padding: "8px", color: "#888" }}>No customers</div>
              )}
              {filteredCustomers.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    setSelected(c.id);
                    setDropdownOpen(false);
                    localStorage.setItem("selectedCustomer", c.id);
                    window.dispatchEvent(new Event("customerChanged"));
                  }}
                  style={{
                    padding: "8px 12px",
                    cursor: "pointer",
                    background: c.id === selected ? "#e6f7ff" : "#fff",
                    border: "none",
                    width: "100%",
                    textAlign: "left"
                  }}
                >
                  {c.name}
                </button>
              ))}

            </div>
          </div>
        )}
      </div>
      {/* Links */}
      <div style={{ display: "flex", gap: "24px" }}>
        {[
          { href: "/actions", label: "Actions" },
          { href: "/configurationTemplate", label: "Configuration Templates" },
          { href: "/adminUI", label: "Administration UI" },
          { href: "/monitor", label: "Monitor" },
          { href: "/config-audit", label: "Configuration Audit" },
          { href: "/access-control", label: "Access Control" },
        ].map(({ href, label }) => (
          <Link
            key={href}
            href={href}
            style={{
              color: pathname === href ? "#5db1f6ff" : "#fff",
              textDecoration: "none",
              fontWeight: pathname === href ? "bold" : "normal",
              borderBottom: pathname === href ? "2px solid #61b5fa" : "none",
              padding: "4px 8px",
              borderRadius: "4px",
              transition: "transform 0.15s, background 0.15s",
              background: pathname === href ? "#f1f8fe" : "transparent",
              transform: pathname === href ? "scale(1.05)" : "none",
            }}
            onMouseEnter={e => {
              // (e.currentTarget as HTMLElement).style.background = "#e6f7ff";
              (e.currentTarget as HTMLElement).style.transform = "scale(1.07)";
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLElement).style.background = pathname === href ? "#f1f8fe" : "transparent";
              (e.currentTarget as HTMLElement).style.transform = pathname === href ? "scale(1.05)" : "none";
            }}
          >
            {label}
          </Link>
        ))}
      </div>
    </nav>
  );
};

export default Navbar;