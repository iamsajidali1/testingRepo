// // src/app/actions/page.tsx
// "use client";

// import React, { useEffect } from "react";
// import { Tabs } from "antd";
// import ListTemplates from "../configurationTemplate/list_templates/list_templates";
// import ActionPropertiesForm from "../components/actions/actionPropertiesForm";
// import ActionAccess from "../components/actions/action-access/action-access";
// import FormRulesTab from "./form-rules/formRulesTab";

// import { useActionSelectionStore } from "./store/actionSelectionStore";
// import { useActionDataStore } from "./store/actionDataStore";

// /**
// * ActionsPage:
// * - left panel: ListTemplates (reuse)
// * - right panel: renders tabs only when a selection exists and data is loaded
// */
// export default function ActionsPage() {
//     const selectedNode = useActionSelectionStore((s) => s.selectedNode);
//     const loadAll = useActionDataStore((s) => s.loadAll);
//     const template = useActionDataStore((s) => s.template);
//     const accessData = useActionDataStore((s) => s.accessData);
//     const loading = useActionDataStore((s) => s.loading);
//     const clear = useActionDataStore((s) => s.clear);

//     // whenever selection changes, load everything
//     useEffect(() => {
//         if (selectedNode) {
//             void loadAll({
//                 templateId: selectedNode.templateId ?? Number(selectedNode.id),
//                 serviceId: selectedNode.serviceId ?? undefined,
//                 customerId: selectedNode.customerId ?? undefined,
//             });
//         } else {
//             clear();
//         }
//     }, [selectedNode, loadAll, clear]);

//     // Build tab items only after we have selection and the loader is done
//     // Build tab items only after we have selection and the loader is done
//     const tabItems: { key: string; label: string; children: React.ReactNode }[] = [];
//     if (selectedNode && !loading && template) {
//         tabItems.push({
//             key: "properties",
//             label: "Properties",
//             children: (
//                 <ActionPropertiesForm
//                     selectionType={selectedNode.type ?? ""}
//                     selectionId={String(selectedNode.id ?? "")}
//                 />
//             ),
//         });
//         tabItems.push({
//             key: "accesses",
//             label: "Accesses",
//             children: (
//                 <ActionAccess
//                     selectionType={selectedNode.type ?? ""}
//                     selectionId={String(selectedNode.id ?? "")}
//                 />
//             ),
//         });
//         tabItems.push({
//             key: "formRules",
//             label: "Form Rules",
//             children: (
//                 <FormRulesTab
//                     actionId={Number(template?.id ?? selectedNode.templateId ?? selectedNode.id ?? 0)}
//                     templateId={Number(template?.id ?? selectedNode.templateId ?? selectedNode.id ?? 0)}
//                 />
//             ),
//         });
//         // Add more tabs here (e.g., Validations, Form Builder) as needed:
//         // tabItems.push({ key: "validations", label: "Validations", children: <ValidationsTab ... /> });
//         // tabItems.push({ key: "formBuilder", label: "Form Builder", children: <FormBuilderTab ... /> });
//     }

//     return (
//         <div style={{ display: "flex", height: "100vh" }}>
//             {/* Left panel */}
//             <div style={{ width: "24%", borderRight: "1px solid #e6e6e6", padding: 12 }}>
//                 <ListTemplates />
//             </div>

//             {/* Right panel */}
//             <div style={{ flex: 1, padding: 24, background: "#f5f5f5" }}>
//                 {!selectedNode && (
//                     <h2 style={{ color: "#888", textAlign: "center", marginTop: 120 }}>
//                         Please select a customer or service from the left panel
//                     </h2>
//                 )}

//                 {selectedNode && loading && (
//                     <h2 style={{ color: "#888", textAlign: "center", marginTop: 120 }}>
//                         Loading action data...
//                     </h2>
//                 )}

//                 {selectedNode && !loading && tabItems.length > 0 && (
//                     <Tabs defaultActiveKey={tabItems[0].key} type="card" items={tabItems} />
//                 )}

//                 {selectedNode && !loading && tabItems.length === 0 && (
//                     <h2 style={{ color: "#888", textAlign: "center", marginTop: 120 }}>
//                         No tabs available for selected item
//                     </h2>
//                 )}
//             </div>
//         </div>
//     );
// }




// created the this for loading actions tab with left panel
"use client";
import React, { useEffect, useState } from "react";
import ListTemplates from "../configurationTemplate/list_templates/list_templates";
import { useSelectionStore } from "./store/selectionStore";
import ActionPropertiesForm from "../components/actions/actionPropertiesForm";
import ActionAccess from "../components/actions/action-access/action-access";
import FormRulesTab from "./form-rules/formRulesTab";
import { Tabs } from "antd";
import { useSearchParams } from "next/navigation";

// Unified Actions page with tabs for Properties, Accesses, Form Rules

export default function ActionsPage() {

	const searchParams = useSearchParams();

	const templateIdFromUrl = searchParams.get("templateId");
	const actionIdFromUrl = searchParams.get("actionId");

	const { selectedType, selectedId } = useSelectionStore();

	console.log("[DEBUG] ActionsPage: store  : ", {selectedType, selectedId});
	console.log("[DEBUG] ActionsPage: URL params : ", {templateIdFromUrl, actionIdFromUrl});

	// use templateId from store or from URL if not set
	// const templateIdFinal = selectedId ?  Number(selectedId) : Number(templateIdFromUrl) || 0;
	// const actionIdFinal = selectedId ? Number(selectedId) : Number(actionIdFromUrl) || 0;

	const templateIdFinal = Number(templateIdFromUrl) || 0;
	const actionIdFinal = Number(actionIdFromUrl) || 0;

	console.log("[DEBUG] ActionPage : FINAL IDs sent to FormRRulesTab : ", {
		templateIdFinal, 
		actionIdFinal
	});

	const safeId = selectedId ?? "";
	const safeType = selectedType ?? "";

	console.log("[DEBUG] ActionsPage: ", {selectedType, selectedId, templateIdFromUrl, actionIdFromUrl});

	const [availableTabs, setAvailableTabs] = useState<string[]>([]);
	const [loadingTabs, setLoadingTabs] = useState(false);

	//use store selection only (do not depend on URL)
	useEffect(() => {
		if (selectedType && selectedId) {
			setLoadingTabs(true);

			//simulated API
			setTimeout(() => {
				setAvailableTabs(["properties", "accesses", "formRules"]);
				setLoadingTabs(false);
			}, 200);
			
		}else {
			setAvailableTabs([]);
		}
	}, [selectedType, selectedId]);

	const tabItems: { key: string; label: string; children: React.JSX.Element }[] = [];
	
	if (availableTabs.includes("properties")) {
		tabItems.push({
			key: "properties",
			label: "Properties",
			children: <ActionPropertiesForm selectionType={safeType} selectionId={safeId} />,
		});
	}

	if (availableTabs.includes("accesses")) {
		tabItems.push({
			key: "accesses",
			label: "Accesses",
			children: <ActionAccess selectionType={safeType} selectionId={safeId} />,
		});
	}
	if (availableTabs.includes("formRules")) {
		tabItems.push({
			key: "formRules",
			label: "Form Rules",
			children: (
				<FormRulesTab
					actionId={actionIdFinal}
					templateId={templateIdFinal}
				/>
			),
		});
	}

	return (
		<div style={{ display: "flex", height: "100vh" }}>
			{/* Left panel reused from Configuration Templates */}
			<div className="w-1/4 h-full flex-shrink-0">
				<ListTemplates />
			</div>
			{/* Main actions content */}
			<div style={{ flex: 1, background: "#f5f5f5", padding: "32px" }}>
				{selectedType && selectedId ? (
					loadingTabs ? (
						<h2 style={{ color: "#888", textAlign: "center", marginTop: "120px" }}>
							Loading tabs...
						</h2>
					) :  (
						<Tabs defaultActiveKey={tabItems.length > 0 ? tabItems[0].key : "properties"} type="card" items={tabItems} />
					)
					) :  (
					<h2 style={{ color: "#888", textAlign: "center", marginTop: "120px" }}>
						Please select a customer or service from the left panel
					</h2>
				)}
			</div>
		</div>
	);
}
