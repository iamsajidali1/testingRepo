// src/components/configTemplates/ConfigTemplatesPage.tsx
"use client";

import React, { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { ProgressSpinner } from "primereact/progressspinner";
import ListTemplates from "./list_templates/list_templates";
import { Template, ICarcheTemplate } from "../configurationTemplate/list_templates/list_templates";
import Editor from "./editor/editor";
import { useDebounce } from "use-debounce";

const TemplateManager: React.FC = () => {

    const [contractId, setContractId] = useState<string>("");
    const [refresh, setRefresh] = useState<string>("");
    const [template, setTemplate] = useState<Template | undefined>(undefined);
    const [deletedTemplate, setDeletedTemplate] = useState<any>(null);
    const [copiedTemplate, setCopiedTemplate] = useState<any>(null);
    const [showSpinner, setShowSpinner] = useState<boolean>(false);
    const searchParams = useSearchParams();

    // 👇 React equivalent of ngOnInit()

    useEffect(() => {
        // setShowSpinner(true);
        getSelectedCustomerFromQuery();
    }, []);

    /**
  
     * Parse query params (replacement for Angular ActivatedRoute)
  
     */

    const getSelectedCustomerFromQuery = () => {

        //const searchParams = new URLSearchParams(location.search);
        const customerName = searchParams.get("customerName");
        const customerId = searchParams.get("customerId");

        if (customerName && customerId) {

            try {
                const decodedId = atob(customerId);
                setShowSpinner(true);

            } catch (e) {
                console.error("Invalid customerId:", e);
            }

        }

    };

    /**
  
     * Called when user selects or edits a template
  
     */

    const sendTemplate = (tmpl: Template) => {
        setShowSpinner(true);
        setTemplate(tmpl);
        // stop spinner after data parses to the right panel
        setTimeout(() => {
            setShowSpinner(false);
        },);
    };

    /**
  
     * Toggle spinner state
  
     */

    const spinnerStatus = (status: boolean) => {
        console.log("Spinner status:", status);
        setShowSpinner(status);
    };

    /**
  
     * Handle delete event from editor
  
     */

    const deleteTemplateEvent = (deleted: any) => {
        setTemplate(undefined);
        setDeletedTemplate(deleted);

    };

    /**
  
     * Handle copy event from editor
  
     */

    const copyTemplateEvent = (copied: any) => {
        setCopiedTemplate(copied);
    };

    return (
        <>
            <section className="pb-3 pl-3 pr-3 pt-3">
                {showSpinner && (
                    <div className="application_loading">
                        <ProgressSpinner animationDuration=".8s" />
                    </div>
                )}
                <div className="flex h-screen w-full overflow-hidden">
                    {/* left panel */}
                    <div className="w-1/4 h-full flex-shrink-0">
                        <div className="border-gray-300" id="left_side_panel">
                            <ListTemplates
                                refresh={refresh}
                                copiedTemplate={copiedTemplate}
                                deletedTemplate={deletedTemplate}
                                contractid={contractId}
                                onEventSpinner={spinnerStatus}
                                onEventEmitter={sendTemplate}
                            />
                        </div>
                    </div>

                    {/* right panel */}
                    <div className="w-3/4 h-full overflow-y-auto overflow-x-hidden">
                        <div className="min-w-max border-gray-300" id="right_side_panel"> {/* <div className="border-gray-300" id="right_side_panel" style={{ overflow: "hidden" }}> */}
                            <Editor template={template} onEventSpinner={spinnerStatus} />
                        </div>
                    </div>

                </div>
            </section>
        </>
    );
};

export default TemplateManager;