// i have created this file to export configurationTemplate component directly

"use client";
import ConfigurationTemplate from "../configurationTemplate/configurationTemplate";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

const queryClient = new QueryClient();

export default function ConfigurationTemplatesPage() {
  return (
    <QueryClientProvider client={queryClient}>
      <ConfigurationTemplate />
    </QueryClientProvider>
  );
}