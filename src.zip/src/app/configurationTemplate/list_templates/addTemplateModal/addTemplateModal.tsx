"use client";

import React from "react";
import { Dialog } from "primereact/dialog";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { Dropdown } from "primereact/dropdown";
import { InputTextarea } from "primereact/inputtextarea";
import styles from "./addTemplateModal.module.css";

interface AddTemplateDialogProps {
    visible: boolean;
    onHide: () => void;
    form: {
        name: string;
        contractid: string;
        service: string;
        templateType: string;
        deviceModel: string;
        vendorType: string;
        body: string;
    };
    errors: any;
    touched: any;
    customers: any[];
    services: any[];
    templateTypes: any[];
    contentTypes: any[];
    vendorTypes: any[];
    disableCustomer?: boolean;
    displayErrorMsg?: boolean;
    loading?: boolean;
    onChange: (field: string, value: any) => void;
    onFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onAdd: () => void;
    onBlur?: (field: string) => void;
}

const AddTemplateDialog: React.FC<AddTemplateDialogProps> = ({
    visible,
    onHide,
    form,
    errors,
    touched,
    customers,
    services,
    templateTypes,
    contentTypes,
    vendorTypes,
    disableCustomer,
    displayErrorMsg,
    loading,
    onChange,
    onFileUpload,
    onAdd,
    onBlur
}) => (
    <Dialog header="Add new template" visible={visible} onHide={onHide} style={{ width: '60vw' }}>
        {loading && (
            <div className="application_loading">
                <i className="pi pi-spin pi-spinner" style={{ fontSize: '2em' }}></i>
                <span style={{ marginLeft: '1rem' }}>Loading data</span>
            </div>
        )}

        <div className="modal-body">
            <div className="p-field p-grid mb-2">
                <label htmlFor="name" className="p-col-fixed" style={{ width: 120 }}>Name <span id="marker_required">*</span></label>
                <div className="p-col">
                    <InputText
                        className="w-full"
                        id="name"
                        value={form.name}
                        onChange={e => onChange("name", e.target.value)}
                        onBlur={e => onBlur && onBlur("name")}
                        required
                    />
                    {/* Required field message */}
                    {!errors.pattern && !form.name && touched.name && !errors.minlength && (
                        <small className="p-error">This field is required</small>
                    )}

                    {/* No whitespaces allowed */}
                    {errors.pattern && (
                        <small className="p-error">Please type name without whitespaces!</small>
                    )}

                    {/* Minimum length */}
                    {errors.minlength && (
                        <small className="p-error">Must be longer than 5 characters!</small>
                    )}

                    {touched.name && errors.name && (
                        <small className="p-error">{errors.name}</small>
                    )}
                </div>
            </div>
            {form.name.length >= 5 && !errors.name && (
                <>
                    <div className="p-field p-grid mb-2">
                        <label htmlFor="contractid" className="p-col-fixed">Customer</label>
                        <div className="p-col">
                            <Dropdown
                                className="w-full"
                                id="contractid"
                                value={form.contractid}
                                options={customers}
                                optionLabel="name"
                                placeholder="Customers"
                                disabled={disableCustomer}
                                onChange={e => onChange("contractid", e.value)}
                                showClear
                                filter />
                            {displayErrorMsg && <small className="p-error">Please provide customer or service!</small>}
                        </div>
                    </div>
                    <div className="p-field p-grid mb-2">
                        <label htmlFor="service" className="p-col-fixed">Service</label>
                        <div className="p-col">
                            <Dropdown
                                className="w-full"
                                id="service"
                                value={form.service}
                                options={services}
                                optionLabel="serviceName"
                                placeholder="Services"
                                onChange={e => onChange("service", e.value)}
                                showClear
                                filter />
                            {displayErrorMsg && <small className="p-error">Please provide customer or service!</small>}
                        </div>
                    </div>
                    <div className="p-field p-grid mb-2">
                        <label htmlFor="templateType" className="p-col-fixed">Template type <span id="marker_required">*</span></label>
                        <div className="p-col">
                            <Dropdown
                                className="w-full"
                                id="templateType"
                                value={form.templateType}
                                options={templateTypes}
                                optionLabel="templateType"
                                placeholder="Template types"
                                onChange={e => onChange("templateType", e.value)}
                                required
                                showClear
                                filter />
                            {touched.templateType && errors.templateType && (
                                <small className="p-error">{errors.templateType}</small>
                            )}
                        </div>
                    </div>
                    <div className="p-field p-grid mb-2">
                        <label htmlFor="deviceModel" className="p-col-fixed">Content type <span id="marker_required">*</span></label>
                        <div className="p-col">
                            <Dropdown
                                className="w-full"
                                id="deviceModel"
                                value={form.deviceModel}
                                options={contentTypes}
                                optionLabel="contentType"
                                placeholder="Content types"
                                onChange={e => onChange("deviceModel", e.value)}
                                required
                                showClear
                                filter />
                            {touched.deviceModel && errors.deviceModel && (
                                <small className="p-error">{errors.deviceModel}</small>
                            )}
                        </div>
                    </div>
                    <div className="p-field p-grid mb-2">
                        <label htmlFor="vendorType" className="p-col-fixed">Vendor type <span id="marker_required">*</span></label>
                        <div className="p-col">
                            <Dropdown
                                className="w-full"
                                id="vendorType"
                                value={form.vendorType}
                                options={vendorTypes}
                                optionLabel="vendorType"
                                placeholder="Vendor types"
                                onChange={e => onChange("vendorType", e.value)}
                                required
                                showClear
                                filter />
                            {touched.vendorType && errors.vendorType && (
                                <small className="p-error">{errors.vendorType}</small>
                            )}
                        </div>
                    </div>
                    <div className="p-field p-formgrid p-grid mb-2">
                        <label htmlFor="body">Body <span id="marker_required">*</span></label>
                        <div className="p-col">
                            <InputTextarea
                                id="body"
                                value={form.body}
                                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => onChange("body", e.target.value)}
                                rows={10}
                                style={{ fontFamily: "monospace" }}
                                className={touched.body && errors.body ? "p-invalid w-full" : "w-full"} />
                            {touched.body && errors.body && (
                                <small className="p-error">{errors.body}</small>
                            )}
                        </div>
                    </div>
                </>
            )}
            <div className={`${styles.modalFooter} modal-footer flex justify-content-end gap-2`}>
                <input id="file-upload" type="file" accept=".txt" onChange={onFileUpload} />
                <Button label="Create" className="p-button" disabled={Object.values(errors).some(Boolean)} onClick={onAdd} size="small" />
                <Button label="Close" className="p-button p-button-secondary" onClick={onHide} size="small" />
            </div>
        </div>
    </Dialog>
);

export default AddTemplateDialog;