"use client";
import React, { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button, Typography, Space, Card, Modal, Table, Select } from "antd";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import dynamic from "next/dynamic";
import TemplateApi, { TemplateResponse, VariableResponse, } from "../../../services/apiConnectService";
import { toast } from "react-toastify";

export interface Template {
    contractid: string | null;
    service: string | null;
    name: string;
    id: string | number;
}

interface EditorProps {
    template?: Template;
    onEventSpinner?: (status: boolean) => void;
    onCopiedTemplate?: (data: any) => void;
    onDeleteTemplate?: (data: any) => void;
    onSpinnerStatus?: (status: boolean) => void;
}
// dynamic Ace import — load ace core and mode/theme first
const AceEditor = dynamic(async () => {
    await import("ace-builds/src-noconflict/ace");
    await import("ace-builds/src-noconflict/ext-language_tools");
    await import("ace-builds/src-noconflict/mode-django");
    await import("ace-builds/src-noconflict/theme-github");
    const mod = await import("react-ace");
    return mod.default;
}, { ssr: false });

const { Title, Text } = Typography;
const { Option } = Select;

const Editor: React.FC<EditorProps> = ({ template, onEventSpinner }) => {
    const qc = useQueryClient();
    const contentTypesQuery = useQuery({
        queryKey: ["contentTypes"],
        queryFn: () => TemplateApi.contentTypes(),
    });
    const templateTypesQuery = useQuery({
        queryKey: ["templateTypes"],
        queryFn: () => TemplateApi.templateTypes(),
    });
    const vendorTypesQuery = useQuery({
        queryKey: ["vendorTypes"],
        queryFn: () => TemplateApi.vendorTypes(),
    });
    // templates list by contract/service
    const templatesQuery = useQuery({
        queryKey: ["templates", template?.contractid ?? "", template?.service ?? "", template?.name ?? ""],
        queryFn: () => TemplateApi.listTemplates(template?.contractid ?? undefined, template?.service ?? undefined),
        enabled: !!(template?.contractid || template?.service),
        placeholderData: [],
    });
    useEffect(() => {
        if (templatesQuery.isLoading) {
            onEventSpinner?.(true);
        } else {
            onEventSpinner?.(false);
        }
    }, [templatesQuery.isLoading]);
    const templates = templatesQuery.data ?? [];

    const [selected, setSelected] = React.useState<TemplateResponse | null>(null);
    const [editorValue, setEditorValue] = React.useState<string>("");
    const [isEditing, setIsEditing] = React.useState<boolean>(false);
    const [loading, setLoading] = React.useState<boolean>(false);
    const [saveConfirmOpen, setSaveConfirmOpen] = React.useState<boolean>(false);
    const [variableModalOpen, setVariableModalOpen] = React.useState(false);
    const [copyModalOpen, setCopyModalOpen] = React.useState(false);
    const [copiedTemplateName, setCopiedTemplateName] = React.useState("");
    const [variables, setVariables] = React.useState<VariableResponse | null>(null);
    const [deleteConfirmOpen, setDeleteConfirmOpen] = React.useState<boolean>(false);

    // metadata dropdowns state
    const [selectedContentType, setSelectedContentType] = React.useState<number | null>(null);
    const [selectedTemplateType, setSelectedTemplateType] = React.useState<number | null>(null);
    const [selectedVendorType, setSelectedVendorType] = React.useState<number | null>(null);

    // state variables for jinja conversion
    const [jinjaModalOpen, setJinjaModalOpen] = React.useState(false);
    const [jinjaFullscreen, setJinjaFullscreen] = React.useState(false);
    const [convertedJinja, setConvertedJinja] = React.useState("");
    const [jinjaTemplateName, setJinjaTemplateName] = React.useState("");

    // When templates load, pick first (As in Angular default behaviour)
    useEffect(() => {
        if (!selected && templates && templates.length > 0) {
            setSelected(templates[0]);
            setEditorValue(templates[0].body ?? "");
            setSelectedContentType(Number(templates[0].deviceModel ?? 0) || null);
            setSelectedTemplateType(Number(templates[0].templateType ?? 0) || null);
            setSelectedVendorType(Number(templates[0].vendorType ?? 0) || null);
        }

        if (templates && templates.length === 0) {
            setSelected(null);
            setEditorValue("");
            setIsEditing(false);
        }
    }, [templates]);
    useEffect(() => {
        const fetchTemplate = async () => {
            if (!template || !onEventSpinner) {
                // if no template selected, clear editor
                setSelected(null);
                setEditorValue("");
                setIsEditing(false);
                return;
            }
            setLoading(true);
            try {
                onEventSpinner(true);
                // fetch full template details (like Angular)
                const tpl = await TemplateApi.getTemplateByName(
                    template.name,
                    template.contractid ?? undefined,
                    template.service ?? undefined
                );
                if (tpl) {
                    setSelected(tpl as any);
                    setEditorValue((tpl as any).body ?? "");
                    setSelectedContentType(Number((tpl as any).deviceModel ?? 0) || null);
                    setSelectedTemplateType(Number((tpl as any).templateType ?? 0) || null);
                    setSelectedVendorType(Number((tpl as any).vendorType ?? 0) || null);
                } else {
                    setSelected({
                        id: template.id as any,
                        name: template.name,
                        contractid: template.contractid ?? undefined,
                        services: template.service ?? undefined,
                        body: "",
                    } as any);
                    setEditorValue("");
                }
            } catch (err) {
                toast.error("Unable to fetch selected template details");
            } finally {
                // hide spinner
                onEventSpinner(false);
                setLoading(false);
            }
        };
        fetchTemplate();
    }, [template?.id, template?.name, template?.contractid, template?.service]);
    // Save (update)
    const handleSave = async (): Promise<any> => {
        if (!selected) throw new Error("No template selected");
        const payload: Partial<TemplateResponse> & { id: number } = {
            id: Number(selected.id),
            name: selected.name,
            body: btoa(convertedJinja),
            contractid: selected.contractid ? String(selected.contractid) : undefined,
            deviceModel: selectedContentType ? Number(selectedContentType) : undefined,
            templateType: selectedTemplateType ? Number(selectedTemplateType) : undefined,
            vendorType: selectedVendorType ? Number(selectedVendorType) : undefined,
        };
        if (selected.service) {
            payload.service = String(selected.service);
        }
        try {
            const res = await TemplateApi.updateTemplate(payload);
            console.log(">>>>>>>>>>>>>>>> updateTemplate response:", res);
            toast.success("Template saved");
            setIsEditing(false);
            await qc.invalidateQueries({ queryKey: ["templates", template?.contractid ?? "", template?.service ?? ""] });
            return res; // <--- important: return so caller can await & react
        } catch (err: any) {
            toast.error(`Save failed: ${err?.message ?? err}`);
            throw err;
        }
    };
    // Show confirmation modal before saving. Calls handleSave() if user confirms.
    const confirmAndSave = () => {
        if (!selected) {
            toast.error("No template selected");
            return;
        }
        Modal.confirm({
            title: "Save confirmation",
            icon: <ExclamationCircleOutlined />,
            content: "Do you want to save changes to this template?",
            okText: "Yes",
            cancelText: "No",
            centered: true,
            okType: "primary",
            // return the promise returned by handleSave so Antd knows to wait
            onOk() {
                console.log(">>>>>>>>>>>>>>>> inside onOk()");
                setLoading(true);
                return handleSave()
                    .catch((err: any) => {
                        console.log(">>>>>>>>>>>>>>>> onOk handleSave ERROR :", err);
                        toast.error(`Save failed: ${err?.message ?? err}`);
                    })
                    .finally(() => {
                        console.log(">>>>>>>>>>>>>>>> onOk finally reached");
                        setLoading(false);
                    });
            },
            onCancel: () => {
                console.log(">>>>>>>>>>>>>>>> Save cancelled by user");
            },
        });
    };

    // Delete
    const handleDelete = () => {
        if (!selected) return;
        Modal.confirm({
            title: null,
            footer: null,
            centered: true,
            width: 370,
            className: 'blur-modal',
            maskStyle: { backdropFilter: 'blur(4px)' },
            content: (
                <div style={{ borderRadius: 12, overflow: 'hidden', background: '#fff', boxShadow: '0 4px 24px rgba(0,0,0,0.12)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 18px 8px 18px', borderBottom: '1px solid #eee' }}>
                        <span style={{ fontWeight: 600, fontSize: 17 }}>Delete confirmation</span>
                        <span style={{ fontSize: 18, fontWeight: 600, color: '#666', cursor: 'pointer' }} onClick={() => Modal.destroyAll()}>&times;</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', padding: '18px 18px 0 18px' }}>
                        <ExclamationCircleOutlined style={{ color: '#faad14', fontSize: 22, marginRight: 12 }} />
                        <span style={{ fontSize: 16 }}>
                            Are you sure that you want to delete this template?
                        </span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, padding: '18px' }}>
                        <Button
                            type="primary"
                            icon={<i className="pi pi-check" style={{ marginRight: 4 }}></i>}
                            style={{ background: '#1890ff', border: 'none', minWidth: 80 }}
                            onClick={async () => {
                                try {
                                    console.log('Delete button clicked. Selected:', selected);
                                    // Check usage before deleting
                                    const usage = await TemplateApi.checkTemplateUsage?.(selected.id, selected.name);
                                    if (usage && usage.length > 0) {
                                        const actions = usage.map((a: any) => a.NAME).join(', ');
                                        toast.error(`This template cannot be removed, because it is used in: ${actions}. Please remove or change it.`);
                                        return;
                                    }
                                    console.log('Calling deleteTemplate API with:', { id: selected.id });
                                    const res = await TemplateApi.deleteTemplate({ id: selected.id });
                                    console.log('Delete API response:', res);
                                    toast.success('Your template is successfully deleted!');
                                    setSelected(null);
                                    setEditorValue('');
                                    qc.invalidateQueries({ queryKey: ["templates", template?.contractid ?? "", template?.service ?? ""] });
                                    Modal.destroyAll();
                                } catch (err) {
                                    console.error('Delete error:', err);
                                    toast.error('Your template is not deleted!');
                                }
                            }}
                        >
                            Yes
                        </Button>
                        <Button
                            type="default"
                            icon={<i className="pi pi-times" style={{ marginRight: 4 }}></i>}
                            style={{ background: '#1890ff', color: '#fff', border: 'none', minWidth: 80 }}
                            onClick={() => { toast.info('Delete cancelled'); Modal.destroyAll(); }}
                        >
                            No
                        </Button>
                    </div>
                </div>
            ),
        });
    };
    // Copy modal logic
    const handleCopy = () => {
        setCopiedTemplateName(selected ? `${selected.name}-copy` : "");
        setCopyModalOpen(true);
    };
    const handleCopyConfirm = async () => {
        if (!selected || !copiedTemplateName.trim()) {
            toast.error("Please enter a valid template name.");
            return;
        }
        try {
            const payload: Partial<TemplateResponse> = {
                name: copiedTemplateName.trim(),
                body: btoa(selected.body ?? ""),
                contractid: selected.contractid ?? undefined,
                service: selected.service ?? undefined,
                deviceModel: selected.deviceModel ? Number(selected.deviceModel) : undefined,
                templateType: selected.templateType ? Number(selected.templateType) : undefined,
                vendorType: selected.vendorType ? Number(selected.vendorType) : undefined,
            };
            const created = await TemplateApi.addTemplate(payload as any);
            toast.success("Template copied");
            setCopyModalOpen(false);
            setCopiedTemplateName("");
            qc.invalidateQueries({ queryKey: ["templates", template?.contractid ?? "", template?.service ?? ""] });
            // Optionally select the new created if API returns it
            if (created && created.id) {
                const list = await TemplateApi.listTemplates(template?.contractid ?? undefined, template?.service ?? undefined);
                const found: TemplateResponse | undefined = (list as TemplateResponse[]).find((x: TemplateResponse) => x.name === copiedTemplateName.trim());
                if (found) {
                    setSelected(found);
                    setEditorValue(found.body ?? "");
                }
            }
        } catch (err: any) {
            toast.error(`Copy failed: ${err?.message ?? err}`);
        }
    };
    // Convert to Jinja
    const handleConvertToJinja = async () => {
        if (!selected || !editorValue) return;
        try {
            setLoading(true);
            const res = await TemplateApi.convertToJinja(editorValue);
            // sanity check
            if (!res) {
                toast.error("Conversion returned empty result from backend during conversion");
                return;
            }
            // Normalize API response (fixes [object Object])
            let convertedText = "";
            if (typeof res === "string") {
                convertedText = res;
            } else if (res?.data && typeof res.data === "string") {
                convertedText = res.data;
            } else if (res?.converted && typeof res.converted === "string") {
                convertedText = res.converted;
            } else if (res?.result && typeof res.result === "string") {
                convertedText = res.result;
            } else {
                convertedText = JSON.stringify(res, null, 2);
            }
            // reformat the escape characters for proper indentation
            const formattedText = convertedText
                .replace(/\\n/g, "\n")
                .replace(/\\t/g, "\t")
                .trim();

            // Prefill name like Angular
            const newName = `${selected.name}_jinja2`;

            setConvertedJinja(formattedText);
            setJinjaTemplateName(newName);
            setJinjaModalOpen(true);
        } catch (err: any) {
            toast.error(`Conversion failed: ${err?.message ?? err}`);
        } finally {
            setLoading(false);
        }
    };
    // View variables — auto picks endpoint
    const handleViewVariables = async () => {
        if (!selected) return;
        try {
            let data: VariableResponse | null = null;
            if (selected.contractid && selected.name && selected.templateType) {
                data = await TemplateApi.getVariablesByContract(selected.name, selected.contractid, String(selected.templateType));
            } else if (selected.service && selected.name && selected.templateType) {
                data = await TemplateApi.getVariablesByService(selected.name, String(selected.service), String(selected.templateType));
            } else if (selected.id && selected.templateType) {
                data = await TemplateApi.getVariablesByTemplateId(String(selected.id), String(selected.templateType));
            }
            if (data) {
                setVariables(data);
                setVariableModalOpen(true);
            } else {
                toast.info("No variables found");
            }
        } catch (err: any) {
            toast.error(`Failed to load variables: ${err?.message ?? err}`);
        }
    };
    // helper to get Jinja2 template type ID or label
    const getJinja2TypeId = (): number | string | undefined => {
        if (!templateTypesQuery.data) return undefined;

        const jinja = (templateTypesQuery.data as any[]).find(
            (t: any) =>
                t.templateType?.toLowerCase().includes("jinja") ||
                t.templateType?.toLowerCase() === "jinja2"
        );
        return jinja ? jinja.id : undefined;
    };
    // UI rendering
    return (
        <div className="grid grid-cols-12 gap-4 h-full">
            {/* right */}
            <div className="col-span-9 flex flex-col h-full">
                {/* top row: dropdowns + action buttons */}
                <Card size="small" className="mb-2">
                    <div className="flex items-center justify-between gap-4">
                        {/* Left: dropdowns */}
                        <div className="flex items-center gap-2">
                            <Select
                                placeholder="Content Type"
                                style={{ width: 180 }}
                                value={selectedContentType ?? undefined}
                                onChange={(v: number | string) => setSelectedContentType(Number(v))}
                                options={Array.isArray(contentTypesQuery.data) ? contentTypesQuery.data.map((ct: any) => ({ value: ct.id, label: ct.contentType })) : []}
                                disabled={!isEditing} // non-editable until Edit or until you want to allow changing metadata
                            />
                            <Select
                                placeholder="Vendor"
                                style={{ width: 180 }}
                                value={selectedVendorType ?? undefined}
                                onChange={(v: number | string) => setSelectedVendorType(Number(v))}
                                options={Array.isArray(vendorTypesQuery.data) ? vendorTypesQuery.data.map((vt: any) => ({ value: vt.id, label: vt.vendorType })) : []}
                                disabled={!isEditing}
                            />
                            <Select
                                placeholder="Template Type"
                                style={{ width: 180 }}
                                value={selectedTemplateType ?? undefined}
                                onChange={(v: number | string) => setSelectedTemplateType(Number(v))}
                                options={Array.isArray(templateTypesQuery.data) ? templateTypesQuery.data.map((tt: any) => ({ value: tt.id, label: tt.templateType })) : []}
                                disabled={!isEditing}
                            />
                        </div>
                        {/* Right: buttons */}
                        <div>
                            <Space>
                                {/* Edit / Save toggle logic */}
                                {!isEditing ? (
                                    <>
                                        {/* Convert to Jinja (green) */}
                                        {selected && selectedTemplateType !== getJinja2TypeId() && (
                                            <Button
                                                type="primary"
                                                onClick={handleConvertToJinja}
                                                style={{ backgroundColor: "#00a859", borderColor: "#00a859" }}
                                            >
                                                <i className="pi pi-cog" style={{ marginRight: 4 }}></i> Convert to Jinja
                                            </Button>
                                        )}
                                        {/* Edit */}
                                        <Button
                                            type="primary"
                                            onClick={() => setIsEditing(true)}
                                            disabled={!selected}
                                        >
                                            <i className="pi pi-pencil" style={{ marginRight: 4 }}></i> Edit
                                        </Button>
                                        {/* Copy */}
                                        <Button
                                            type="primary"
                                            onClick={handleCopy}
                                            disabled={!selected}
                                            icon={<i className="pi pi-copy" style={{ marginRight: 4 }}></i>}
                                            style={{ marginLeft: 3 }}
                                        >
                                            Copy
                                        </Button>
                                        {/* Copy Modal */}
                                        <Modal
                                            open={copyModalOpen}
                                            onCancel={() => setCopyModalOpen(false)}
                                            footer={null}
                                            centered
                                            width={340}
                                            className="blur-modal"
                                            styles={{ body: { padding: 0, borderRadius: 12, boxShadow: '0 4px 24px rgba(0,0,0,0.12)' } }}
                                            maskStyle={{ backdropFilter: 'blur(4px)' }}
                                            closeIcon={<span style={{ fontSize: 18, fontWeight: 600, color: '#666', cursor: 'pointer' }}>&times;</span>}
                                        >
                                            <div style={{ borderRadius: 12, overflow: 'hidden', background: '#fff' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 18px 8px 18px', borderBottom: '1px solid #eee' }}>
                                                    <span style={{ fontWeight: 600, fontSize: 17 }}>Type name of copied template</span>
                                                    <span style={{ fontSize: 18, fontWeight: 600, color: '#666', cursor: 'pointer' }} onClick={() => setCopyModalOpen(false)}>&times;</span>
                                                </div>
                                                <div style={{ padding: '18px 18px 0 18px' }}>
                                                    <label htmlFor="copy-template-name" style={{ color: '#333', fontSize: 14, marginBottom: 6, display: 'block' }}>cArche template name</label>
                                                    <input
                                                        id="copy-template-name"
                                                        type="text"
                                                        value={copiedTemplateName}
                                                        onChange={e => setCopiedTemplateName(e.target.value)}
                                                        maxLength={120}
                                                        placeholder="cArche template name"
                                                        style={{ width: '100%', marginBottom: 0, padding: 8, fontSize: 15, borderRadius: 4, border: '1px solid #d9d9d9' }}
                                                    />
                                                </div>
                                                <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '18px' }}>
                                                    <Button
                                                        type="primary"
                                                        icon={<i className="pi pi-copy" style={{ marginRight: 4 }}></i>}
                                                        style={{ background: '#1890ff', border: 'none', minWidth: 80 }}
                                                        onClick={handleCopyConfirm}
                                                    >
                                                        Copy
                                                    </Button>
                                                </div>
                                            </div>
                                        </Modal>
                                        {/* Delete */}
                                        <Button
                                            type="primary"
                                            danger
                                            onClick={() => setDeleteConfirmOpen(true)}
                                            disabled={!selected}
                                        >
                                            <i className="pi pi-trash" style={{ marginRight: 4 }}></i> Delete
                                        </Button>

                                    </>
                                ) : (
                                    <>
                                        {selected && selectedTemplateType !== getJinja2TypeId() && (
                                            <Button
                                                type="primary"
                                                onClick={handleConvertToJinja}
                                                // disabled={!selected}
                                                style={{ backgroundColor: "#00a859", borderColor: "#00a859" }}
                                            >
                                                <i className="pi pi-cog" style={{ marginRight: 4 }}></i> Convert to Jinja
                                            </Button>
                                        )}

                                        {/* Save replaces Edit */}
                                        <Button
                                            type="primary"
                                            onClick={() => setSaveConfirmOpen(true)}
                                            disabled={!selected || loading}
                                            icon={<i className="pi pi-save" />}
                                        >
                                            Save
                                        </Button>
                                        {/* Keep Copy and Convert still visible */}
                                        <Button
                                            type="primary"
                                            onClick={handleCopy}
                                            disabled={!selected}
                                        >
                                            <i className="pi pi-copy" style={{ marginRight: 4 }}></i> Copy
                                        </Button>
                                        {/* Cancel replaces Delete */}
                                        <Button
                                            type="primary"
                                            onClick={() => setIsEditing(false)}
                                            disabled={!selected}
                                            icon={<i className="pi pi-times" />}
                                        >
                                            Cancel
                                        </Button>
                                    </>
                                )}
                            </Space>
                        </div>
                    </div>
                </Card>
                {/* editor */}
                <div className="flex-1 border rounded-lg overflow-hidden min-h-[60vh] w-full relative">
                    {loading ? (
                        <div className="flex justify-center items-center h-full">
                            <i className="pi pi-spin pi-spinner" style={{ fontSize: "2rem" }}></i>
                        </div>
                    ) : !selected ? (
                        <div className="flex justify-center items-center h-full text-gray-500 italic">
                            Select a template from the left panel to begin editing
                        </div>
                    ) : (
                        <AceEditor
                            mode="django"
                            theme="github"
                            style={{ width: "100%", overflowX: "hidden" }}
                            height="100%"
                            fontSize={14}
                            value={editorValue}
                            onChange={(val: string) => setEditorValue(val)}
                            setOptions={{
                                useWorker: false,
                                showLineNumbers: true,
                                tabSize: 2,
                                enableBasicAutocompletion: true,
                                enableLiveAutocompletion: true,
                            }}
                            readOnly={!isEditing}
                            name="config-template-editor"
                        />
                    )}
                </div>
            </div>
            {/* Variables Modal */}
            <Modal open={variableModalOpen} title="Template Variables" footer={null} onCancel={() => setVariableModalOpen(false)} width={650}>
                {variables ? (
                    <Table
                        size="small"
                        pagination={false}
                        dataSource={Object.entries(variables).map(([k, v]) => ({ key: k, name: k, value: String(v ?? "") }))}
                        columns={[
                            { title: "Variable", dataIndex: "name", key: "name" },
                            { title: "Value", dataIndex: "value", key: "value" },
                        ]}
                    />
                ) : (
                    <Text>No variables found</Text>
                )}
            </Modal>
            {/* Convert to Jinja Modal */}
            <Modal
                open={jinjaModalOpen}
                onCancel={() => setJinjaModalOpen(false)}
                footer={null}
                width={jinjaFullscreen ? "100%" : 800}
                style={jinjaFullscreen ? { top: 0, padding: 0 } : {}}
                className={`jinja-modal ${jinjaFullscreen ? "fullscreen" : ""}`}
                closable={false}
            >
                {/* Header */}
                <div
                    style={{
                        backgroundColor: "#f5f5f5",
                        borderBottom: "1px solid #d9d9d9",
                        padding: "10px 16px",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        fontWeight: 600,
                        fontSize: "16px",
                    }}
                >
                    <span>Convert cArche to Jinja2</span>
                    <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                        {/* Fullscreen toggle */}
                        <i
                            className={`pi ${jinjaFullscreen ? "pi-window-minimize" : "pi-window-maximize"} cursor-pointer text-gray-600 hover:text-black`}
                            title={jinjaFullscreen ? "Exit Fullscreen" : "Fullscreen"}
                            onClick={() => setJinjaFullscreen(!jinjaFullscreen)}
                        ></i>
                        {/* Close */}
                        <i
                            className="pi pi-times cursor-pointer text-gray-600 hover:text-black"
                            onClick={() => setJinjaModalOpen(false)}
                        ></i>
                    </div>
                </div>
                {/* Body */}
                <div style={{ padding: "16px", height: jinjaFullscreen ? "calc(100vh - 60px)" : "auto", overflow: "auto" }}>
                    <p style={{ marginBottom: 12 }}>
                        The respective cArche template has converted successfully to Jinja2 template.
                        <br />
                        <b>Please validate the Jinja2 template before saving it.</b>
                    </p>

                    <div style={{ marginBottom: 12 }}>
                        <label style={{ display: "block", fontWeight: 500 }}>Jinja2 Template Name *</label>
                        <input
                            type="text"
                            value={jinjaTemplateName}
                            onChange={(e) => setJinjaTemplateName(e.target.value)}
                            className="w-full border rounded p-2"
                        />
                    </div>
                    <div style={{ marginBottom: 12 }}>
                        <label style={{ display: "block", fontWeight: 500 }}>Jinja2 Template Content *</label>
                        <textarea
                            value={convertedJinja}
                            onChange={(e) => setConvertedJinja(e.target.value)}
                            spellCheck={false}
                            className="w-full border rounded p-2 font-mono text-sm bg-[#fafafa] resize-none"
                            style={{
                                height: jinjaFullscreen ? "calc(100vh - 300px)" : "300px",
                                whiteSpace: "pre",
                                overflowWrap: "normal",
                                overflowX: "auto",
                            }}
                        />
                    </div>
                    <div className="flex justify-end gap-2 mt-4">
                        <div style={{
                            display: "flex",
                            justifyContent: "flex-end",
                            gap: "10px",
                            marginTop: "16px",
                            borderTop: "1px solid #e0e0e0",
                            paddingTop: "10px"
                        }}
                        >
                            <Button
                                type="primary"
                                style={{
                                    backgroundColor: "#1677ff",
                                    borderColor: "#1677ff",
                                    minWidth: "80px"
                                }}
                                onClick={async () => {
                                    if (!selected) {
                                        toast.error("No template selected");
                                        return;
                                    }
                                    setLoading(true);
                                    try {

                                        const jinjaTypeId = getJinja2TypeId();

                                        // if no Jinja2 type found, stop
                                        if (!jinjaTypeId) {
                                            toast.error("Jinja2 template type not found in dropdown data");
                                            return;
                                        }
                                        // Prepare payload to match Angular
                                        const payload: any = {
                                            name: jinjaTemplateName,
                                            body: btoa(convertedJinja),
                                            contractid: selected.contractid ? String(selected.contractid) : undefined,
                                            deviceModel: selected.deviceModel ? Number(selected.deviceModel) : undefined,
                                            templateType: typeof jinjaTypeId === 'number' ? jinjaTypeId : Number(jinjaTypeId),
                                            vendorType: selected.vendorType ? Number(selected.vendorType) : undefined,
                                        };
                                        // Only add service if it's a valid number
                                        if (selected.service && !isNaN(Number(selected.service))) {
                                            payload.service = Number(selected.service);
                                        }
                                        const created = await TemplateApi.addTemplate(payload);

                                        toast.success("Jinja2 template saved successfully");

                                        // Refresh templates list
                                        await qc.invalidateQueries({ queryKey: ["templates", template?.contractid ?? "", template?.service ?? ""] });

                                        // Poll for new template until available (max 10 attempts, 500ms interval)
                                        if (created && created.id) {
                                            const maxAttempts = 10;
                                            const pollInterval = 500;
                                            let attempts = 0;
                                            let newTpl = null;
                                            while (attempts < maxAttempts) {
                                                newTpl = await TemplateApi.getTemplateByName(
                                                    created.name,
                                                    selected.contractid ?? undefined,
                                                    selected.service ?? undefined
                                                );
                                                if (newTpl) break;
                                                await new Promise(res => setTimeout(res, pollInterval));
                                                attempts++;
                                            }
                                            if (newTpl) {
                                                setSelected(newTpl as any);
                                                setEditorValue((newTpl as any).body ?? "");
                                                setSelectedContentType(Number((newTpl as any).deviceModel ?? 0) || null);
                                                setSelectedTemplateType(Number((newTpl as any).templateType ?? 0) || null);
                                                setSelectedVendorType(Number((newTpl as any).vendorType ?? 0) || null);
                                            } else {
                                                toast.info("New template not found after saving. Please refresh or check later.");
                                            }
                                        }

                                        setJinjaModalOpen(false);
                                    } catch (err: any) {
                                        toast.error(`Save failed: ${err?.message ?? err}`);
                                    } finally {
                                        setLoading(false);
                                    }
                                }}
                            >
                                <i className="pi pi-save" style={{ marginRight: 4 }}>  </i>
                                Save
                            </Button>
                            <Button
                                style={{
                                    backgroundColor: "white",
                                    borderColor: "#d9d9d9",
                                    color: "#333",
                                    minWidth: "80px"
                                }}
                                onClick={() => setJinjaModalOpen(false)}>
                                <i className="pi pi-times" style={{ marginRight: 4 }}></i>
                                Close
                            </Button>
                        </div>
                    </div>
                </div>
            </Modal>
            {/* Save Confirmation Modal */}
            <Modal
                open={saveConfirmOpen}
                onCancel={() => setSaveConfirmOpen(false)}
                footer={null}
                centered
                closable={false}
                maskClosable={true}
                maskStyle={{ backdropFilter: "blur(2px)" }} // blur background
                width={400}
                bodyStyle={{
                    textAlign: "center",
                    padding: "24px 16px",
                    borderRadius: "12px",
                }}
            >
                <div style={{ marginBottom: 12 }}>
                    <ExclamationCircleOutlined
                        style={{
                            color: "#faad14",
                            fontSize: 36,
                            marginBottom: 8,
                        }}
                    />
                    <div
                        style={{
                            fontSize: 18,
                            fontWeight: 600,
                            color: "#333",
                        }}
                    >
                        Save Confirmation
                    </div>
                </div>

                <div style={{ marginBottom: 24, color: "#555", fontSize: 15 }}>
                    Do you want to save changes to this template?
                </div>

                <div style={{ display: "flex", justifyContent: "center", gap: "16px" }}>
                    {/* Yes */}
                    <Button
                        type="primary"
                        loading={loading}
                        style={{
                            backgroundColor: "#1677ff",
                            borderColor: "#1677ff",
                            minWidth: 80,
                        }}
                        onClick={async () => {
                            setLoading(true);
                            try {
                                await handleSave();
                                setSaveConfirmOpen(false);
                            } catch (err) {
                                toast.error("Save failed");
                            } finally {
                                setLoading(false);
                            }
                        }}
                    >
                        Yes
                    </Button>

                    {/* No */}
                    <Button
                        style={{
                            backgroundColor: "white",
                            borderColor: "#d9d9d9",
                            color: "#333",
                            minWidth: 80,
                        }}
                        onClick={() => setSaveConfirmOpen(false)}
                    >
                        No
                    </Button>
                </div>
            </Modal>

            {/* Delete Confirmation Modal (Angular Style) */}
            <Modal
                open={deleteConfirmOpen}
                onCancel={() => setDeleteConfirmOpen(false)}
                footer={null}
                centered
                width={420}
                closable={false}
                maskClosable={true}
                maskStyle={{ backgroundColor: "rgba(0,0,0,0.45)" }}
                bodyStyle={{
                    padding: 0,
                    borderRadius: 6,
                    overflow: "hidden",
                }}
            >
                {/* Header */}
                <div
                    style={{
                        backgroundColor: "#e6f1fb",
                        borderBottom: "1px solid #d9d9d9",
                        padding: "10px 16px",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                    }}
                >
                    <span style={{ fontWeight: 600, color: "#000", fontSize: 15 }}>
                        Delete confirmation
                    </span>
                    <span
                        onClick={() => setDeleteConfirmOpen(false)}
                        style={{
                            fontSize: 16,
                            fontWeight: 600,
                            color: "#555",
                            cursor: "pointer",
                        }}
                    >
                        ×
                    </span>
                </div>

                {/* Content */}
                <div
                    style={{
                        display: "flex",
                        alignItems: "flex-start",
                        gap: 10,
                        padding: "24px 20px 12px 20px",
                        fontSize: 14.5,
                        color: "#333",
                    }}
                >
                    <ExclamationCircleOutlined
                        style={{ color: "#faad14", fontSize: 22, marginTop: 2 }}
                    />
                    <div>
                        Are you sure that you want to delete this template?
                    </div>
                </div>

                {/* Buttons */}
                <div
                    style={{
                        display: "flex",
                        justifyContent: "flex-end",
                        gap: "8px",
                        padding: "0 16px 16px 16px",
                        borderTop: "1px solid #f0f0f0",
                        marginTop: 8,
                    }}
                >
                    <Button
                        type="primary"
                        loading={loading}
                        style={{
                            backgroundColor: "#0078d4",
                            borderColor: "#0078d4",
                            minWidth: 75,
                        }}
                        onClick={async () => {
                            if (!selected) {
                                toast.error("No template selected");
                                return;
                            }
                            setLoading(true);
                            try {
                                console.log("Deleting template:", selected?.id, selected?.name);
                                await TemplateApi.deleteTemplate({ id: selected.id });
                                toast.success("Template deleted successfully");
                                setSelected(null);
                                setEditorValue("");
                                await qc.invalidateQueries({ queryKey: ["templates", template?.contractid ?? "", template?.service ?? ""] });
                                setDeleteConfirmOpen(false);
                            } catch (err: any) {
                                console.error("Delete failed:", err);
                                toast.error("Delete failed");
                            } finally {
                                setLoading(false);
                            }
                        }}
                    >
                        Yes
                    </Button>

                    <Button
                        style={{
                            borderColor: "#0078d4",
                            color: "#0078d4",
                            minWidth: 75,
                        }}
                        onClick={() => setDeleteConfirmOpen(false)}
                    >
                        No
                    </Button>
                </div>
            </Modal>

        </div>
    );
};

export default Editor;