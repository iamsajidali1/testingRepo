
// src/app/services/controllerService.ts
import axios from "axios";
const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API, // e.g. https://selfservice.dev.att.com/api
  withCredentials: true,
});
 
//  Helper to unwrap Angular-like result
const unwrap = (res: any, key: string = "result") => {
  if (res?.data?.[key]) return res.data[key];
  if (Array.isArray(res?.data)) return res.data; // raw array
  if (res?.data) return res.data;
  return [];
};
 
// ----------------- Customers -----------------
export async function getCustomers() {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  const res = await fetch(`${baseUrl}/customers/status/?active=true`);
  if (!res.ok) throw new Error("Failed to fetch customers");
  const json = await res.json();
  return json.result;
}
 
// / ----------------- Services -----------------
export async function getServices() {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  const res = await fetch(`${baseUrl}/service/`);
  if (!res.ok) throw new Error("Failed to fetch services");
  const json = await res.json();
  return json.result ?? json;
}
 
export async function getServicesByCustomerId(customerId: string) {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  const res = await fetch(`${baseUrl}/customer/service/?customerId=${customerId}`);
  if (!res.ok) throw new Error("Failed to fetch services by customer");
  const json = await res.json();
  return json.result ?? json;
}
 
// ----------------- Vendors -----------------
export async function getVendors() {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  const res = await fetch(`${baseUrl}/cArche/template/vendor-types/`);
  if (!res.ok) throw new Error("Failed to fetch vendors");
  const json = await res.json();
  return json.result ?? json;
}
 
// ----------------- Action Types -----------------
export async function getActionTypes() {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  try {
    const res = await fetch(`${baseUrl}/workflows/`);
    if (!res.ok) {
      console.error("getActionTypes: non-OK response", res.status);
      return [];
    }
    const json = await res.json();
    const payload = json.result ?? json;
 
    if (
      payload &&
      typeof payload === "object" &&
      !Array.isArray(payload) &&
      (payload.redirectUrl || payload.path || payload.src === "OIDC")
    ) {
      if (typeof window !== "undefined" && payload.redirectUrl) {
        window.location.href = payload.redirectUrl;
      }
      return [];
    }
 
    const raw = Array.isArray(payload) ? payload : Array.isArray(json) ? json : [];
    if (!Array.isArray(raw)) return [];
 
    if (typeof window !== "undefined") {
      console.debug("getActionTypes raw full:", raw);
      console.debug("getActionTypes raw sample:", raw[0]);
    }
 
    return raw.map((a: any) => {
      if (a == null) return { ID: null, NAME: "" };
      if (typeof a !== "object") return { ID: a, NAME: String(a) };
 
      const id =
        a.ID ??
        a.id ??
        a.workflowId ??
        a.value ??
        a._id ??
        (a.workflow && (a.workflow.id ?? a.workflow.workflowId)) ??
        null;
 
      const name =
        a.NAME ??
        a.name ??
        a.workflowName ??
        a.label ??
        a.displayName ??
        a.title ??
        (a.workflow && (a.workflow.name ?? a.workflow.NAME)) ??
        a.path ??
        a.src ??
        (() => {
          try {
            const str = JSON.stringify(a);
            return str.length > 120 ? str.slice(0, 120) + "..." : str;
          } catch {
            return "";
          }
        })();
 
      return {
        ...a,
        ID: id,
        NAME: name,
      };
    });
  } catch (err: any) {
    console.error("❌ getActionTypes error:", err?.message ?? err);
    return [];
  }
}
 
// ----------------- Hostnames -----------------
export async function getHostnames(customerId: string) {
  if (!customerId) return [];
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  try {
    const res = await fetch(`${baseUrl}/cache/devices/?customerId=${encodeURIComponent(customerId)}`);
    if (!res.ok) {
      console.warn("getHostnames: non-OK response", res.status);
      return [];
    }
    const json = await res.json();
    const data = json.result ?? json;
    if (!Array.isArray(data)) return [];
 
    return data.map((d: any, i: number) => {
      const hostname =
        d.HOSTNAME ??
        d.hostname ??
        d.deviceName ??
        d.name ??
        d.hostName ??
        (typeof d === "string" ? d : null);
      return {
        ID: d.id ?? d.deviceId ?? i,
        HOSTNAME: hostname,
      };
    });
  } catch (err: any) {
    console.error("❌ getHostnames error:", err?.message ?? err);
    return [];
  }
}
 
// ----------------- Rollback Timers -----------------
export async function getRollbackTimers() {
  return [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120];
}
 
// ----------------- Workflow Attributes -----------------
export async function getWorkflowAttributes(workflowId: string) {
  const defaults = {
    validation: { required: false, enabled: true },
    hostname: { required: false, enabled: false },
    configurationTemplate: { required: false, enabled: true },
    apiEndpoint: { required: false, enabled: true },
  };
 
  if (!workflowId) return defaults;
 
  try {
    try {
      const res1 = await api.get(`/workflow/attribute/`, { params: { id: workflowId } });
      const attrs1 = unwrap(res1, "result");
      if (Array.isArray(attrs1) && attrs1.length > 0) {
        return {
          validation: {
            required: attrs1.find((a: any) => a.id === 1)?.status === "required",
            enabled: attrs1.find((a: any) => a.id === 1)?.status !== "disabled",
          },
          hostname: {
            required: attrs1.find((a: any) => a.id === 3)?.status === "required",
            enabled: attrs1.find((a: any) => a.id === 3)?.status !== "disabled",
          },
          configurationTemplate: {
            required: attrs1.find((a: any) => a.id === 4)?.status === "required",
            enabled: attrs1.find((a: any) => a.id === 4)?.status !== "disabled",
          },
          apiEndpoint: {
            required: attrs1.find((a: any) => a.id === 5)?.status === "required",
            enabled: attrs1.find((a: any) => a.id === 5)?.status !== "disabled",
          },
        };
      }
    } catch (e) {
      if (typeof window !== "undefined")
        console.debug("getWorkflowAttributes: /workflow/attribute/ failed", (e as any)?.message ?? e);
    }
 
    try {
      const res2 = await api.get(`/workflows/${workflowId}/attributes`);
      const attrs2 = unwrap(res2, "result");
      if (Array.isArray(attrs2) && attrs2.length > 0) {
        return {
          validation: {
            required: attrs2.find((a: any) => a.id === 1)?.status === "required",
            enabled: attrs2.find((a: any) => a.id === 1)?.status !== "disabled",
          },
          hostname: {
            required: attrs2.find((a: any) => a.id === 3)?.status === "required",
            enabled: attrs2.find((a: any) => a.id === 3)?.status !== "disabled",
          },
          configurationTemplate: {
            required: attrs2.find((a: any) => a.id === 4)?.status === "required",
            enabled: attrs2.find((a: any) => a.id === 4)?.status !== "disabled",
          },
          apiEndpoint: {
            required: attrs2.find((a: any) => a.id === 5)?.status === "required",
            enabled: attrs2.find((a: any) => a.id === 5)?.status !== "disabled",
          },
        };
      }
    } catch (e) {
      if (typeof window !== "undefined")
        console.debug("getWorkflowAttributes: /workflows/{id}/attributes failed", (e as any)?.message ?? e);
    }
 
    return defaults;
  } catch (err: any) {
    if (typeof window !== "undefined") console.debug("getWorkflowAttributes unexpected error:", err?.message ?? err);
    return defaults;
  }
}
 
// ----------------- Save Action (UPDATED ENDPOINT) -----------------
export async function saveAction(payload: any) {
  try {
    const flatPayload = { ...payload };

    if (payload.customer && typeof payload.customer === "object") {
      flatPayload.customerId = payload.customer.id ?? payload.customer.ID ?? payload.customer;
    }
    if (payload.service && typeof payload.service === "object") {
      flatPayload.serviceId = payload.service.id ?? payload.service.ID ?? payload.service;
    }
    if (payload.actionType && typeof payload.actionType === "object") {
      flatPayload.workflowId = payload.actionType.id ?? payload.actionType.ID ?? payload.actionType;
    } else if (payload.actionType) {
      flatPayload.workflowId = payload.actionType;
    }
    if (payload.vendor && typeof payload.vendor === "object") {
      flatPayload.vendorTypeId = payload.vendor.id ?? payload.vendor.ID ?? payload.vendor;
    }

    delete flatPayload.customer;
    delete flatPayload.service;
    delete flatPayload.actionType;
    delete flatPayload.vendor;

    // Use the same endpoint as Angular for create action
    const res = await api.post("/action-template/", flatPayload);
    return res.data;
  } catch (err: any) {
    console.error("❌ saveAction error:", err.response?.status, err.message);
    throw err;
  }
}
 
// ----------------- Load Action Type for Action Template -----------------
export async function loadActionTypeForActionTemplate(actionId: string) {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  if (!actionId) return [];
 
  try {
    const res = await fetch(`${baseUrl}/workflow/action/?id=${encodeURIComponent(actionId)}`);
    if (!res.ok) {
      console.debug("loadActionTypeForActionTemplate non-OK:", res.status);
      return [];
    }
    const json = await res.json();
    const raw = json.result ?? json;
    if (!Array.isArray(raw)) return [];
 
    return raw.map((a: any) => {
      if (a == null) return { ID: null, NAME: "" };
      if (typeof a !== "object") return { ID: a, NAME: String(a) };
 
      const id =
        a.ID ??
        a.id ??
        a.workflowId ??
        a.value ??
        a._id ??
        (a.workflow && (a.workflow.id ?? a.workflow.workflowId)) ??
        null;
 
      const name =
        a.NAME ??
        a.name ??
        a.workflowName ??
        a.label ??
        a.displayName ??
        a.title ??
        (a.workflow && (a.workflow.name ?? a.workflow.NAME)) ??
        a.path ??
        a.src ??
        (() => {
          try {
            const str = JSON.stringify(a);
            return str.length > 120 ? str.slice(0, 120) + "..." : str;
          } catch {
            return "";
          }
        })();
 
      return { ...a, ID: id, NAME: name };
    });
  } catch (err: any) {
    console.debug("loadActionTypeForActionTemplate error:", err?.message ?? err);
    return [];
  }
}












 