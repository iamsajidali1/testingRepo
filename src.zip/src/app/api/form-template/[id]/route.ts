import { NextRequest, NextResponse } from "next/server";
import httpClient from "../../../../services/httpClient";

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Call your backend for the template with the given id
    const res = await httpClient.get(`/action-template/${params.id}`);
    // Return the backend response data as JSON
    return NextResponse.json(res.data);
  } catch (err: any) {
    // Return error as JSON with status 500
    return NextResponse.json(
      { error: err.message || "Failed to fetch template" },
      { status: 500 }
    );
  }
}