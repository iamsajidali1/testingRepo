#!/bin/sh
set -e
cd /app||true
ENV=UNITTEST python3 manage.py migrate
coverage run \
    --branch \
    --source api,crypt_app \
    --omit '*/migrations/*,*/apps.py' \
    manage.py test
coverage report | grep -v /migrations/
coverage html
