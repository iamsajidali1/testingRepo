"use client";

import React, { useEffect, useState, useCallback } from "react";
import {
  fetchFormRules,
  createFormRule,
  editFormRule,
  deleteFormRule,
  incrementFormRuleSequence,
  FormRule,
  WhenCondition,
  ThenCondition,
} from "../../../services/formRulesService";
import { Button, Modal, message, Table, Popconfirm } from "antd";
import { PlusOutlined, UpOutlined, DownOutlined, EditOutlined, DeleteOutlined } from "@ant-design/icons";
import RuleEditModal from "./RuleEditModal";

interface Props {
  actionId: number;
  templateId: number;
}

function parseWhen(when: WhenCondition[]) {
  return when
    .map((wc) => {
      const parts = [];
      if (wc.operation) parts.push(wc.operation);
      parts.push(wc.source_key, wc.condition);
      if (wc.value) parts.push(`"${wc.value}"`);
      return parts.join(" ");
    })
    .join(", ");
}

function parseThen(then: ThenCondition[]) {
  return then
    .map((tc) => `${tc.action} ${tc.target_key} "${tc.target_value}"`)
    .join(", ");
}

export default function FormRulesTab({ actionId, templateId }: Props) {
  const [rules, setRules] = useState<FormRule[]>([]);
  const [loading, setLoading] = useState(false);
  const [editRule, setEditRule] = useState<FormRule | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  const loadRules = useCallback(async () => {
    setLoading(true);
    try {
      const result = await fetchFormRules(actionId, "customer"); // includes belongsTo
      const result = await fetchFormRules(actionId);
      setRules(result);
    } catch {
      message.error("Failed to load form rules for the action");
    }
    setLoading(false);
  }, [actionId]);

  useEffect(() => {
    if (!isNaN(actionId)) {
      loadRules();
    } else {
      setRules([]);
    }
  }, [actionId, loadRules]);

  const minSeq = rules.length ? Math.min(...rules.map((r) => r.SEQUENCE)) : 0;
  const maxSeq = rules.length ? Math.max(...rules.map((r) => r.SEQUENCE)) : 0;

  const handleAdd = () => {
    setEditRule(null);
    setModalOpen(true);
  };

  const handleEdit = (rule: FormRule) => {
    setEditRule(rule);
    setModalOpen(true);
  };

  const handleDelete = async (id: number) => {
    setLoading(true);
    try {
      await deleteFormRule(id);
      message.success("Form rule deleted successfully!");
      loadRules();
    } catch {
      message.error("Failed to delete the form rule");
    }
    setLoading(false);
  };

  const handleIncrement = async (id: number, increment: boolean) => {
    setLoading(true);
    try {
      await incrementFormRuleSequence(id, increment);
      loadRules();
    } catch {
      loadRules();
    }
    setLoading(false);
  };

  return (
    <div style={{ background: "white", padding: 24 }}>
      <h2>Form Rules</h2>
      <Button
        icon={<PlusOutlined />}
        type="primary"
        style={{ marginBottom: 16 }}
        onClick={handleAdd}
        disabled={loading}
      >
        Add Form Rule
      </Button>
      <Table
        dataSource={rules}
        rowKey="ID"
        loading={loading}
        pagination={false}
        bordered
        columns={[
          {
            title: "Sequence",
            dataIndex: "SEQUENCE",
            render: (_value, record: FormRule) => (
              <span>
                {record.SEQUENCE !== maxSeq && (
                  <Button
                    icon={<DownOutlined />}
                    size="small"
                    style={{ marginRight: 4 }}
                    onClick={() => handleIncrement(record.ID, true)}
                    disabled={loading}
                  />
                )}
                {record.SEQUENCE !== minSeq && (
                  <Button
                    icon={<UpOutlined />}
                    size="small"
                    style={{ marginRight: 4 }}
                    onClick={() => handleIncrement(record.ID, false)}
                    disabled={loading}
                  />
                )}
                <span>{record.SEQUENCE}</span>
              </span>
            ),
          },
          {
            title: "When Conditions",
            render: (_, record: FormRule) => parseWhen(record.WHEN_CONDITIONS),
          },
          {
            title: "Then Conditions",
            render: (_, record: FormRule) => parseThen(record.THEN_CONDITIONS),
          },
          {
            title: "Actions",
            render: (_, record: FormRule) => (
              <>
                <Button
                  icon={<EditOutlined />}
                  size="small"
                  onClick={() => handleEdit(record)}
                  style={{ marginRight: 4 }}
                  disabled={loading}
                />
                <Popconfirm
                  title="Delete form rule?"
                  onConfirm={() => handleDelete(record.ID)}
                  okText="Yes"
                  cancelText="No"
                >
                  <Button icon={<DeleteOutlined />} size="small" danger disabled={loading} />
                </Popconfirm>
              </>
            ),
          },
        ]}
      />
      <RuleEditModal
        open={modalOpen}
        onCancel={() => setModalOpen(false)}
        onOk={async (when, then, ruleId) => {
          setLoading(true);
          try {
            if (ruleId) {
              await editFormRule(ruleId, when, then);
              message.success("Form rule saved successfully!");
            } else {
              await createFormRule(actionId, 0, when, then);
              message.success("Form rule saved successfully!");
            }
            setModalOpen(false);
            loadRules();
          } catch {
            message.error("Failed to save the form rule");
          }
          setLoading(false);
        }}
        rule={editRule}
        templateId={templateId}
      />
    </div>
  );
}