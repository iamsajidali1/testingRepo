"use client";
 
import React, { useEffect, useState } from "react";
import ActionProperties from "../../components/actions/actionPropertiesForm";
 
import {
  getCustomers,
  getServices,
  getActionTypes,
  getVendors,
  getHostnames,
  saveAction,
} from "../../services/controllerService";
 
export default function Page() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
 
  useEffect(() => {
    async function fetchData() {
      try {
        const cust = await getCustomers();
        console.log("✅ Customers from API:", cust); // <-- moved inside
        setCustomers(cust);
      } catch (err) {
        console.error("❌ Error fetching customers:", err);
      } finally {
        setIsLoading(false);
      }
    }
    fetchData();
  }, []);
 
  if (isLoading) return <p>Loading customers...</p>;
  if (!customers.length) return <p>No customers found.</p>;
 
  // Pick first customer for now
  const customer = customers[0];
 
  // Mock attributes (replace with getWorkflowAttributes if backend supports)
  const actionAttributes = [
    { id: 3, status: "optional" },
    { id: 4, status: "optional" },
    { id: 5, status: "optional" },
    { id: 6, status: "optional" },
  ];
 

async function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }
 
export default function Page() {
  // Pretend these come from your store/service
  const actionAttributes = [
    { id: 3, status: "optional" },  // HOSTNAME_VISIBILITY_ATTRIBUTE_ID
    { id: 4, status: "optional" },  // CONFIG_TEMPLATE_ATTRIBUTE_ID
    { id: 5, status: "optional" },  // REPORT_PATH_ATTRIBUTE_ID
    { id: 6, status: "optional" },  // ROLLBACK_TIMER_ATTRIBUTE_ID
  ] as any;
 
  const actionTemplate = {
    id: 101,
    name: "Reboot Agent",
    description: "Reboot the remote agent",
    enabled: true,
    staticHostnameCheckBox: false,
    staticHostname: null,
    apiEndpoint: "/api/report",
    minRollbackTimer: 10,
    maxRollbackTimer: 60,
    carcheTemplate: null,
  };
 
  const preselectedServices = [{ id: 1, serviceName: "Windows" }];
  const preselectedType = null;
  const preselectedVendor = null;
  const customer = { id: 77, name: "Acme Corp" };
 
  return (
<div className="max-w-5xl mx-auto p-6">
<ActionProperties
        actionAttributes={actionAttributes}
        actionTemplate={actionTemplate}
        actionServices={[]}
        actionType={null}
        actionVendor={null}
        customer={customer}
        isPropsLoaded={true}
        loadAllServices={getServices}
        loadAllActionTypes={getActionTypes}
        loadVendors={getVendors}
        loadHostnamesByCustomer={() => getHostnames(customer.id)}
        // loadConfigTemplates={getConfigTemplates}
        onSaveAction={saveAction}
        actionServices={preselectedServices}
        actionType={preselectedType}
        actionVendor={preselectedVendor}
        customer={customer}
        isPropsLoaded={true}
 
        loadAllServices={async (customerId?: number) => {
          await sleep(300);
          return [
            { id: 1, serviceName: "Windows" },
            { id: 2, serviceName: "Linux" },
          ];
        }}
        loadAllActionTypes={async () => {
          await sleep(300);
          // Service-aware types
          return [
            { ID: 11, NAME: "Patch", service: { ID: 1 } },
            { ID: 12, NAME: "Reboot", service: { ID: 1 } },
            { ID: 21, NAME: "Install", service: { ID: 2 } },
          ];
        }}
        loadVendors={async () => {
          await sleep(300);
          return [
            { id: 100, vendorType: "Symantec" },
            { id: 101, vendorType: "CrowdStrike" },
          ];
        }}
        loadHostnamesByCustomer={async () => {
          await sleep(300);
          return [
            { HOSTNAME: "srv-01" },
            { HOSTNAME: "srv-02" },
          ];
        }}
        loadConfigTemplates={async () => {
          await sleep(300);
          return [
            { id: 900, name: "Win Reboot Std", services: "1", contractid: "77", vendorType: "100" },
            { id: 901, name: "Linux Install Std", services: "2", contractid: "77", vendorType: "101" },
          ];
        }}
 
        onSaveAction={async (payload) => {
          console.log("SAVE payload ->", payload);
          await sleep(500);
          // Here call your real backend: fetch("/api/...",{method:"POST",body:JSON.stringify(payload)})
        }}
      />
</div>
  );
}