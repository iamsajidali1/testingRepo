"use client";
 
import { useEffect, useState } from "react";
import styles from "./actionProperties.module.css";
import {
  getCustomers,
  getServices,
  getVendors,
  getActionTypes,
  getHostnames,
  getRollbackTimers,
  getWorkflowAttributes,
  saveAction,
} from "../../services/controllerService";
 
type CustomerType = {
  id: string;
  name: string;
};
 
type WorkflowAttributes = {
  validation: { required: boolean; enabled: boolean };
  hostname: { required: boolean; enabled: boolean };
  configurationTemplate: { required: boolean; enabled: boolean };
  apiEndpoint: { required: boolean; enabled: boolean };
};
 
export default function ActionPropertiesForm() {
  const [customers, setCustomers] = useState<CustomerType[]>([]);
  const [services, setServices] = useState<any[]>([]);
  const [vendors, setVendors] = useState<any[]>([]);
  const [actionTypes, setActionTypes] = useState<any[]>([]);
  const [hostnames, setHostnames] = useState<any[]>([]);
  const [configTemplates, setConfigTemplates] = useState<any[]>([]);
  const [rollbackTimers, setRollbackTimers] = useState<any[]>([]);
 
  const [workflowAttributes, setWorkflowAttributes] =
    useState<WorkflowAttributes>({
      validation: { required: false, enabled: true },
      hostname: { required: false, enabled: false },
      configurationTemplate: { required: false, enabled: true },
      apiEndpoint: { required: false, enabled: true },
    });
 
  const initialForm = {
    actionName: "",
    customer: "",
    service: "",
    actionType: "",
    staticHost: false,
    hostname: "",
    description: "",
    enabled: false,
    vendor: "",
    configTemplate: "",
    reportPath: "/api/report",
    minRollbackTimer: "",
    maxRollbackTimer: "",
  };
 
  const [formData, setFormData] = useState(initialForm);
 
  // Hardcoded config templates
  const configTemplateOptions = [
    { id: "my_new_template_adding", name: "my_new_template_adding" },
    { id: "my_test_junos", name: "my_test_junos" },
    // Add more if needed
  ];
 
  // ✅ Load dropdowns
  useEffect(() => {
    getCustomers()
      .then((customersRes) => {
        setCustomers(customersRes || []);
        const firstCustomerId = (customersRes && customersRes[0]?.id) || "";
        return Promise.all([
          Promise.resolve(customersRes),
          getServices(),
          getVendors(),
          getActionTypes(),
          getHostnames(firstCustomerId),
          getRollbackTimers(),
        ]);
      })
      .then(
        ( [
          customersRes,
          servicesRes,
          vendorsRes,
          actionTypesRes,
          hostnamesRes,
          rollbackTimersRes,
        ]) => {
          setServices(servicesRes || []);
          setVendors(vendorsRes || []);
          setActionTypes(actionTypesRes || []);
          setHostnames(Array.isArray(hostnamesRes) ? hostnamesRes : []);
          setRollbackTimers(rollbackTimersRes || []);
        }
      )
      .catch((err) => {
        console.error("Error loading data:", err);
      });
  }, []);
 
  // ✅ Load workflow attributes
  useEffect(() => {
    if (formData.actionType) {
      getWorkflowAttributes(formData.actionType)
        .then((attrs) => {
          setWorkflowAttributes(attrs);
        })
        .catch((err) => {
          console.error("Error loading workflow attributes:", err);
        });
    }
  }, [formData.actionType]);
 
  // ✅ Handle input changes
  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) => {
    const { name, value, type, checked } = e.target as HTMLInputElement;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };
 
  // ✅ Reset Original
  const handleReset = () => {
    setFormData(initialForm);
  };
 
  // ✅ Save action
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Submitting form:", formData);
 
    if (!formData.actionName || !formData.service || !formData.actionType) {
      alert("Please fill required fields!");
      return;
    }
 
    saveAction(formData)
      .then((data) => {
        console.log("Form saved:", data);
        alert("Action saved successfully!");
      })
      .catch((err) => console.error("Error saving action:", err));
  };
 
  return (
    <form onSubmit={handleSubmit} className={styles["form-container"]}>
      <h2 className={styles["form-title"]}>Action Properties</h2>
 
      {/* Action Name */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]}>
          Action Name <span className={styles["required"]}>*</span>
        </label>
        <input
          type="text"
          name="actionName"
          value={formData.actionName}
          onChange={handleChange}
          className={styles["form-input"]}
        />
      </div>
 
      {/* Customer */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]}>
          Customer Name <span className={styles["required"]}>*</span>
        </label>
        <select
          name="customer"
          value={formData.customer}
          onChange={handleChange}
          className={styles["form-input"]}
        >
          <option value="">-- Select Customer --</option>
          {customers.map((c, i) => (
            <option key={c.id ?? i} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>
 
      {/* Services */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]}>
          Services <span className={styles["required"]}>*</span>
        </label>
        <select
          name="service"
          value={formData.service}
          onChange={handleChange}
          className={styles["form-input"]}
        >
          <option value="">-- Select Service --</option>
          {services.map((s, i) => (
            <option key={s.id ?? i} value={s.id}>
              {s.serviceName || s.name}
            </option>
          ))}
        </select>
      </div>
 
      {/* Action Type */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]}>
          Action Type <span className={styles["required"]}>*</span>
        </label>
        <select
          name="actionType"
          value={formData.actionType}
          onChange={handleChange}
          className={styles["form-input"]}
        >
          <option value="">-- Select Action Type --</option>
          {actionTypes.map((a, i) => (
            <option key={a.ID ?? a.id ?? i} value={a.ID ?? a.id}>
              {a.NAME}
            </option>
          ))}
        </select>
      </div>
 
      {/* Static Host */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]}>Static Host</label>
        <input
          type="checkbox"
          name="staticHost"
          checked={formData.staticHost}
          onChange={handleChange}
          style={{ marginLeft: "8px" }}
        />
      </div>
 
      {/* Hostnames */}
      {formData.staticHost && (
        <div className={styles["form-row"]}>
          <label className={styles["form-label"]}>
            Hostname <span className={styles["required"]}>*</span>
          </label>
          <select
            name="hostname"
            value={formData.hostname}
            onChange={handleChange}
            className={styles["form-input"]}
          >
            <option value="">-- Select Hostname --</option>
            {(Array.isArray(hostnames) ? hostnames : []).map((h, i) => (
              <option key={h.HOSTNAME ?? i} value={h.HOSTNAME ?? h}>
                {h.HOSTNAME ?? h}
              </option>
            ))}
          </select>
        </div>
      )}
 
      {/* Description */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]}>
          Description <span className={styles["required"]}>*</span>
        </label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          className={`${styles["form-input"]}`}
        />
      </div>
 
      {/* Enabled */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]}>Enabled *</label>
        <label className={styles["toggle"]}>
          <input
            type="checkbox"
            name="enabled"
            checked={formData.enabled}
            onChange={handleChange}
          />
          <span className={styles["slider"]}></span>
        </label>
      </div>
 
      {/* Vendor */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]}>
          Vendor <span className={styles["required"]}>*</span>
        </label>
        <select
          name="vendor"
          value={formData.vendor}
          onChange={handleChange}
          className={styles["form-input"]}
        >
          <option value="">-- Select Vendor --</option>
          {vendors.map((v, i) => (
            <option key={v.id ?? i} value={v.id}>
              {v.vendorType}
            </option>
          ))}
        </select>
      </div>
 
      {/* Config Template */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]}>
          Configuration Template <span className={styles["required"]}>*</span>
        </label>
        <select
          name="configTemplate"
          value={formData.configTemplate}
          onChange={handleChange}
          className={styles["form-input"]}
        >
          <option value="">-Select Template-</option>
          {configTemplateOptions.map((t, i) => (
            <option key={t.id ?? i} value={t.id}>
              {t.name}
            </option>
          ))}
        </select>
      </div>
 
      {/* Rollback Timers (Min and Max as number input with up/down arrows) */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]}>Min Rollback Timer :</label>
        <input
          type="number"
          name="minRollbackTimer"
          value={formData.minRollbackTimer}
          onChange={handleChange}
          className={styles["form-input"]}
          min={Math.min(...rollbackTimers)}
          max={Math.max(...rollbackTimers)}
          step={rollbackTimers[1] - rollbackTimers[0] || 10}
          list="minRollbackOptions"
        />
        <datalist id="minRollbackOptions">
          {rollbackTimers.map((t, i) => (
            <option key={i} value={t} />
          ))}
        </datalist>
      </div>
 
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]}>Max Rollback Timer :</label>
        <input
          type="number"
          name="maxRollbackTimer"
          value={formData.maxRollbackTimer}
          onChange={handleChange}
          className={styles["form-input"]}
          min={Math.min(...rollbackTimers)}
          max={Math.max(...rollbackTimers)}
          step={rollbackTimers[1] - rollbackTimers[0] || 10}
          list="maxRollbackOptions"
        />
        <datalist id="maxRollbackOptions">
          {rollbackTimers.map((t, i) => (
            <option key={i} value={t} />
          ))}
        </datalist>
      </div>
 
      {/* Buttons */}
      <div className={styles["button-row"]} style={{ display: "flex", gap: "12px" }}>
        <button
          type="button"
          className={styles["reset-btn"]}
          onClick={handleReset}
        >
          ⟳ Reset Original
        </button>
        <button type="submit" className={styles["save-btn"]}>
          💾 Save Changes
// actionPropertiesForm.tsx
import React, { useEffect, useState } from "react";
import styles from "./actionProperties.module.css";

// Types for props
interface ServiceOption { id: number; serviceName: string; }
interface VendorOption { id: number; vendorType: string; }
interface ActionTypeOption { ID: number; NAME: string; service?: { ID: number } }
interface ConfigTemplateOption { id: number; name: string; }
interface Customer { id: number; name: string; }

interface ActionPropertiesFormProps {
  actionTemplate: any;
  customer: Customer;
  actionServices?: ServiceOption[];
  actionType?: ActionTypeOption | null;
  actionVendor?: VendorOption | null;
  isPropsLoaded?: boolean;
  loadAllServices: (customerId?: number) => Promise<ServiceOption[]>;
  loadAllActionTypes: () => Promise<ActionTypeOption[]>;
  loadVendors: () => Promise<VendorOption[]>;
  loadConfigTemplates: () => Promise<ConfigTemplateOption[]>;
  onSaveAction: (payload: any) => Promise<void>;
}

const initialFormState = (template: any, customer: Customer) => ({
  actionName: template?.name || "",
  customerName: customer?.name || "",
  services: template?.serviceId || "",
  actionType: template?.actionTypeId || "",
  staticHost: template?.staticHostnameCheckBox || false,
  description: template?.description || "",
  enabled: template?.enabled || false,
  vendor: template?.vendorId || "",
  configurationTemplate: template?.configTemplateId || "",
  minRollbackTimer: template?.minRollbackTimer?.toString() || "10",
  maxRollbackTimer: template?.maxRollbackTimer?.toString() || "60"
});

const ActionPropertiesForm: React.FC<ActionPropertiesFormProps> = ({
  actionTemplate,
  customer,
  actionServices,
  actionType,
  actionVendor,
  isPropsLoaded,
  loadAllServices,
  loadAllActionTypes,
  loadVendors,
  loadConfigTemplates,
  onSaveAction
}) => {
  // State for form values and original values
  const [form, setForm] = useState(() => initialFormState(actionTemplate, customer));
  const [original, setOriginal] = useState(() => initialFormState(actionTemplate, customer));

  // On mount, set both form and original. On prop change, only update original.
  useEffect(() => {
    setOriginal(initialFormState(actionTemplate, customer));
    // Do not update form here, so user changes are preserved
  }, [actionTemplate, customer]);
  // State for select options
  const [services, setServices] = useState<ServiceOption[]>(actionServices || []);
  const [vendors, setVendors] = useState<VendorOption[]>([]);
  const [actionTypes, setActionTypes] = useState<ActionTypeOption[]>([]);
  const [configTemplates, setConfigTemplates] = useState<ConfigTemplateOption[]>([]);
  // State for errors
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Load options on mount
  useEffect(() => {
    loadAllServices(customer?.id).then(setServices);
    loadVendors().then(setVendors);
    loadAllActionTypes().then(setActionTypes);
    loadConfigTemplates().then(setConfigTemplates);
    // eslint-disable-next-line
  }, [customer?.id]);

  // Handlers
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { id, value, type, checked } = e.target as HTMLInputElement;
    setForm((prev) => ({
      ...prev,
      [id]: type === "checkbox" ? checked : value
    }));
    setErrors((prev) => ({ ...prev, [id]: "" }));
  };

  const handleReset = () => {
    setForm({ ...original });
    setErrors({});
  };

  const validate = () => {
    const newErrors: { [key: string]: string } = {};
    if (!form.actionName) newErrors.actionName = "Action Name is required.";
    if (!form.services) newErrors.services = "Service is required.";
    if (!form.actionType) newErrors.actionType = "Action Type is required.";
    if (!form.description) newErrors.description = "Description is required.";
    if (!form.vendor) newErrors.vendor = "Vendor is required.";
    if (!form.configurationTemplate) newErrors.configurationTemplate = "Config Template is required.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    await onSaveAction(form);
    setOriginal(form); // update original after save
    alert("Changes saved!");
  };

  return (
    <form className={styles["form-container"]} onSubmit={handleSubmit}>
      <h2 className={styles["form-title"]}>Action Properties</h2>
      {/* Action Name */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]} htmlFor="actionName">
          Action Name<span className={styles["required"]}>*</span>
        </label>
        <input id="actionName" type="text" className={styles["form-input"]} value={form.actionName} onChange={handleChange} />
        {errors.actionName && <span style={{ color: "red", marginLeft: 8 }}>{errors.actionName}</span>}
      </div>
      {/* Customer Name */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]} htmlFor="customerName">Customer Name</label>
        <input id="customerName" type="text" className={styles["form-input"]} value={form.customerName} readOnly />
      </div>
      {/* Services */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]} htmlFor="services">
          Services<span className={styles["required"]}>*</span>
        </label>
        <select id="services" className={styles["form-input"]} value={form.services} onChange={handleChange}>
          <option value="">-- Select Service --</option>
          {services.map((s) => (
            <option key={s.id} value={s.id}>{s.serviceName}</option>
          ))}
        </select>
        {errors.services && <span style={{ color: "red", marginLeft: 8 }}>{errors.services}</span>}
      </div>
      {/* Action Type */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]} htmlFor="actionType">
          Action Type<span className={styles["required"]}>*</span>
        </label>
        <select id="actionType" className={styles["form-input"]} value={form.actionType} onChange={handleChange}>
          <option value="">-- Select Type --</option>
          {actionTypes.map((t) => (
            <option key={t.ID} value={t.ID}>{t.NAME}</option>
          ))}
        </select>
        {errors.actionType && <span style={{ color: "red", marginLeft: 8 }}>{errors.actionType}</span>}
      </div>
      {/* Static Host */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]} htmlFor="staticHost">Static Host<span className={styles["required"]}>*</span></label>
        <input id="staticHost" type="checkbox" checked={form.staticHost} onChange={handleChange} />
      </div>
      {/* Description */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]} htmlFor="description">
          Description<span className={styles["required"]}>*</span>
        </label>
        <textarea id="description" className={styles["form-input"]} value={form.description} onChange={handleChange}></textarea>
        {errors.description && <span style={{ color: "red", marginLeft: 8 }}>{errors.description}</span>}
      </div>
      {/* Enabled */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]} htmlFor="enabled">
          Enabled<span className={styles["required"]}>*</span>
        </label>
        <label className={styles["toggle"]}>
          <span className="sr-only">Toggle Enabled</span>
          <input id="enabled" type="checkbox" checked={form.enabled} onChange={handleChange} />
          <span className={styles["slider"]}></span>
        </label>
      </div>
      {/* Vendor */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]} htmlFor="vendor">
          Vendor<span className={styles["required"]}>*</span>
        </label>
        <select id="vendor" className={styles["form-input"]} value={form.vendor} onChange={handleChange}>
          <option value="">-- Select Vendor --</option>
          {vendors.map((v) => (
            <option key={v.id} value={v.id}>{v.vendorType}</option>
          ))}
        </select>
        {errors.vendor && <span style={{ color: "red", marginLeft: 8 }}>{errors.vendor}</span>}
      </div>
      {/* Configuration Template */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]} htmlFor="configurationTemplate">
          Configuration Template<span className={styles["required"]}>*</span>
        </label>
        <select id="configurationTemplate" className={styles["form-input"]} value={form.configurationTemplate} onChange={handleChange}>
          <option value="">-- Select Template --</option>
          {configTemplates.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        {errors.configurationTemplate && <span style={{ color: "red", marginLeft: 8 }}>{errors.configurationTemplate}</span>}
      </div>
      {/* Min Rollback Timer */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]} htmlFor="minRollbackTimer">Min Rollback Timer</label>
        <select id="minRollbackTimer" className={styles["form-input"]} value={form.minRollbackTimer} onChange={handleChange}>
          <option value="10">10 minutes</option>
          <option value="30">30 minutes</option>
        </select>
      </div>
      {/* Max Rollback Timer */}
      <div className={styles["form-row"]}>
        <label className={styles["form-label"]} htmlFor="maxRollbackTimer">Max Rollback Timer</label>
        <select id="maxRollbackTimer" className={styles["form-input"]} value={form.maxRollbackTimer} onChange={handleChange}>
          <option value="60">60 minutes</option>
          <option value="120">120 minutes</option>
        </select>
      </div>
      {/* Buttons */}
      <div className={styles["button-row"]}>
        <button
          className={styles["reset-btn"]}
          type="button"
          onClick={handleReset}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 104.582 9m0 0L9 13m-4.418-4L9 5" />
          </svg>
          Reset Original
        </button>
        <button
          className={styles["save-btn"]}
          type="submit"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16v-4a4 4 0 00-8 0v4m-2 4h12a2 2 0 002-2v-4a6 6 0 10-12 0v4a2 2 0 002 2z" />
          </svg>
          Save Changes
        </button>
      </div>
    </form>
  );
}

};

export default ActionPropertiesForm;
