
"use client";

import Image from "next/image";
import "primereact/resources/themes/lara-light-blue/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";
import ConfigurationTemplate from "../app/configurationTemplate/configurationTemplate";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";

const queryClient = new QueryClient();
import { useSearchParams } from "next/navigation";
import FormRulesTab from "./actions/form-rules/formRulesTab";
import Image from "next/image";
import ActionAccess from "./components/actions/action-access/action-access";

export default function Home() {
  const searchParams = useSearchParams();
  const actionId = Number(searchParams.get("actionId"));

  return (
    <QueryClientProvider client={queryClient}>
      <ConfigurationTemplate />
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
    <FormRulesTab actionId={actionId} templateId={actionId} />


export default function Home() {
  return (
   <ActionAccess />
import React from "react";
import Navbar from "./components/navbar";
// import LeftPanel from "./components/left-panel";
 
export default function Page() {
  return (
<div style={{ display: "flex", height: "100vh", flexDirection: "column" }}>
<Navbar />
<div style={{ display: "flex", flex: 1 }}>
        {/* Left panel with customers/services */}
{/* <LeftPanel /> */}
        {/* Main content placeholder */}
<div style={{ flex: 1, padding: "20px" }}>
{/* <h1>Welcome! Select a customer and service.</h1> */}
</div>
</div>
</div>
  );
}