import axios from 'axios';
import { generateBasicAuthHeader } from '../lib/authHelper';

const nodeListService = {

  async getBasicNodes() {
    const username = process.env.NEXT_PUBLIC_USERNAME;
    const password = process.env.NEXT_PUBLIC_PASSWORD;
    const basicAuth = 'Basic ' + Buffer.from(username + ':' + password).toString('base64');
    const response = await axios.get(
      `${process.env.NEXT_PUBLIC_API}/node-list/`,
      {
        headers: {
          'Authorization': basicAuth
        }
      }
    )
    return response.data;
  },
}

export default nodeListService;


