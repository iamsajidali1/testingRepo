import axios from "axios";
 
const httpClient = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_BASE, // e.g. http://localhost:3001
  headers: { "Content-Type": "application/json" },
});
 
// Optional interceptors for auth/logging
httpClient.interceptors.request.use(
  (config) => {
    // Example: attach token
    // const token = localStorage.getItem("token");
    // if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error instanceof Error ? error : new Error(error))
);
 
httpClient.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error("API Error:", error.response?.data || error.message);
    return Promise.reject(error instanceof Error ? error : new Error(error));
  }
);
 
export default httpClient;
 