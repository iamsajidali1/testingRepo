// lib/interceptor.ts
export function getXsrfToken(): string | undefined {
  if (typeof document === 'undefined') return undefined;
  return document.cookie
    .split('; ')
    .find(row => row.startsWith('xsrf-token='))
    ?.split('=')[1];
}

export function setXsrfToken(token: string) {
  if (typeof document === 'undefined') return;
  document.cookie = `xsrf-token=${token};SameSite=Strict`;
}

export async function interceptedFetch(input: RequestInfo, init: RequestInit = {}) {
  const xsrfToken = getXsrfToken();
  const headers = {
    'Cache-Control': 'no-cache, no-store, must-revalidate, post- check=0, pre-check=0',
    'Pragma': 'no-cache',
    'Expires': '0',
    ...(xsrfToken ? { 'xsrf-token': xsrfToken } : {}),
    ...(init.headers || {})
  };

  const res = await fetch(input, {
    ...init,
    credentials: 'include',
    headers,
  });

  const xsrfHeader = res.headers.get('xsrf-token');
  if (xsrfHeader) setXsrfToken(xsrfHeader);

  if (!res.ok) {
    // Optionally log or handle error here
    throw new Error(`Request for ${input} failed with status ${res.status}`);
  }

  return res;
}