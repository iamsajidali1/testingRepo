"use client";

import React, { useState, useEffect, useCallback, useRef } from "react";
import { useSelectionStore } from "../../actions/store/selectionStore";
import { Tree } from "primereact/tree";
import { Button } from "primereact/button";
import { useSearchParams, useRouter } from "next/navigation";
// import { Template, ICarcheTemplate } from "../models/template";
import NodeListService from "../../../services/nodeListService";
import ControllerService from "../../../services/controllerService";
import AddTemplateDialog from "./addTemplateModal/addTemplateModal";
import { Toast } from "primereact/toast";

export interface Template {
    contractid: string | null;
    service: string | null;
    name: string;
    id: string | number;
    // Add other properties as needed
}

export interface ICarcheTemplate {
    contractid: string | null;
    service: string | null;
    name: string;
    id: string | number;
}

interface ListTemplatesProps {
    refresh?: string;
    contractid?: string;
    deletedTemplate?: any;
    copiedTemplate?: any;
    onEventEmitter?: (template: ICarcheTemplate) => void;
    onEventSpinner?: (state: boolean) => void;
}

interface ValidateFunction {
    (field: string, value: any): void;
}

// Define TreeNode type locally since it's not exported by primereact
export interface TreeNode {
    key?: string | number;
    label?: string;
    data?: any;
    icon?: string;
    expandedIcon?: string;
    collapsedIcon?: string;
    children?: TreeNode[];
    leaf?: boolean;
    expanded?: boolean;
    [key: string]: any;
}

const ListTemplatesComponent: React.FC<ListTemplatesProps> = ({

    refresh = "",
    contractid = "",
    deletedTemplate,
    copiedTemplate,
    onEventEmitter,
    onEventSpinner
}) => {

    const router = useRouter();
    const searchParams = useSearchParams();
    const [treeLoading, setTreeLoading] = useState(false);
    const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
    const [listOfTemplates, setListOfTemplates] = useState<Template[]>([]);
    const [indexOfSelectedTemp, setIndexOfSelectedTemp] = useState<string | undefined>();
    const [customerId, setCustomerId] = useState<string>("");
    const [selectedTemplateName, setSelectedTemplateName] = useState("");
    const [templateTreeNodes, setTemplateTreeNodes] = useState<TreeNode[]>([]);
    const [originalTemplateTreeNodes, setOriginalTemplateTreeNodes] = useState<TreeNode[]>([]);
    const [selectedTemplateTreeNode, setSelectedTemplateTreeNode] = useState<any>(null); // selectionKeys expects an object or null
    const [showAddModal, setShowAddModal] = useState(false);
    const toast = useRef<Toast>(null);

    const [newTemplateName, setNewTemplateName] = useState("");
    const [form, setForm] = useState({
        name: "",
        contractid: "",
        service: "",
        templateType: "",
        deviceModel: "",
        vendorType: "",
        body: ""
    });
    interface FormErrors {
        name?: string;
        // Add other fields as needed
    }
    const [errors, setErrors] = useState<FormErrors>({});
    const [touched, setTouched] = useState({});

    const others = "others";

    // -----------------------------

    const validate: ValidateFunction = (field, value) => {
        const newErrors: FormErrors = { ...errors };
        if (field === "name" && !value) {
            newErrors.name = "Name is required";
        } else {
            delete newErrors.name;
        }
        setErrors(newErrors);
    };

    const handleChange = (field: string, value: any) => {
        setForm(prev => ({ ...prev, [field]: value }));
        validate(field, value);
    };

    const handleBlur = (field: string) => {
        setTouched(prev => ({ ...prev, [field]: true }));
    }

    // Tree traversal

    const treeTraverse = useCallback((node: TreeNode, oldKey: any, newKey: any) => {

        if (node.children) {

            node.children.forEach((childNode: any) => {

                if (childNode.key && childNode.leaf) {

                    if (childNode.key === oldKey) {
                        childNode.key = newKey;
                    }
                }
                treeTraverse(childNode, oldKey, newKey);
            });
        }
    }, []);

    // -----------------------------

    // Base nodes loading

    const getBaseNodes = useCallback(() => {

        setTreeLoading(true);
        onEventSpinner?.(true);

        NodeListService.getBasicNodes().then((result: TreeNode[]) => {
            setTreeLoading(false);
            onEventSpinner?.(false);
            setOriginalTemplateTreeNodes(result);
            setTemplateTreeNodes(result);
            //getSelectedCustomerIdFromQueryAndListOfTemplates();
            const templateId = searchParams.get("templateId");
            if (templateId) findTreeNodeBy(templateId, result);
        }).catch((err: unknown) => {
            onEventSpinner?.(false);
            toast.current?.show({
                severity: "error",
                summary: "Error",
                detail: "Error loading templates!",
                life: 3000
            });
        });
    }, [searchParams, onEventSpinner]);

    useEffect(() => {
        getBaseNodes();
    }, []);

    // Get customer id from query

    const getSelectedCustomerIdFromQueryAndListOfTemplates = useCallback(() => {

        const encodedCustomerId = searchParams.get("customerId");
        if (encodedCustomerId) {
            const decoded = atob(encodedCustomerId);
            setCustomerId(decoded);
            generateTreeBasedOnCustomer(decoded);
        } else {
            setTemplateTreeNodes(originalTemplateTreeNodes);
        }

    }, [searchParams, originalTemplateTreeNodes]);

    // -----------------------------

    // Refresh / Delete / Copy logic

    useEffect(() => {

        if (refresh !== "") {
            setSelectedTemplate({
                contractid: null,
                service: null,
                name: "",
                id: "",
            });
            setIndexOfSelectedTemp(undefined);
            getSelectedCustomerIdFromQueryAndListOfTemplates();
        }

        if (deletedTemplate) {

            setSelectedTemplateName("");
            let service = deletedTemplate.service || "";
            if (deletedTemplate.contractid && !deletedTemplate.service) service = others;
            if (!deletedTemplate.templateOldId) {

                removeTemplateFromNodeTreeModel(deletedTemplate.contractid, service, deletedTemplate.id);

            } else {
                templateTreeNodes.forEach((node) =>
                    treeTraverse(node, deletedTemplate.templateOldId, deletedTemplate.id)
                );
            }

        }

        if (copiedTemplate) {
            updateTree(copiedTemplate);
        }

    }, [refresh, deletedTemplate, copiedTemplate, templateTreeNodes]);

    // -----------------------------

    // Node select
    const setSelection = useSelectionStore((s: any) => s.setSelection);
    const nodeSelect = (node: TreeNode) => {
        setSelectedTemplateTreeNode(node);
        if (node.leaf) {
            // const carcheTemp: ICarcheTemplate = {
            //     contractid: (node as any).customer || "",
            //     service: (node as any).service || "",
            //     name: node.data as string,
            //     id: node.key ?? ""
            // };

            // setSelectedTemplateName(node.data as string);
            // onEventEmitter?.(carcheTemp);
            // // Store all relevant info for right panel
            // // setSelection('service', String(carcheTemp.id), carcheTemp.name || "", carcheTemp.contractid || "");
            // // router.replace(`?templateId=${carcheTemp.id}`);

            // const templateId = String(carcheTemp.id);
            // const actionId = templateId;

            // // setSelection('service', templateId, carcheTemp.name || "", carcheTemp.contractid || "");
            // if (carcheTemp.contractid && !carcheTemp.service) {
            //     // Customer selection
            //     setSelection(
            //         'customer',
            //         String(carcheTemp.id),
            //         carcheTemp.name,
            //         carcheTemp.contractid ?? undefined
            //     );
            // } else {
            //     // Service selection
            //     setSelection(
            //         'service',
            //         String(carcheTemp.id),
            //         carcheTemp.name,
            //         carcheTemp.contractid ?? undefined
            //     );
            // }
            // router.replace(`?templateId=${carcheTemp.id}&actionId=${carcheTemp.id}`);

            // till here ........................ 
            
            // try to read templateId from node (may be present under multiple names)
            const nodeAny = node as any;
            const extractedTemplateId =
                nodeAny.templateId ??
                nodeAny.template_id ??
                nodeAny.actionTemplateId ??
                nodeAny.action_template_id ??
                nodeAny.templateIdString ??
                null;

            // build carcheTemp as before (id is the node id — often service id)
            const carcheTemp: ICarcheTemplate = {
                contractid: nodeAny.customer ?? "",
                service: nodeAny.service ?? "",
                name: node.data as string,
                id: node.key ?? ""
            };

            setSelectedTemplateName(node.data as string);
            onEventEmitter?.(carcheTemp);

            // Decide selection type
            const selectionType = carcheTemp.contractid && !carcheTemp.service ? "customer" : "service";

            // Pass templateId as an extra (if your store accepts it). We pass undefined if absent.
            setSelection(
                selectionType,
                String(carcheTemp.id),
                carcheTemp.name,
                carcheTemp.contractid ?? undefined,
                extractedTemplateId ?? undefined
            );

            // build URL params: include templateId param only if we actually extracted it; always include actionId
            const urlTemplateId = extractedTemplateId ?? carcheTemp.id;
            router.replace(`?templateId=${urlTemplateId}&actionId=${carcheTemp.id}`);

            console.log("[Debug] nodeSelect carcheTemp: ", carcheTemp, " templateId (extracted):", extractedTemplateId);
            console.log("[DEBUG] setSelection firing with type:", selectionType);

            // till here ........................

            onEventSpinner?.(false);
        }

    };

    // -----------------------------

    // Generate tree based on customer

    const generateTreeBasedOnCustomer = (customerId: string) => {
        const customerIdNumber = Number(customerId);
        const customerNode: TreeNode[] = [generateMainNode("Customers")];
        originalTemplateTreeNodes[0]?.children?.forEach((customer: any) => {
            if (customer.id === customerIdNumber) customerNode[0].children!.push(customer);
        });
        getGeneralServiceNodesByCustomerService(originalTemplateTreeNodes[1]?.children || [], customerId, customerNode);
    };

    const getGeneralServiceNodesByCustomerService = (treeNode: TreeNode[], customerId: string, customerNode: TreeNode[]) => {

        setTemplateTreeNodes([]);
        const servicesNode: TreeNode[] = [generateMainNode("Services")];
        const servicesForCustomer: TreeNode[] = [];
        onEventSpinner?.(true);

        ControllerService.getServiceToCustomerById(customerId).then((custServices: any) => {
            onEventSpinner?.(false);
            custServices.services?.forEach((custService: any) => {
                treeNode.forEach((service: any) => {
                    if (service.key === custService.serviceName && service.id === custService.id) {
                        servicesForCustomer.push(service);
                    }
                });
            });

            if (servicesForCustomer.length > 0) servicesNode[0].children = servicesForCustomer;
            setTemplateTreeNodes([...customerNode, ...servicesNode]);
        });

    };

    // -----------------------------

    // Add template modal

    const handleAddTemplate = () => {
        if (!newTemplateName) return;
        const template = {
            name: newTemplateName,
            id: crypto.randomUUID(),
            contractid: null,
            service: null,
        };
        updateTree(template);
        setShowAddModal(false);
        setNewTemplateName("");

    };

    // -----------------------------

    // Update tree

    const updateTree = (template: any) => {
        const leaf = generateLeaf(template);
        if (!templateTreeNodes) getBaseNodes();
        else addTemplateToNodeTreeModel(template.contractid, template.service, leaf);
        toast.current?.show({
            severity: "success",
            summary: "Success",
            detail: "Template added succesfully!",
            life: 3000
        })
    };

    const addTemplateToNodeTreeModel = (selectedCustomer: any, selectedService: any, template: any) => {
        if (!templateTreeNodes) getBaseNodes();
        else addTemplateTreeNodeForNoneEmptyTree(selectedCustomer, selectedService, template);
    };

    const addTemplateTreeNodeForNoneEmptyTree = (selectedCustomer: any, selectedService: any, template: any) => {
        if (selectedCustomer) {
            if (!templateTreeNodes[0].expanded) templateTreeNodes[0].expanded = true;
            const customerNode = templateTreeNodes[0].children?.find(
                (node: any) => node.key === selectedCustomer.name && node.id === selectedCustomer.id
            );
            if (!customerNode) {
                templateTreeNodes[0].children!.push(generateCustomerNode(selectedCustomer));
            }
            templateTreeNodes[0].children?.forEach((customer: any) => {
                if (customer.key === selectedCustomer.name && customer.id === selectedCustomer.id) {
                    customer.expanded = true;
                    addTemplateNodeTreeService(customer.children, selectedService, template, selectedCustomer.id);
                }
            });
        } else if (selectedService && !selectedCustomer) {
            if (!templateTreeNodes[1].expanded) templateTreeNodes[1].expanded = true;
            addTemplateNodeTreeService(templateTreeNodes[1].children, selectedService, template, "");
        }
    };

    const addTemplateNodeTreeService = (treeNode: any, selectedService: any, template: any, customerId: any) => {
        treeNode.push(template);
    };

    const removeTemplateFromNodeTreeModel = (customerId: any, serviceId: any, id: any) => {
        if (!templateTreeNodes) return;
        if (customerId) {
            if (templateTreeNodes[0].children) {
                templateTreeNodes[0].children.forEach((customer: any, index: number) => {
                    if (customer.id === customerId) {
                        removeTemplateNodeTreeService(customer.children, serviceId, id);
                        if (customer.children && customer.children.length === 0) templateTreeNodes[0].children?.splice(index, 1);
                    }
                });
            }
        } else if (serviceId && !customerId) {
            if (templateTreeNodes[1].children) {
                removeTemplateNodeTreeService(templateTreeNodes[1].children, serviceId, id);
            }
        }
    };

    const removeTemplateNodeTreeService = (treeNode: any[], serviceId: any, id: any) => {
        treeNode.forEach((service: any, index: number) => {
            if (service.id === serviceId) {
                const idx = service.children.findIndex((c: any) => c.key === id);
                if (idx >= 0) service.children.splice(idx, 1);
                if (service.children.length === 0) treeNode.splice(index, 1);
            }
        });
    };

    const findTreeNodeBy = (templateId: any, nodes: TreeNode[]) => {
        nodes.forEach((node) => {
            const { key, children } = node;
            if (key === Number(templateId)) {
                setSelectedTemplateTreeNode(node);
                nodeSelect(node);
            } else if (children) {
                findTreeNodeBy(templateId, children);
            }
        });
    };

    // -----------------------------

    // Node generation helpers

    // const generateLeaf = (child: any): TreeNode => ({
    //     label: child.name,
    //     key: child.id,
    //     icon: "pi pi-file",
    //     data: child.name,
    //     service: child.service,
    //     leaf: true,
    //     customer: child.contractid,
    // });

    const generateLeaf = (child: any): TreeNode => {

        // try common variations for template id used by different backends
        const templateId =
            child.templateId ??
            child.template_id ??
            child.actionTemplateId ??
            child.action_template_id ??
            child.templateIdString ??
            null;
        return {
            label: child.name,
            key: child.id,
            icon: "pi pi-file",
            data: child.name,
            service: child.service,
            leaf: true,
            customer: child.contractid,
            // attach templateId (can be null) so node carries it
            templateId,
        };
    };

    const generateMainNode = (name: string): TreeNode => ({
        label: name,
        key: name,
        level: 1,
        data: name + " Folder",
        expandedIcon: "pi pi-folder-open",
        collapsedIcon: "pi pi-folder",
        children: [],
    });

    const generateCustomerNode = (customer: any): TreeNode => ({
        label: customer.name,
        key: customer.name,
        data: customer.name,
        id: customer.id,
        children: [],
    });

    return (
        <div>
            <Toast ref={toast} />
            <div style={{ marginTop: 12, borderBottom: "1px solid #c8c8c8" }}>
                <p style={{ textAlign: "center", minHeight: 24 }}>{selectedTemplateName}</p>
            </div>

            {templateTreeNodes.length > 0 && (
                <div className="mb-2">
                    <div style={{ maxHeight: "800px", overflow: "auto" }}>
                        <Tree
                            value={templateTreeNodes}
                            selectionMode="single"
                            selectionKeys={selectedTemplateTreeNode}
                            onSelectionChange={(e) => {
                                setSelectedTemplateTreeNode(e.value);
                                // Find the selected node object and pass to nodeSelect
                                const findNodeByKey = (nodes: TreeNode[], key: any): TreeNode | null => {
                                    for (const node of nodes) {
                                        if (node.key === key) return node;
                                        if (node.children) {
                                            const found = findNodeByKey(node.children, key);
                                            if (found) return found;
                                        }
                                    }
                                    return null;
                                };
                                const selectedKey = e.value;
                                const selectedNode = findNodeByKey(templateTreeNodes, selectedKey);
                                if (selectedNode) nodeSelect(selectedNode);
                            }}
                            loading={treeLoading}
                            filter
                            filterMode="lenient"
                        />
                    </div>
                </div>

            )}

            <div style={{ textAlign: "center" }}>
                <Button icon="pi pi-plus" className="p-button" label="Add new template" onClick={() => setShowAddModal(true)} size="small" />
            </div>

            <AddTemplateDialog
                visible={showAddModal}
                onHide={() => setShowAddModal(false)}
                form={form}
                errors={errors} // Provide an empty object or appropriate value
                touched={touched} // Provide an empty object or appropriate value
                customers={[]} // Provide an empty array or appropriate value
                services={[]} // Provide an empty array or appropriate value
                templateTypes={[]} // Provide an empty array or appropriate value
                contentTypes={[]} // Provide an empty array or appropriate value
                vendorTypes={[]} // Provide an empty array or appropriate value
                disableCustomer={false} // Provide a boolean or appropriate value
                displayErrorMsg={false} // Provide a boolean or appropriate value
                loading={false} // Provide a boolean or appropriate value
                onChange={handleChange} // Provide a no-op or appropriate handler
                onFileUpload={() => { }} // Provide a no-op or appropriate handler
                onAdd={handleAddTemplate}
                onBlur={handleBlur}
            />
        </div>

    );

};

export default ListTemplatesComponent;