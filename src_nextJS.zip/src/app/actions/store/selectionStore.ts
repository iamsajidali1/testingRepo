import { create } from 'zustand';

type SelectionType = 'customer' | 'service' | null;

interface SelectionState {
    selectedType: SelectionType;
    selectedId: string | null;
    selectedName: string | null;
    selectedCustomerId: string | null;
    selectedTemplateId?: string | null;
    setSelection: (type: SelectionType, id: string, name?: string, customerId?: string, templateId?: string) => void;
}

export const useSelectionStore = create<SelectionState>((set) => ({
    selectedType: null,
    selectedId: null,
    selectedName: null,
    selectedCustomerId: null,
    selectedTemplateId: null,
    setSelection: (type, id, name, customerId, templateId) => {
        console.debug("[SelectionStore] setSelection:", { type, id, name, customerId, templateId });
        set({
            selectedType: type,
            selectedId: id,
            selectedName: name ?? null,
            selectedCustomerId: customerId ?? null,
            selectedTemplateId: templateId ?? null,
        });
    },
}));







