// ----------------- Customers -----------------
export async function getCustomers() {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  const res = await fetch(`${baseUrl}/customers/status/?active=true`, {
    cache: "no-store", // ensure fresh data
  });
  if (!res.ok) throw new Error("Failed to fetch customers");
  const json = await res.json();
  return json.result; // backend returns { result: [...] }
}
 
// ----------------- Services -----------------
export async function getServices(customerId: string) {
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  const res = await fetch(`${baseUrl}/service?customerId=${customerId}`, {
    cache: "no-store",
  });
  if (!res.ok) throw new Error("Failed to fetch services");
  const json = await res.json();
  return json.result;
}