import { Subject } from 'rxjs';

export interface Access {
    ID: number;
    [key: string]: any;
    inherited?: boolean;
}

export const actionService = {
    actionServices: [
        { id: 1, name: "Default Service" } // Add your actual service objects here
    ],

    actionLoadCompleteSubject: new Subject<boolean>(),

    actionTemplate: { id: 1 },

    action: {
        actionAccesses: {
            businessCenter: [] as Access[],
            group: [] as Access[],
            individual: [] as Access[],
        },
        actionCache: {} as Record<string, any>,
    },

    customer: {
        id: 1, // or null/undefined if not set by default
        // ...other customer properties if needed
    },

    _cache: {} as Record<string, any>,

    getActionCache(key: string) {
        return (key in this.action.actionCache) ? this.action.actionCache[key] : null;
        //return this._cache[key];
    },

    setActionCache(key: string, value: any) {
        this.action.actionCache[key] = value;
    }

};