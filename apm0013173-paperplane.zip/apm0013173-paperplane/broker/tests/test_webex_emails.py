from unittest.mock import patch, MagicMock, call
from json import dumps
from os import environ
from django.test import TestCase

from broker.handlers import (
    get_webex_email, webex_email_lookup, fetch_att_email_domains
)
from pp_application.settings import WEBEX_API_URL, WEBEX_ATT_ORG, PROXY


class WebexEmailsTestCase(TestCase):
    sample_people = {
        "notFoundIds": None,
        "items": [
            {
                "id": "some-it",
                "emails": [
                    "attuid@intl.att.com"
                ],
                "displayName": "name surname (attuid)",
                "nickName": "nick",
                "firstName": "name",
                "lastName": "surname",
                "orgId": WEBEX_ATT_ORG,
                "created": "2018-10-09T08:11:02.237Z",
                "type": "person"
            }
        ]
    }

    def setup_databases(self, **kwargs):
        pass  # This method is intentionally left empty as no database setup is required for these tests.

    def teardown_databases(self, old_config, **kwargs):
        pass  # This method is intentionally left empty as no database teardown is required for these tests.

    def test_correct_email(self):
        content = b"good"
        code = 200
        response = MagicMock()
        response.configure_mock(**{
            "status_code": code,
            "content": content,
            "text": content.decode("utf-8")
        })

        email = "correct"
        token = "super"

        with patch("broker.handlers.req.get", return_value=response) as mock:
            text = get_webex_email(webex_email=email, token=token)
            get_webex_email.cache_clear()

            mock.assert_called_once_with(
                url=f"{WEBEX_API_URL}/people", params=dict(
                    email=email, orgId=WEBEX_ATT_ORG
                ), proxies={}, headers={"Authorization": f"Bearer {token}"}
            )
            self.assertEqual(content.decode("utf-8"), text)

    def test_incorrect_email(self):
        code = 400
        response = MagicMock()
        response.configure_mock(**{"status_code": code})

        email = "incorrect"
        token = "super"

        with patch("broker.handlers.req.get", return_value=response) as mock:
            text = get_webex_email(webex_email=email, token=token)
            get_webex_email.cache_clear()

            mock.assert_called_once_with(
                url=f"{WEBEX_API_URL}/people", params=dict(
                    email=email, orgId=WEBEX_ATT_ORG
                ), proxies={}, headers={"Authorization": f"Bearer {token}"}
            )
            self.assertEqual("{}", text)

    def test_email_lookup_fail(self):
        domains = fetch_att_email_domains()
        fetch_att_email_domains.cache_clear()
        token = environ.get('WEBEXBOT_TOKEN', '')

        patched = patch(
            "broker.handlers.get_webex_email", return_value="{}"
        )
        with patched as mock:
            result = webex_email_lookup(attuid="invalid")

            self.assertEqual(
                [call(f"invalid@{domain}", token=token) for domain in domains],
                mock.mock_calls
            )
            self.assertIsNone(result)

    def test_email_lookup(self):
        sample = self.sample_people
        sample_json = dumps(sample)
        email = sample["items"][0]["emails"][0]
        attuid = email[:6]

        domains = fetch_att_email_domains()
        fetch_att_email_domains.cache_clear()
        token = environ.get('WEBEXBOT_TOKEN', '')

        patched = patch(
            "broker.handlers.get_webex_email", return_value=sample_json
        )
        with patched as mock:
            result = webex_email_lookup(attuid=attuid)

            self.assertEqual(
                [call(f"{attuid}@{domains[0]}", token=token)],
                mock.mock_calls
            )
            self.assertEqual(email, result)

    def test_email_lookup_custom_token(self):
        sample = self.sample_people
        sample_json = dumps(sample)
        email = sample["items"][0]["emails"][0]
        attuid = email[:6]

        domains = fetch_att_email_domains()
        fetch_att_email_domains.cache_clear()

        patched = patch(
            "broker.handlers.get_webex_email", return_value=sample_json
        )
        with patched as mock:
            result = webex_email_lookup(attuid=attuid, options={
                "bot_type": "webex-bot", "bot_token": "custom"
            })

            self.assertEqual(
                [call(f"{attuid}@{domains[0]}", token="custom")],
                mock.mock_calls
            )
            self.assertEqual(email, result)
