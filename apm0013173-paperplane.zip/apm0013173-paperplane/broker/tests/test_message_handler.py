from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta, timezone
from django.test import TestCase

from broker.handlers import new_message
from api import models


class HandlerMessageTestCase(TestCase):
    def setup_databases(self, **kwargs):
        # Intentionally left blank as no database setup is required for these tests.
        pass

    def teardown_databases(self, old_config, **kwargs):
        # Intentionally left blank as no database teardown is required for these tests.
        pass

    def test_skip_signals(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            msg = models.MessageModel()
            msg.skip_signals = True
            self.assertIsNone(new_message(msg))

            for mock in (email, brd, wchat, wroom):
                mock.assert_not_called()

    def test_skip_processed(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            msg = models.MessageModel(processed=True)
            self.assertIsNone(new_message(msg))

            for mock in (email, brd, wchat, wroom):
                mock.assert_not_called()

    def test_skip_scheduled(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            msg = models.MessageModel(
                time=datetime.now(timezone.utc) + timedelta(days=1)
            )
            self.assertIsNone(new_message(msg))

            for mock in (email, brd, wchat, wroom):
                mock.assert_not_called()

    def test_skip_scheduled_iso(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            msg = models.MessageModel(time=(
                datetime.now(timezone.utc) + timedelta(days=1)
            ).isoformat())
            self.assertIsNone(new_message(msg))

            for mock in (email, brd, wchat, wroom):
                mock.assert_not_called()

    def test_parameter_parse_to(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            msg = models.MessageModel(
                to=["one", "two", "three"],
                type=models.MessageTypeModel(name="ignore-me"),
                app=models.ApplicationModel()
            )
            save_mock = MagicMock()
            msg.save = save_mock
            self.assertFalse(msg.processed)

            self.assertIsNone(new_message(msg))
            self.assertTrue(msg.processed)
            save_mock.assert_called_once()

            for mock in (email, brd, wchat, wroom):
                mock.assert_not_called()

    def test_parameter_parse_to_str(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            msg = models.MessageModel(
                to=str(["one", "two", "three"]),
                type=models.MessageTypeModel(name="ignore-me"),
                app=models.ApplicationModel()
            )
            save_mock = MagicMock()
            msg.save = save_mock
            self.assertFalse(msg.processed)

            self.assertIsNone(new_message(msg))
            self.assertTrue(msg.processed)
            save_mock.assert_called_once()

            for mock in (email, brd, wchat, wroom):
                mock.assert_not_called()

    def test_parameter_parse_bcc(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            msg = models.MessageModel(
                to=[],
                bcc=["one", "two", "three"],
                type=models.MessageTypeModel(name="ignore-me"),
                app=models.ApplicationModel()
            )
            save_mock = MagicMock()
            msg.save = save_mock
            self.assertFalse(msg.processed)

            self.assertIsNone(new_message(msg))
            self.assertTrue(msg.processed)
            save_mock.assert_called_once()

            for mock in (email, brd, wchat, wroom):
                mock.assert_not_called()

    def test_parameter_parse_bcc_str(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            msg = models.MessageModel(
                to=[],
                bcc=str(["one", "two", "three"]),
                type=models.MessageTypeModel(name="ignore-me"),
                app=models.ApplicationModel()
            )
            save_mock = MagicMock()
            msg.save = save_mock
            self.assertFalse(msg.processed)

            self.assertIsNone(new_message(msg))
            self.assertTrue(msg.processed)
            save_mock.assert_called_once()

            for mock in (email, brd, wchat, wroom):
                mock.assert_not_called()

    def test_type_parse_q(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            to_list = ["one", "two", "three"]
            body = "msg"
            app = models.ApplicationModel(app_name="sample")

            msg = models.MessageModel(
                to=to_list, app=app, body=body,
                type=models.MessageTypeModel.objects.get(name="qmessage")
            )
            save_mock = MagicMock()
            msg.save = save_mock
            self.assertFalse(msg.processed)

            self.assertIsNone(new_message(msg))
            self.assertTrue(msg.processed)
            save_mock.assert_called_once()

            for mock in (email, brd, wchat, wroom):
                mock.assert_not_called()


    def test_type_parse_q_chatbot(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            to_list = ["one", "two", "three"]
            body = "msg"
            app = models.ApplicationModel(app_name="sample")

            msg = models.MessageModel(
                to=to_list, app=app, body=body,
                type=models.MessageTypeModel.objects.get(
                    name="q-chatbot-message"
                )
            )
            save_mock = MagicMock()
            msg.save = save_mock
            self.assertFalse(msg.processed)

            self.assertIsNone(new_message(msg))
            self.assertTrue(msg.processed)
            save_mock.assert_called_once()

            for mock in (email, brd, wchat, wroom):
                mock.assert_not_called()
                

    def test_type_parse_email(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            to_list = ["one", "two", "three"]
            bcc_list = ["four", "five"]
            body = "msg"
            app = models.ApplicationModel(
                app_name="sample", from_email="from-email",
                reply_to_email="reply"
            )

            msg = models.MessageModel(
                to=to_list, app=app, body=body, bcc=bcc_list,
                type=models.MessageTypeModel.objects.get(name="email"),
                subject="my sub"
            )
            save_mock = MagicMock()
            msg.save = save_mock
            self.assertFalse(msg.processed)

            self.assertIsNone(new_message(msg))
            self.assertTrue(msg.processed)
            save_mock.assert_called_once()

            for mock in (brd, wchat, wroom):
                mock.assert_not_called()

            email.assert_called_once_with(
                to_emails=to_list, body=body, display_name=app.app_name,
                message_id=msg.id, options={}, bcc_emails=bcc_list,
                from_email=app.from_email, notify_read=msg.notify_read,
                notify_delivered=msg.notify_delivered, subject=msg.subject,
                reply_to=app.reply_to_email, event_app=msg.app, event_uid=''
            )

    def test_type_parse_webex_direct(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            to_list = ["one", "two", "three"]
            body = "msg"
            app = models.ApplicationModel(app_name="sample")

            msg = models.MessageModel(
                to=to_list, app=app, body=body,
                type=models.MessageTypeModel.objects.get(
                    name="webex-teams-message"
                )
            )
            save_mock = MagicMock()
            msg.save = save_mock
            self.assertFalse(msg.processed)

            self.assertIsNone(new_message(msg))
            self.assertTrue(msg.processed)
            save_mock.assert_called_once()

            for mock in (email, brd, wroom):
                mock.assert_not_called()

            wchat.assert_called_once_with(
                to_ids=to_list, message=body, message_id=msg.id, options={}
            )

    def test_type_parse_webex_room(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            to_list = ["one", "two", "three"]
            body = "msg"
            app = models.ApplicationModel(app_name="sample")

            msg = models.MessageModel(
                to=to_list, app=app, body=body,
                type=models.MessageTypeModel.objects.get(
                    name="webex-teams-room-message"
                )
            )
            save_mock = MagicMock()
            msg.save = save_mock
            self.assertFalse(msg.processed)

            self.assertIsNone(new_message(msg))
            self.assertTrue(msg.processed)
            save_mock.assert_called_once()

            for mock in (email, brd, wchat):
                mock.assert_not_called()

            wroom.assert_called_once_with(
                to_ids=to_list, message=body, message_id=msg.id, options={}
            )

    def test_type_parse_broadcast(self):
        pml = patch("broker.handlers.send_email")
        pbd = patch("broker.handlers.send_broadcast")
        pwc = patch("broker.handlers.send_webex_message")
        pwr = patch("broker.handlers.send_webex_room_message")

        with pml as email, pbd as brd, pwc as wchat, pwr as wroom:
            to_list = ["one", "two", "three"]
            body = "msg"
            app = models.ApplicationModel(
                app_name="sample", from_email="from-email",
                reply_to_email="reply"
            )

            msg = models.MessageModel(
                to=to_list, app=app, body=body,
                type=models.MessageTypeModel.objects.get(name="broadcast")
            )
            save_mock = MagicMock()
            msg.save = save_mock
            self.assertFalse(msg.processed)

            self.assertIsNone(new_message(msg))
            self.assertTrue(msg.processed)
            save_mock.assert_called_once()

            for mock in (email, wchat, wroom):
                mock.assert_not_called()

            brd.assert_called_once_with(
                subscription_types=to_list, body=body,
                display_name=app.app_name, message_id=msg.id, options={},
                from_email=app.from_email, notify_read=msg.notify_read,
                notify_delivered=msg.notify_delivered, subject=app.app_name,
                reply_to=app.reply_to_email, app=app
            )
