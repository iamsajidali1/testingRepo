from unittest.mock import patch
from django.test import TestCase

from broker.handlers import send_email_non_att_recipients


class EmailMessageTestCase(TestCase):
    def setup_databases(self, **__):
        # This method is intentionally left empty because no database setup is required for these tests.
        pass

    def teardown_databases(self, *_, **__):
        # This method is intentionally left empty because no database teardown is required for these tests.
        pass

    def test_send_nonatt_warning(self):
        with patch("broker.handlers.send_email") as mock:
            send_email_non_att_recipients()
            mock.assert_called_once()
            self.assertEqual(
                ["subject", "reply_to"], list(mock.call_args[1].keys())
            )
