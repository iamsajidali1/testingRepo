from unittest.mock import patch, MagicMock, call
from json import dumps
from os import environ
from copy import deepcopy
from django.test import TestCase

from broker.handlers import send_webex_message, send_webex_room_message
from pp_application.settings import WEBEX_API_URL, PROXY


class WebexMessageTestCase(TestCase):
    def setup_databases(self, **kwargs):
        # This method is intentionally left empty because no database setup is required for these tests.
        pass

    def teardown_databases(self, old_config, **kwargs):
        # This method is intentionally left empty because no database teardown is required for these tests.
        pass

    def test_correct_email(self):
        content = b"good"
        code = 200
        response = MagicMock()
        response.configure_mock(**{"status_code": code, "content": content})

        token = environ.get("WEBEXBOT_TOKEN", "")
        msg = "message"
        opts_normal = dict(
            url=f"{WEBEX_API_URL}/messages",
            proxies={},
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token}"
            }
        )
        opts_custom = deepcopy(opts_normal)
        opts_custom["headers"]["Authorization"] = "Bearer custom"

        post = patch("broker.handlers.req.post", return_value=response)
        wlook = patch(
            "broker.handlers.webex_email_lookup", return_value="webex@mail"
        )
        with wlook, post as mock_post:
            norm = send_webex_message(to_ids=["mail1", "mail2"], message=msg)
            cust = send_webex_message(
                to_ids=["mail1", "mail2"], message=msg, options={
                    "bot_type": "webex-bot", "bot_token": "custom"
                }
            )

            self.assertEqual([
                call(
                    data=dumps({"toPersonEmail": "webex@mail", "text": msg}),
                    **opts_normal
                ),
                call(
                    data=dumps({"toPersonEmail": "webex@mail", "text": msg}),
                    **opts_normal
                ),
                call(
                    data=dumps({"toPersonEmail": "webex@mail", "text": msg}),
                    **opts_custom
                ),
                call(
                    data=dumps({"toPersonEmail": "webex@mail", "text": msg}),
                    **opts_custom
                )
            ], mock_post.mock_calls)
            self.assertEqual(([code, code], [content, content]), norm)
            self.assertEqual(([code, code], [content, content]), cust)

    def test_correct_email_room_message(self):
        content = b"good"
        code = 200
        response = MagicMock()
        response.configure_mock(**{"status_code": code, "content": content})

        token = environ.get("WEBEXBOT_TOKEN", "")
        msg = "message"
        opts_normal = dict(
            url=f"{WEBEX_API_URL}/messages",
            proxies={},
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token}"
            }
        )
        opts_custom = deepcopy(opts_normal)
        opts_custom["headers"]["Authorization"] = "Bearer custom"

        post = patch("broker.handlers.req.post", return_value=response)
        with post as mock_post:
            norm = send_webex_room_message(
                to_ids=["room1", "room2"], message=msg
            )
            cust = send_webex_room_message(
                to_ids=["room1", "room2"], message=msg, options={
                    "bot_type": "webex-bot", "bot_token": "custom"
                }
            )

            self.assertEqual([
                call(
                    data=dumps({"roomId": "room1", "text": msg}),
                    **opts_normal
                ),
                call(
                    data=dumps({"roomId": "room2", "text": msg}),
                    **opts_normal
                ),
                call(
                    data=dumps({"roomId": "room1", "text": msg}),
                    **opts_custom
                ),
                call(
                    data=dumps({"roomId": "room2", "text": msg}),
                    **opts_custom
                )
            ], mock_post.mock_calls)
            self.assertEqual(([code, code], [content, content]), norm)
            self.assertEqual(([code, code], [content, content]), cust)

    def test_incorrect_email(self):
        wlook = patch("broker.handlers.webex_email_lookup", return_value=None)
        with wlook, patch("broker.handlers.req.post") as mock_post:
            norm = send_webex_message(to_ids=["mail1"], message="nothing")
            mock_post.assert_not_called()
            self.assertEqual(([], []), norm)
