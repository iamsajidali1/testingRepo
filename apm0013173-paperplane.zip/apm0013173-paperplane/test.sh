#!/bin/sh
set -e
cd /app/backend||true
ENV=UNITTEST python3 manage.py migrate
coverage run \
    --branch \
    --source broker,api,pp_application \
    --omit '*/migrations/*,*/apps.py' \
    manage.py test
coverage report --show-missing | grep -v /migrations/
coverage html
