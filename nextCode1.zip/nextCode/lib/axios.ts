// lib/axios.ts
import axios from 'axios';

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL, // e.g., https://selfservice.dev.att.com/api
  withCredentials: true,
});

api.interceptors.request.use((config) => {
  // Set custom headers
  config.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate, post- check=0, pre-check=0';
  config.headers['Pragma'] = 'no-cache';
  config.headers['Expires'] = '0';
  // Example: set xsrf-token from cookie if needed
  if (typeof document !== 'undefined') {
    const xsrfToken = document.cookie
      .split('; ')
      .find(row => row.startsWith('xsrf-token='))
      ?.split('=')[1];
    if (xsrfToken) config.headers['xsrf-token'] = xsrfToken;
  }
  return config;
}, error => Promise.reject(error));

api.interceptors.response.use((response) => {
  // Set xsrf-token cookie from response header if present
  if (typeof document !== 'undefined') {
    const xsrfToken = response.headers['xsrf-token'];
    if (xsrfToken) {
      document.cookie = `xsrf-token=${xsrfToken};SameSite=Strict`;
    }
  }
  return response;
}, (error) => {
  // Handle error
  console.error('Request for', error.config?.url, 'Response Status', error.response?.status, 'With error', error.message);
  return Promise.reject(error);
});

export default api;