"use client";
import { Fieldset } from 'primereact/fieldset';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Tooltip } from 'primereact/tooltip';
import styles from './action-access.module.css';
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";

// Import your services (you’ll need to implement API calls here)

// Update the import path below if the actual location is different
// Update the import path below to the correct location if needed
import { actionService } from "@/services/actionService";
import controllerService from "@/services/controllerService";

interface Access {
  ID: number;
  [key: string]: any;
  inherited?: boolean;
}

const ActionAccess: React.FC = () => {

  const [loaders, setLoaders] = useState<Record<string, boolean>>({});
  const [errors, setErrors] = useState<Record<string, any>>({});
  const [selectedGroup, setSelectedGroup] = useState<Access | null>(null);
  const [assignedGroupAccess, setAssignedGroupAccess] = useState<Access[]>([]);
  const [filteredGroupAccess, setFilteredGroupAccess] = useState<Access[]>([]);
  const [selectedIndividual, setSelectedIndividual] = useState<Access | null>(
    null
  );
  const [assignedIndividualAccess, setAssignedIndividualAccess] = useState<
    Access[]
  >([]);
  const [filteredIndividualAccess, setFilteredIndividualAccess] = useState<
    Access[]
  >([]);
  const [selectedBcUser, setSelectedBcUser] = useState<Access | null>(null);
  const [assignedBcUserAccess, setAssignedBcUserAccess] = useState<Access[]>([]);
  const [filteredBcUserAccess, setFilteredBcUserAccess] = useState<Access[]>([]);
  // ✅ Equivalent of ngOnInit

  useEffect(() => {
    const subscription = actionService.actionLoadCompleteSubject.subscribe(
      (isActionLoaded: boolean) => {
        if (isActionLoaded) {
          loadIndividualAccesses();
          loadGroupAccesses();
          loadBcUserAccesses();
        }
      }
    );

    return () => {
      subscription.unsubscribe(); // ✅ Equivalent of ngOnDestroy
    };

  }, []);

  // Filter available groups for dropdown, using cache if available
  const filterGroups = async () => {
    const cachedGroups = actionService.getActionCache && actionService.getActionCache('groups');
    if (cachedGroups) {
      setFilteredGroupAccess([...cachedGroups]);
      return;
    }
    setLoaders(prev => ({ ...prev, group: true }));
    setErrors(prev => ({ ...prev, group: null }));
    try {
      const groups = await controllerService.getRoles();
      // Set the cache if method exists
      if (actionService.setActionCache) {
        actionService.setActionCache('groups', groups);
      }
      setFilteredGroupAccess([...groups]);
    } catch (error) {
      setErrors(prev => ({ ...prev, group: { message: 'Unable to load available groups' } }));
    } finally {
      setLoaders(prev => ({ ...prev, group: false }));
    }
  };

  // Filter available business center users for dropdown, using cache if available
  const filterBcCustomers = async () => {
    const cachedBcCustomers = actionService.getActionCache && actionService.getActionCache('bcCustomers');
    if (cachedBcCustomers) {
      setFilteredBcUserAccess([...cachedBcCustomers]);
      return;
    }
    setLoaders(prev => ({ ...prev, 'bc-user': true }));
    setErrors(prev => ({ ...prev, 'bc-user': null }));
    try {
      const bcCustomers = await controllerService.getBcUsers();
      if (actionService.setActionCache) {
        actionService.setActionCache('bcCustomers', bcCustomers);
      }
      setFilteredBcUserAccess([...bcCustomers]);
    } catch (error) {
      setErrors(prev => ({ ...prev, 'bc-user': { message: 'Unable to load available bc users' } }));
    } finally {
      setLoaders(prev => ({ ...prev, 'bc-user': false }));
    }
  };

  // Filter available individuals for dropdown, using cache if available
  const filterIndividuals = async () => {
    const cachedIndividuals = actionService.getActionCache && actionService.getActionCache('individuals');
    if (cachedIndividuals) {
      setFilteredIndividualAccess([...cachedIndividuals]);
      return;
    }
    setLoaders(prev => ({ ...prev, individual: true }));
    setErrors(prev => ({ ...prev, individual: null }));
    try {
      const individuals = await controllerService.getExistingUsersFromDB();
      if (actionService.setActionCache) {
        actionService.setActionCache('individuals', individuals);
      }
      setFilteredIndividualAccess([...individuals]);
    } catch (error) {
      setErrors(prev => ({ ...prev, individual: { message: 'Unable to load available individuals' } }));
    } finally {
      setLoaders(prev => ({ ...prev, individual: false }));
    }
  };

  const onAssignIndividualAccess = async () => {
    if (!selectedIndividual) return;
    setLoaders(prev => ({ ...prev, ['individual-assign']: true }));
    try {
      await controllerService.assignTemplateToUser(selectedIndividual.ID, actionService.actionTemplate.id);
      setAssignedIndividualAccess(prev => {
        const updated = [...prev, { ...selectedIndividual, inherited: false }];
        // Update cache
        actionService.action.actionAccesses.individual = [...updated];
        return updated;
      });
      setSelectedIndividual(null);
      toast.success('Successfully assigned access for the selected individual!');
    } catch (error) {
      toast.error('Failed to assign access for the selected individual!');
    } finally {
      setLoaders(prev => ({ ...prev, ['individual-assign']: false }));
    }
  };

  /** -------------------------

   * LOAD FUNCTIONS

   * ------------------------- */

  const loadIndividualAccesses = async () => {
    const cached = actionService.action.actionAccesses.individual;
    if (cached) {
      setAssignedIndividualAccess([...cached]);
      return;
    }

    try {
      setLoaders((l) => ({ ...l, ["individual-load"]: true }));
      const { id } = actionService.actionTemplate;
      const [service] = actionService.actionServices;
      let inherited = await controllerService.getUserForServices(service.id);
      if (actionService.customer?.id) {
        inherited = await controllerService.getUsersForServiceAndCustomer(
          actionService.customer.id,
          service.id
        );
      }

      const [inhResp, tmplResp] = await Promise.all([
        inherited,
        controllerService.getTemplateToUser(id),
      ]);

      const combined = [
        ...(inhResp?.result || []).map((inh: any) => ({
          ...inh,
          inherited: true,
        })),
        ...(tmplResp || []).map((tmp: any) => ({
          ...tmp,
          inherited: false,
        })),
      ];

      setAssignedIndividualAccess(combined);

      actionService.action.actionAccesses.individual = [...combined];
    } catch (err) {
      setErrors((e) => ({
        ...e,
        ["individual-load"]: {
          status: 501,
          message: "Unable to load assigned individual accesses",
        },
      }));

    } finally {
      setLoaders((l) => ({ ...l, ["individual-load"]: false }));
    }

  };

  const loadGroupAccesses = async () => {
    const cached = actionService.action.actionAccesses.group;
    if (cached) {
      setAssignedGroupAccess([...cached]);
      return;
    }

    try {
      setLoaders((l) => ({ ...l, ["group-load"]: true }));
      const { id } = actionService.actionTemplate;
      const [service] = actionService.actionServices;
      let inherited = await controllerService.getRolesForServices(service.id);
      if (actionService.customer?.id) {
        inherited = await controllerService.getRolesForServiceAndCustomer(
          String(actionService.customer.id),
          String(service.id)
        );
      }

      const [inhResp, tmplResp] = await Promise.all([
        inherited,
        controllerService.getTemplateToRole(id),
      ]);

      const combined = [
        ...(inhResp?.result || []).map((inh: any) => ({
          ...inh,
          inherited: true,
        })),

        ...(tmplResp || []).map((tmp: any) => ({
          ...tmp,
          inherited: false,
        })),

      ];

      setAssignedGroupAccess(combined);

      actionService.action.actionAccesses.group = [...combined];

    } catch {

      setErrors((e) => ({
        ...e,
        ["group-load"]: {
          status: 501,
          message: "Unable to load assigned group accesses",
        },
      }));

    } finally {

      setLoaders((l) => ({ ...l, ["group-load"]: false }));

    }

  };

  const loadBcUserAccesses = async () => {

    const cached = actionService.action.actionAccesses.businessCenter;

    if (cached) {

      setAssignedBcUserAccess([...cached]);

      return;

    }

    try {

      setLoaders((l) => ({ ...l, ["bc-user-load"]: true }));
      const { id } = actionService.actionTemplate;
      const [service] = actionService.actionServices;
      let inherited = await controllerService.getBcUserForServices(service.id);
      if (actionService.customer?.id) {
        inherited =
          await controllerService.getBcUserForServiceAndCustomer(
            actionService.customer.id,
            service.id
          );
      }
      const [inhResp, tmplResp] = await Promise.all([
        inherited,
        controllerService.getTemplateToBcUser(id),
      ]);

      const combined = [
        ...(inhResp?.result || []).map((inh: any) => ({
          ...inh,
          inherited: true,
        })),
        ...(tmplResp || []).map((tmp: any) => ({
          ...tmp,
          inherited: false,
        })),
      ];

      setAssignedBcUserAccess(combined);
      actionService.action.actionAccesses.businessCenter = [...combined];
    } catch {

      setErrors((e) => ({
        ...e,
        ["bc-user-load"]: {
          status: 501,
          message: "Unable to load assigned bc user accesses",
        },
      }));

    } finally {
      setLoaders((l) => ({ ...l, ["bc-user-load"]: false }));
    }

  };

  /** -------------------------

   * ASSIGN/REMOVE FUNCTIONS

   * ------------------------- */

  const onAssignGroupAccess = async () => {
    if (!selectedGroup) return;
    try {
      setLoaders((l) => ({ ...l, ["group-assign"]: true }));
      await controllerService.assignTemplateToRole(
        selectedGroup.ID,
        actionService.actionTemplate.id
      );
      setAssignedGroupAccess((prev) => [
        ...prev,
        { ...selectedGroup, inherited: false },
      ]);
      setSelectedGroup(null);
      toast.success("Successfully assigned access for the selected group!");
    } catch {
      toast.error("Failed to assign access for the selected group!");
    } finally {
      setLoaders((l) => ({ ...l, ["group-assign"]: false }));
    }
  };

  const onRemoveGroupAccess = async (id: number) => {

    if (!id) return;

    try {

      setLoaders((l) => ({ ...l, [`group-revoke-${id}`]: true }));

      await controllerService.deleteRoleForActionTemplate(

        id,

        actionService.actionTemplate.id

      );

      setAssignedGroupAccess((prev) =>

        prev.filter((gr) => !(gr.ID === id && !gr.inherited))

      );

      toast.success("Successfully revoked access for the selected group!");

    } catch {

      toast.error("Failed to revoke access for the selected group!");

    } finally {

      setLoaders((l) => ({ ...l, [`group-revoke-${id}`]: false }));

    }

  };


  const onRemoveIndividualAccess = async (id: number) => {
    if (!id) return;
    setLoaders(prev => ({ ...prev, [`individual-revoke-${id}`]: true }));
    try {
      await controllerService.deleteUsersForActionTemplate(id, actionService.actionTemplate.id);
      const updatedAccess = assignedIndividualAccess.filter(
        acc => !(acc.ID === id && !acc.inherited)
      );
      setAssignedIndividualAccess(updatedAccess);
      // Update cache if needed
      actionService.action.actionAccesses.individual = [...updatedAccess];
      toast.success('Successfully revoked access for the selected individual!');
    } catch (error) {
      toast.error('Failed to revoke access for the selected individual!');
    } finally {
      setLoaders(prev => ({ ...prev, [`individual-revoke-${id}`]: false }));
    }
  };

  const onAssignBcUserAccess = async () => {
    if (!selectedBcUser) return;
    setLoaders(prev => ({ ...prev, ['bc-user-assign']: true }));
    try {
      await controllerService.assignTemplateToBCUser(selectedBcUser.ID, actionService.actionTemplate.id);
      setAssignedBcUserAccess(prev => {
        const updated = [...prev, { ...selectedBcUser, inherited: false }];
        // Update cache
        if (actionService.action && actionService.action.actionAccesses) {
          actionService.action.actionAccesses.businessCenter = [...updated];
        }
        return updated;
      });
      setSelectedBcUser(null);
      toast.success('Successfully assigned access for the selected bc user!');
    } catch (error) {
      toast.error('Failed to assign access for the selected bc user!');
    } finally {
      setLoaders(prev => ({ ...prev, ['bc-user-assign']: false }));
    }
  };

  const onRemoveBcUserAccess = async (id: number) => {
    if (!id) return;
    setLoaders(prev => ({ ...prev, [`bc-user-revoke-${id}`]: true }));
    try {
      await controllerService.deleteBcUserForActionTemplate(id, actionService.actionTemplate.id);
      setAssignedBcUserAccess(prev => {
        const updated = prev.filter(acc => !(acc.ID === id && !acc.inherited));
        // Update cache
        actionService.action.actionAccesses.businessCenter = [...updated];
        return updated;
      });
      toast.success('Successfully revoked access for the selected bc user!');
    } catch (error) {
      toast.error('Failed to revoke access for the selected bc user!');
    } finally {
      setLoaders(prev => ({ ...prev, [`bc-user-revoke-${id}`]: false }));
    }
  };

  // Helper for rendering chips
  const renderChips = (assigned: Access[], type: string) =>
    assigned.map(access => (
      <div
        key={access.ID}
        className={`ui-chips-input-token ${styles['chips-custom']}${access.inherited ? ' success-chip' : ''}`}
      >
        {access.IDENTIFICATOR || access.NAME}
        {!access.inherited ? (
          <>
            {!loaders[`${type}-revoke-${access.ID}`] ? (
              <i
                className="ml-2 cursor-pointer fa fa-times"
                title={`Revoke access for this ${type}!`}
                onClick={() => {
                  if (type === 'group') onRemoveGroupAccess(access.ID);
                  if (type === 'individual') onRemoveIndividualAccess(access.ID);
                  if (type === 'bc-user') onRemoveBcUserAccess(access.ID);
                }}
              />
            ) : (
              <i
                className="ml-2 fa fa-spin fa-spinner"
                title={`Revoking access for this ${type}!`}
              />
            )}
          </>
        ) : (
          <i
            className="ml-2 far fa-question-circle"
            title="This access is inherited from its parent, can't be modified here!"
          />
        )}
      </div>
    ));

  return (
    <section className="bg-white pb-3 pl-3 pr-3">
      <div className="grid">
        <div className='col-12'>
          <Fieldset legend="Access Management">
            {/* Group Access */}
            <div className="grid align-items-center mb-4">
              <div className="col-3">
                <p className="p-label">
                  Group <span className="marker_required">*</span> :
                </p>
              </div>
              <div className="col-6">
                <div className="flex align-items-center">
                  <Dropdown
                    options={filteredGroupAccess}
                    className="mr-2 w-full"
                    optionLabel="IDENTIFICATOR"
                    value={selectedGroup}
                    onChange={e => setSelectedGroup(e.value)}
                    onClick={filterGroups}
                    placeholder="Choose group access"
                  />
                  <span
                    className="tooltip-wrapper"
                    data-pr-tooltip="Assign action access to the selected group"
                  >
                    <Button
                      icon="pi pi-plus"
                      aria-label="add"
                      className="my-group-plus-btn"
                      onClick={onAssignGroupAccess}
                      disabled={!selectedGroup}
                    />
                  </span>

                  <Tooltip target=".tooltip-wrapper" position="right" />
                  {/* <Button
                    icon="pi pi-plus"
                    aria-label='add'
                    className="my-group-plus-btn"
                    tooltip="Assign action access to the selected group"
                    tooltipOptions={{ position: 'right' }}
                    onClick={onAssignGroupAccess}
                    disabled={!selectedGroup}
                  /> */}
                </div>
                <div className="p-grid mt-2">
                  <div className={`${styles['chips-wrapper']}`}>
                    {(loaders['group-load'] || errors['group-load']) ? (
                      <>
                        {loaders['group-load'] && (
                          <p className="p-2 mt-2">
                            <i className="fa fa-spin fa-spinner mr-2"></i> loading assigned group accesses
                          </p>
                        )}
                        {errors['group-load'] && (
                          <p className="error-message p-2 mt-2">
                            <i className="fas fa-exclamation-triangle mr-2"></i>
                            {errors['group-load'].message}. Please
                            <a className="font-bold cursor-pointer" onClick={loadGroupAccesses}>Retry!</a>
                          </p>
                        )}
                      </>
                    ) : (
                      renderChips(assignedGroupAccess, 'group')
                    )}
                  </div>
                </div>
              </div>
              <div className="col-3">
                {loaders['group'] && (
                  <p className="p-2 ml-2">
                    <i className="fa fa-spin fa-spinner"></i> loading available groups
                  </p>
                )}
                {loaders['group-assign'] && (
                  <p className="p-2 ml-2">
                    <i className="fa fa-spin fa-spinner"></i> saving the group assignment
                  </p>
                )}
              </div>
            </div>
            {/* Individual Access */}
            <div className="grid align-items-center mb-4">
              <div className="col-3">
                <p className="p-label">
                  Individual <span className="marker_required">*</span> :
                </p>
              </div>
              <div className="col-6">
                <div className="flex align-items-center">
                  <Dropdown
                    options={filteredIndividualAccess}
                    className="mr-2 w-full"
                    optionLabel="NAME"
                    value={selectedIndividual}
                    onChange={e => setSelectedIndividual(e.value)}
                    onClick={filterIndividuals}
                    placeholder="Choose individual access"
                  />
                  <span
                    className="my-group-plus-btn-tooltip"
                    data-pr-tooltip="Assign action access to the selected individual"
                  >
                    <Button
                      icon="pi pi-plus"
                      className="my-group-plus-btn"
                      onClick={onAssignIndividualAccess}
                      disabled={loaders.individual || loaders['individual-assign'] || !selectedIndividual}
                    />
                  </span>
                  <Tooltip target=".my-group-plus-btn-tooltip" position="right" />
                  {/* <Button
                      className="ui-button"
                      tooltip="Assign action access to the selected individual"
                      onClick={onAssignIndividualAccess}
                      disabled={loaders.individual || loaders['individual-assign'] || !selectedIndividual}
                      icon={loaders['individual-assign'] ? 'pi pi-spin pi-spinner' : 'fa fa-plus'}
                    /> */}
                </div>
                <div className="p-grid mt-2">
                  <div className={`${styles['chips-wrapper']}`}>
                    {(loaders['individual-load'] || errors['individual-load']) ? (
                      <>
                        {loaders['individual-load'] && (
                          <p className="p-2 mt-2">
                            <i className="fa fa-spin fa-spinner mr-2"></i> loading assigned individual accesses
                          </p>
                        )}
                        {errors['individual-load'] && (
                          <p className="error-message p-2 mt-2">
                            <i className="fas fa-exclamation-triangle mr-2"></i>
                            {errors['individual-load'].message}. Please
                            <a className="font-bold cursor-pointer" onClick={loadIndividualAccesses}>Retry!</a>
                          </p>
                        )}
                      </>
                    ) : (
                      renderChips(assignedIndividualAccess, 'individual')
                    )}
                  </div>
                </div>
              </div>
              <div className="col-3">
                {loaders['individual'] && (
                  <p className="p-2 ml-2">
                    <i className="fa fa-spin fa-spinner"></i> loading available individuals
                  </p>
                )}
                {loaders['individual-assign'] && (
                  <p className="p-2 ml-2">
                    <i className="fa fa-spin fa-spinner"></i> saving the individual assignment
                  </p>
                )}
              </div>
            </div>
            {/* BC User Access */}
            <div className="grid align-items-center mb-4">
              <div className="col-3">
                <p className="p-label">
                  Business Center <span className="marker_required">*</span> :
                </p>
              </div>
              <div className="col-6">
                <div className="flex align-items-center">
                  <Dropdown
                    options={filteredBcUserAccess}
                    className="mr-2 w-full"
                    optionLabel="NAME"
                    value={selectedBcUser}
                    onChange={e => setSelectedBcUser(e.value)}
                    onClick={filterBcCustomers}
                    placeholder="Choose bc user access"
                  />
                   <span
                    className="my-group-plus-btn-tooltip"
                    data-pr-tooltip="Assign action access to the selected individual">

                    <Button
                      className='my-group-plus-btn'
                      tooltip="Assign action access to the selected bc user"
                      onClick={onAssignBcUserAccess}
                      disabled={loaders['bc-user'] || loaders['bc-user-assign'] || !selectedBcUser}
                      icon={loaders['bc-user-assign'] ? 'pi pi-spin pi-spinner' : "pi pi-plus"}
                    /> 
                  </span>
                  <Tooltip target=".my-group-plus-btn-tooltip" position="right" />
                  {/* <Button
                    className='my-group-plus-btn'
                    tooltip="Assign action access to the selected bc user"
                    onClick={onAssignBcUserAccess}
                    disabled={loaders['bc-user'] || loaders['bc-user-assign'] || !selectedBcUser}
                    icon={loaders['bc-user-assign'] ? 'pi pi-spin pi-spinner' : "pi pi-plus"}
                  /> */}
                </div>
                <div className="p-grid mt-2">
                  <div className={`${styles['chips-wrapper']}`}>
                    {(loaders['bc-user-load'] || errors['bc-user-load']) ? (
                      <>
                        {loaders['bc-user-load'] && (
                          <p className="p-2 mt-2">
                            <i className="fa fa-spin fa-spinner mr-2"></i> loading assigned bc user accesses
                          </p>
                        )}
                        {errors['bc-user-load'] && (
                          <p className="error-message p-2 mt-2">
                            <i className="fas fa-exclamation-triangle mr-2"></i>
                            {errors['bc-user-load'].message}. Please
                            <a className="font-bold cursor-pointer" onClick={loadBcUserAccesses}>Retry!</a>
                          </p>
                        )}
                      </>
                    ) : (
                      renderChips(assignedBcUserAccess, 'bc-user')
                    )}
                  </div>
                </div>
              </div>
              <div className="col-3">
                {loaders['bc-user'] && (
                  <p className="p-2 ml-2">
                    <i className="fa fa-spin fa-spinner"></i> loading available bc users
                  </p>
                )}
                {loaders['bc-user-assign'] && (
                  <p className="p-2 ml-2">
                    <i className="fa fa-spin fa-spinner"></i> saving the bc user assignment
                  </p>
                )}
              </div>
            </div>
          </Fieldset>
        </div>
      </div>
    </section>
  );
};


export default ActionAccess;

