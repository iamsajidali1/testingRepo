// created the this for loading actions tab with left panel
"use client";
import React from "react";
import ListTemplates from "../configurationTemplate/list_templates/list_templates";
import { useSelectionStore } from "./store/selectionStore";
import ActionPropertiesForm from "../components/actions/actionPropertiesForm";
import ActionAccess from "../components/actions/action-access/action-access";
import FormRulesTab from "./form-rules/formRulesTab";
import { Tabs } from "antd";

export default function ActionsPage() {
	const { selectedType, selectedId } = useSelectionStore();

	// Only show tabs if a selection exists
	const showTabs = selectedType && selectedId;

	return (
		<div style={{ display: "flex", height: "100vh" }}>
			{/* Left panel reused from Configuration Templates */}
			<div className="w-1/4 h-full flex-shrink-0">
				<ListTemplates />
			</div>
			{/* Main actions content */}
			<div style={{ flex: 1, background: "#f5f5f5", padding: "32px" }}>
				{showTabs ? (
					<Tabs defaultActiveKey="properties" type="card" items={[
						{
							key: "properties",
							label: "Properties",
							children: <ActionPropertiesForm selectionType={selectedType} selectionId={selectedId} />,
						},
						{
							key: "accesses",
							label: "Accesses",
							children: <ActionAccess selectionType={selectedType} selectionId={selectedId} />,
						},
						{
							key: "formRules",
							label: "Form Rules",
							children: <FormRulesTab actionId={Number(selectedId)} templateId={Number(selectedId)} />,
						},
						// Add Form Builder, Validations, etc. tabs here as needed
					]} />
				) : (
					<h2 style={{ color: "#888", textAlign: "center", marginTop: "120px" }}>
						Please select a customer or service from the left panel
					</h2>
				)}
			</div>
		</div>
	);
}
