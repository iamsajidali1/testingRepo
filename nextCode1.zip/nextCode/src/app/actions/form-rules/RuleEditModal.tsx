"use client";

import React, { useEffect, useState } from "react";
import { Modal, Button, Input, Select, Space, Tooltip } from "antd";
import { PlusOutlined, MinusCircleOutlined } from "@ant-design/icons";
import { FormRule, WhenCondition, ThenCondition } from "../../../services/formRulesService";
import { getFormTemplateById } from "../../../services/controllerService";

interface Props {
  open: boolean;
  onCancel: () => void;
  onOk: (when: WhenCondition[], then: ThenCondition[], ruleId?: number) => void;
  rule: FormRule | null;
  templateId: number;
}

type FieldOption = { key: string; label: string };

// These match the Angular app's logic exactly!
const conditionOptions = [
  { value: "starts with", label: "starts with", hasValue: true },
  { value: "ends with", label: "ends with", hasValue: true },
  { value: "contains", label: "contains", hasValue: true },
  { value: "is", label: "is", hasValue: true },
  { value: "is not", label: "is not", hasValue: true },
  { value: "is empty", label: "is empty", hasValue: false },
  { value: "is not empty", label: "is not empty", hasValue: false },
  { value: "is one of", label: "is one of", hasValue: true },
];

const actionOptions = [
  { value: "set", label: "set", hasValue: true },
  { value: "hide", label: "hide", hasValue: false },
];

const operationOptions = [
  { value: "OR", label: "OR" },
  { value: "AND", label: "AND" },
];

export default function RuleEditModal({
  open,
  onCancel,
  onOk,
  rule,
  templateId,
}: Props) {
  const [fields, setFields] = useState<FieldOption[]>([]);
  const [when, setWhen] = useState<any[]>([]);
  const [then, setThen] = useState<any[]>([]);
  const belongsTo = "customer"; // Centralized

  // Load fields when templateId or modal opens
  useEffect(() => {
    async function loadFields() {
      try {
        const res = await getFormTemplateById(templateId);
        // supports both "questions" or "QUESTIONS" as per backend variations
        const q = res?.result?.questions || res?.result?.QUESTIONS || [];
        setFields(q.map((f: any) => ({ key: f.key, label: f.label || f.key })));
      } catch {
        setFields([]);
      }
    }
    if (open && templateId) loadFields();
  }, [open, templateId]);

  // When editing a rule, populate from rule.
  useEffect(() => {
    if (rule) {
      setWhen(
        rule.WHEN_CONDITIONS.length > 0
          ? rule.WHEN_CONDITIONS.map((w) => ({ ...w }))
          : [{ source_key: "", condition: "", value: "", operation: undefined }]
      );
      setThen(
        rule.THEN_CONDITIONS.length > 0
          ? rule.THEN_CONDITIONS.map((t) => ({ ...t }))
          : [{ target_key: "", action: "", target_value: "" }]
      );
    }
  }, [rule, open]);

  // FIX: When opening modal for "add" (not edit) and fields have loaded, reset to 1 blank row
  useEffect(() => {
    if (open && fields.length > 0 && !rule) {
      setWhen([{ source_key: "", condition: "", value: "", operation: undefined }]);
      setThen([{ target_key: "", action: "", target_value: "" }]);
    }
  }, [open, fields, rule]);

  const handleWhenChange = (i: number, key: string, value: any) => {
    setWhen((prev) => prev.map((w, idx) => (idx === i ? { ...w, [key]: value } : w)));
  };
  const handleThenChange = (i: number, key: string, value: any) => {
    setThen((prev) => prev.map((t, idx) => (idx === i ? { ...t, [key]: value } : t)));
  };

  const addWhen = () =>
    setWhen((prev) => [
      ...prev,
      {
        source_key: "",
        condition: "is",
        value: "",
        operation: "OR",
      },
    ]);
  const removeWhen = (i: number) =>
    setWhen((prev) => (prev.length > 1 ? prev.filter((_, idx) => idx !== i) : prev));

  const addThen = () =>
    setThen((prev) => [
      ...prev,
      { target_key: "", action: "set", target_value: "" },
    ]);
  const removeThen = (i: number) =>
    setThen((prev) => (prev.length > 1 ? prev.filter((_, idx) => idx !== i) : prev));

  const isFormValid = () =>
    when.every((w) => w.source_key && w.condition && (w.value || w.value === "" || conditionOptions.find(c => c.value === w.condition)?.hasValue === false)) &&
    then.every((t) => t.target_key && t.action && (t.target_value || t.target_value === "" || actionOptions.find(a => a.value === t.action)?.hasValue === false));

  return (
    <Modal
      title={
        <span style={{ fontWeight: 700, fontSize: "1.18rem", color: "#232947" }}>
          {rule ? "Edit Form Rule" : "Add New Form Rule"}
        </span>
      }
      open={open}
      onCancel={onCancel}
      onOk={() =>
        onOk(
          when.map(({ source_key, condition, value, operation }) => ({
            source_key,
            condition,
            value,
            ...(operation ? { operation } : {}),
          })),
          then.map(({ target_key, action, target_value }) => ({
            target_key,
            action,
            target_value,
          })),
          rule?.ID
        )
      }
      okButtonProps={{
        disabled: !isFormValid(),
        style: {
          background: "#61b5fa",
          borderColor: "#61b5fa",
          color: "#fff",
          fontWeight: 600,
        },
      }}
      cancelText="Discard"
      cancelButtonProps={{
        style: {
          background: "#f1f3f6",
          color: "#232947",
          fontWeight: 600,
        },
      }}
      width={720}
      maskClosable={false}
      destroyOnHidden
    >
      <div>
        <strong style={{ fontSize: "1.05rem", color: "#232947" }}>When Conditions</strong>
        {when.map((w, i) => (
          <Space key={i} style={{ display: "flex", marginBottom: 10 }} align="start">
            <Select
              style={{ width: 110 }}
              placeholder="Operation"
              value={w.operation}
              onChange={(val) => handleWhenChange(i, "operation", val)}
              options={operationOptions}
              allowClear
              disabled={i === 0}
            />
            <Select
              style={{ width: 180 }}
              placeholder="Source Key"
              value={w.source_key}
              onChange={(val) => handleWhenChange(i, "source_key", val)}
              options={fields.map((f) => ({ value: f.key, label: f.label }))}
            />
            <Select
              style={{ width: 130 }}
              placeholder="Condition"
              value={w.condition}
              onChange={(val) => handleWhenChange(i, "condition", val)}
              options={conditionOptions}
            />
            {conditionOptions.find((c) => c.value === w.condition)?.hasValue && (
              <Input
                style={{ width: 130 }}
                placeholder="Value"
                value={w.value}
                onChange={(e) => handleWhenChange(i, "value", e.target.value)}
              />
            )}
            {when.length > 1 && (
              <Tooltip title="Remove Condition">
                <Button
                  icon={<MinusCircleOutlined />}
                  onClick={() => removeWhen(i)}
                  danger
                  type="text"
                />
              </Tooltip>
            )}
          </Space>
        ))}
        <Button
          icon={<PlusOutlined />}
          type="dashed"
          onClick={addWhen}
          style={{ marginBottom: 12, marginTop: 0, width: 40, padding: 0 }}
          aria-label="Add Condition"
        />
      </div>
      <div style={{ marginTop: 18 }}>
        <strong style={{ fontSize: "1.05rem", color: "#232947" }}>Then Conditions</strong>
        {then.map((t, i) => (
          <Space key={i} style={{ display: "flex", marginBottom: 10 }} align="start">
            <Select
              style={{ width: 180 }}
              placeholder="Target Key"
              value={t.target_key}
              onChange={(val) => handleThenChange(i, "target_key", val)}
              options={fields.map((f) => ({ value: f.key, label: f.label }))}
            />
            <Select
              style={{ width: 110 }}
              placeholder="Action"
              value={t.action}
              onChange={(val) => handleThenChange(i, "action", val)}
              options={actionOptions}
            />
            {actionOptions.find((a) => a.value === t.action)?.hasValue && (
              <Input
                style={{ width: 130 }}
                placeholder="Target Value"
                value={t.target_value}
                onChange={(e) => handleThenChange(i, "target_value", e.target.value)}
              />
            )}
            {then.length > 1 && (
              <Tooltip title="Remove Then">
                <Button
                  icon={<MinusCircleOutlined />}
                  onClick={() => removeThen(i)}
                  danger
                  type="text"
                />
              </Tooltip>
            )}
          </Space>
        ))}
        <Button
          icon={<PlusOutlined />}
          type="dashed"
          onClick={addThen}
          style={{ marginBottom: 0, marginTop: 0, width: 40, padding: 0 }}
          aria-label="Add Then"
        />
      </div>
    </Modal>
  );
}