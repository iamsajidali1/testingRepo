import { create } from 'zustand';

type SelectionType = 'customer' | 'service' | null;

interface SelectionState {
  selectedType: SelectionType;
  selectedId: string | null;
  setSelection: (type: SelectionType, id: string) => void;
}

export const useSelectionStore = create<SelectionState>((set: (state: Partial<SelectionState>) => void) => ({
  selectedType: null,
  selectedId: null,
  setSelection: (type: SelectionType, id: string) => set({ selectedType: type, selectedId: id }),
}));
