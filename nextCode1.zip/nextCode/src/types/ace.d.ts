declare module 'ace-builds/src-noconflict/ace' {
  const ace: any;
  export default ace;
}
declare module 'ace-builds/src-noconflict/ext-language_tools';
declare module 'ace-builds/src-noconflict/mode-django';
declare module 'ace-builds/src-noconflict/theme-github';