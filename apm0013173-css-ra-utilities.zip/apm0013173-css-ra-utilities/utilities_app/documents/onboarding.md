# Access

Please use Either AT&T Global Logon credentials or your AAF MechID credentials to access this resource.
