"""URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path, re_path
from django.conf.urls import include
from django.conf.urls.static import static
from django.views.generic.base import RedirectView
from velocloud_app.settings import STATIC_URL, STATIC_ROOT

urlpatterns = [
    re_path(r'^api/', include('api.urls')),

    # index page
    path(
        "",
        RedirectView.as_view(pattern_name="schema-swagger-ui", permanent=True),
        name='index'
    )
] + static(STATIC_URL, document_root=STATIC_ROOT)
