// // src/app/actions/store/actionSelectionStore.ts
// import { create } from "zustand";
 
// export type SelectionType = "customer" | "service" | "";
 
// export interface SelectedNode {
//   type: SelectionType;
//   id?: string | number;
//   templateId?: number;
//   serviceId?: number;
//   customerId?: number;
//   // other useful fields for future
//   name?: string;
// }
 
// interface ActionSelectionState {
//   selectedNode: SelectedNode | null;
//   setSelectedNode: (node: SelectedNode | null) => void;
//   clearSelection: () => void;
// }
 
// export const useActionSelectionStore = create<ActionSelectionState>((set) => ({
//   selectedNode: null,
//   setSelectedNode: (node) => set({ selectedNode: node }),
//   clearSelection: () => set({ selectedNode: null }),
// }));