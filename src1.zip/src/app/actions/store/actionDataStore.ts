// // src/app/actions/store/actionDataStore.ts
// import { create } from "zustand";
// import {
//     getFormTemplateById,
//     // getTemplateToRole,
//     // getTemplateToBcUser,
// } from "../../../services/controllerService"; // uses your file in src/app/services or src/services
// import * as controllerService from "../../../services/controllerService"; // fallback to call other endpoints

// type AccessBundle = {
//     toUser?: any;
//     toRole?: any;
//     toBcUser?: any;
//     raw?: any;
// };

// type State = {
//     loading: boolean;
//     error: string | null;
//     template: any | null;
//     accessData: AccessBundle | null;
//     formRules: any[] | null; // form rules loaded separately if needed
//     loadAll: (opts: { templateId?: number | null; serviceId?: number | null; customerId?: number | null }) => Promise<void>;
//     clear: () => void;
// };

// export const useActionDataStore = create<State>((set) => ({
//     loading: false,
//     error: null,
//     template: null,
//     accessData: null,
//     formRules: null,

//     loadAll: async ({ templateId, serviceId, customerId }) => {
//         set({ loading: true, error: null });
//         try {
//             const tId = Number(templateId) || undefined;

//             // Important: call only if templateId is present
//             const pTemplate = tId ? await getFormTemplateById(tId) : null;

//             // Access calls: use controllerService helpers (some may return .data or .result)
//             const [toUser, toRole, toBcUser] = await Promise.all([
//                 tId ? controllerService.getTemplateUsers?.(tId).catch(() => null) : Promise.resolve(null),
//                 tId ? controllerService.getTemplateRoles?.(tId).catch(() => null) : Promise.resolve(null),
//                 tId ? controllerService.getTemplateBcUsers?.(tId).catch(() => null) : Promise.resolve(null),
//             ]);

//             // If you have a form-rules endpoint you can fetch here (optional)
//             let rules = null;
//             try {
//                 if (tId && (controllerService as any).getFormRulesForTemplate) {
//                     rules = await (controllerService as any).getFormRulesForTemplate(tId);
//                 }
//             } catch (e) {
//                 rules = null;
//             }

//             set({
//                 template: pTemplate?.result ?? pTemplate ?? null,
//                 accessData: { toUser, toRole, toBcUser, raw: { templateId, serviceId, customerId } },
//                 formRules: rules ?? null,
//                 loading: false,
//             });
//         } catch (err: any) {
//             set({ error: err?.message ?? "Load failed", loading: false });
//             console.error("actionDataStore.loadAll error", err);
//         }
//     },

//     clear: () => set({ template: null, accessData: null, formRules: null, loading: false, error: null }),
// }));