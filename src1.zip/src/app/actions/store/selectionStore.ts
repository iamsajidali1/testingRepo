import { create } from 'zustand';

type SelectionType = 'customer' | 'service' | null;

interface SelectionState {
    selectedType: SelectionType;
    selectedId: string | null;
    selectedName: string | null;
    selectedCustomerId: string | null;
    setSelection: (type: SelectionType, id: string, name?: string, customerId?: string) => void;
}

export const useSelectionStore = create<SelectionState>((set: (state: Partial<SelectionState>) => void) => ({
    selectedType: null,
    selectedId: null,
    selectedName: null,
    selectedCustomerId: null,
    setSelection: (type: SelectionType, id: string, name?: string, customerId?: string) => set({ selectedType: type, selectedId: id, selectedName: name ?? null, selectedCustomerId: customerId ?? null }),
}));
