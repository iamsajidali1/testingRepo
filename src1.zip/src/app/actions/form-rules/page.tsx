// "use client";

// import { useSearchParams } from "next/navigation";
// import FormRulesTab from "./formRulesTab";


// export default function FormRulesPage() {
//   const searchParams = useSearchParams();
//   const actionId = Number(searchParams.get("actionId"));
//   // const belongsTo = searchParams.get("belongsTo") || "customer";

//   return (
//     <FormRulesTab actionId={actionId} templateId={actionId} />
//   );
// }