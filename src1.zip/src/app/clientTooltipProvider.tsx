"use client";
import { Tooltip } from 'primereact/tooltip';

export default function ClientTooltipProvider() {
  return <Tooltip target=".my-group-plus-btn" />;
}