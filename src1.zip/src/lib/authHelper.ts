  /**
 * Generates a Basic Authentication header value.
 * @returns {string} The Basic Auth header value.
 */
export const generateBasicAuthHeader = (): string => {
  const username = process.env.NEXT_PUBLIC_API_USERNAME;
  const password = process.env.NEXT_PUBLIC_API_PASSWORD;

  if (!username || !password) {
    throw new Error('Missing NEXT_PUBLIC_API_USERNAME or NEXT_PUBLIC_API_PASSWORD environment variables');
  }

  return 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');
};